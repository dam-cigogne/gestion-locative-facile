/* ============ Vue ============ */
const now0 = new Date();
const V = { tab:"home", y:now0.getFullYear(), m:now0.getMonth(), bf:"all", mf:"mois", bsub:"vue", bsel:"", editId:null, draft:null, pending:null, msg:"", wipe:false, fq:"", faceOK:false };
let toastTimer;
function toast(t){ const el = $("#toast"); el.textContent = t; el.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => el.hidden = true, 2600); }
const svg = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const ICON = {
  home:svg('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>'),
  rent:svg('<circle cx="12" cy="12" r="9"/><path d="M15.500 9a3.500 3.500 0 1 0 0 6M8 11h6M8 13.500h6"/>'),
  add:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  month:svg('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 15l2.500 2.500L16 13"/>'),
  cmp:svg('<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11.500h1M12 11.500h1M16 11.500h0M8 15.500h1M12 15.500h1M16 15.500h0"/>'),
  bld:svg('<path d="M5 21V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v17M15 9h3a1 1 0 0 1 1 1v11M3 21h18M9 7h2M9 11h2M9 15h2"/>'),
  chart:svg('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
  set:svg('<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14.2 3h-4l-.4 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9c.6.5 1.3.9 2 1.2l.4 2.6h4l.4-2.6c.7-.3 1.4-.7 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z"/>'),
  face:svg('<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2M9 10v1.500M15 10v1.500M12 10v3.500h-1M9 16c1.800 1.300 4.200 1.300 6 0"/>'),
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>'
};
function renderTabs(){
  const T = [["home","Accueil"],["cmp","Compta"],["add","Ajouter"],["month","Pointage"],["bld","Biens"],["rent","Location"],["chart","Bilan"]];
  $("#tabs .in").innerHTML = T.map(([k,l]) => k === "add"
    ? `<button class="add ${V.tab===k?"on":""}" data-act="tab" data-v="${k}" aria-label="${l}"><span class="pl">${ICON[k]}</span><span>${l}</span></button>`
    : `<button class="${V.tab===k?"on":""}" data-act="tab" data-v="${k}">${ICON[k]}<span>${l}</span></button>`).join("");
}
const yearNav = () => `<div class="nav"><button data-act="yprev" aria-label="Année précédente">‹</button><span>${V.y}</span><button data-act="ynext" aria-label="Année suivante">›</button></div>`;
const monthNav = () => `<div class="nav"><button data-act="mprev" aria-label="Mois précédent">‹</button><span>${MOIS[V.m]} ${V.y}</span><button data-act="mnext" aria-label="Mois suivant">›</button></div>`;
function topbar(title, nav){
  return `<div class="top"><div class="app">${title}</div><div class="topr">${nav || ""}<button class="q" data-act="help" aria-label="Aide">?</button><button class="gear" data-act="tab" data-v="set" aria-label="Réglages">${ICON.set}</button></div></div>` +
    (S.demo ? `<div class="banner">Données d'exemple. Importe le fichier <b>export_appli.xlsx</b> dans <b>Réglages</b> pour travailler avec tes vrais biens.</div>` : "");
}
const kv = (l, v, cl) => `<div class="kv"><span>${l}</span><span class="num ${cl || ""}">${v}</span></div>`;
const signCl = v => v < 0 ? "neg" : "";
function bienSeg(act, sel, withAll){
  return `<div class="seg">${withAll ? `<button class="${sel==="all"?"on":""}" data-act="${act}" data-v="all">Tous</button>` : ""}${bienIds().map(id => `<button class="${sel===id?"on":""}" data-act="${act}" data-v="${esc(id)}">${esc(bienName(id))}</button>`).join("")}</div>`;
}
const chipJ = (j, st) => st === "À pointer" ? `<span class="chip warn">${isIn(j) ? "À recevoir" : "Non pointé"}</span>` : chipFor(st);
const chipFor = st => `<span class="chip ${st==="En retard"?"bad":st==="À pointer"?"warn":st==="Pointé"?"ok":""}">${st}</span>`;
function jRow(j, showBien){
  const st = statut(j), sign = isIn(j) ? 1 : -1;
  return `<div class="row"><button class="chk ${j.pointe==="x"?"on":""}" data-act="jtoggle" data-id="${j.id}" aria-label="Pointer">${ICON.check}</button>
    <button class="rowbtn" data-act="jedit" data-id="${j.id}"><div class="t">${esc(j.lib || j.cat || j.type)}</div>
    <div class="s">${frDate(j.date)}${showBien ? " " + bienPill(j.bien) : ""} · <span class="cdot" style="background:${catColor(j.cat)};margin-right:4px"></span>${esc(j.cat || TYPE_LAB[j.type] || j.type)}${j.compte==="Perso" ? " · perso" : ""} ${st !== "Pointé" ? chipJ(j, st) : ""}</div></button>
    <div class="amt num ${sign>0?"pos":""}">${sign>0?"+":"−"} ${eur(j.montant)}</div></div>`;
}

/* ---------- Accueil ---------- */
function viewHome(){
  const y = now0.getFullYear(), ids = bienIds(), c = counts(y), st = stats(null, y);
  const tot = r2(sum(ids.map(id => soldeBien(id))));
  const next = J().filter(j => statut(j) === "Prévu").sort((a,b) => a.date.localeCompare(b.date)).slice(0, 6);
  const tileLate = n => { const l = J().filter(j => statut(j) === "En retard" && j.cat === "Loyer").sort((a, b) => a.date.localeCompare(b.date))[0]; return `<button class="tile ${n ? "bad" : ""}" data-act="go" data-v="bld" data-sub="loyers" data-bien="${l ? esc(l.bien) : ""}"><span class="n">${n}</span><span class="l">loyer(s) en retard</span></button>`; };
  const tile = (n, l, cl, to, f) => `<button class="tile ${n ? cl : ""}" data-act="go" data-v="${to}" data-f="${f || ""}"><span class="n">${n}</span><span class="l">${l}</span></button>`;
  return topbar("Gestion Locative Facile") + `
  <div class="card hero"><div class="lbl">Solde de mes comptes appartements</div><div class="big num">${eur(tot)}</div>
    <div class="glass">${ids.map(id => { const p = placeOf(id), on = bourseOn(), parts = on ? PLACE_CATS.filter(c => p.by[c]).map(c => (c === "Bourse" ? "bourse" : c) + " " + eur(p.by[c])).concat(p.interets ? ["intérêts " + eur(p.interets)] : []) : [];
      return kv(bienPill(id), eur(soldeBien(id)), "") + (parts.length ? `<div class="small" style="opacity:.85;text-align:right;margin:-4px 0 6px">(${parts.join(" + ")}) · total ${eur(r2(soldeBien(id) + p.total))}</div>` : ""); }).join("")}
      <div class="small" style="opacity:.85;text-align:right;margin-top:4px">Total tous biens confondus${bourseOn() ? " (comptes + placé)" : ""} : <b>${eur(r2(tot + (bourseOn() ? placeOf(null).total : 0)))}</b></div></div></div>
  ${matelasHome()}${bourseCard()}${placeCard(null)}
  <div class="tiles">${tileLate(c.retard)}${tile(c.pointer,"à pointer","warn","month","todo")}${tile(c.compta,"à saisir en compta","warn","month","compta")}</div>
  <div class="card"><h2>Bénéfice ${y}</h2>
    ${kv("Recettes encaissées", eur(st.recP))}${kv("Dépenses payées", "− " + eur(st.depP))}
    <div class="kv tot"><span>Bénéfice réalisé</span><span class="num ${signCl(st.benef)}">${eur(st.benef)}</span></div>
    ${kv("Bénéfice prévu sur l'année", eur(st.cf), "muted")}</div>
  <div class="card"><h2>Prochaines échéances</h2><div class="rows">${next.length ? next.map(j => `<div class="row"><div class="main"><div class="t">${esc(j.lib || j.cat)}</div><div class="s">${frDate(j.date)} · ${esc(bienName(j.bien))}</div></div><div class="amt num ${isIn(j)?"pos":""}">${isIn(j)?"+":"−"} ${eur(j.montant)}</div></div>`).join("") : '<div class="empty">Rien de prévu.</div>'}</div></div>`;
}

function bourseCard(){
  const ids = bienIds(), ty = usedTypes(null); if (!bourseOn() || !ty.length) return "";
  const t = placeOf(null);
  return `<div class="card bourse"><div class="lbl">${titleTypes(ty)}, pas dépensé</div><div class="big num">${eur(t.net)}</div><div class="small" style="opacity:.9">total à récupérer sur les comptes appartements</div>
    ${ty.length > 1 ? `<div class="small" style="opacity:.9">${ty.map(c => c + " " + eur(t.by[c])).join(" · ")}</div>` : ""}
    ${ids.map(id => { const p = placeOf(id); return usedTypes(id).length ? `<div class="kv">${bienPill(id)}<span class="num">${eur(p.net)}</span></div>` : ""; }).join("")}
    <div class="btns"><button class="btn sm" data-act="bourse" data-v="">Remboursement bourse</button></div></div>`;
}

/* ---------- Loyers (dans Biens, bien par bien) ---------- */
function loyerLines(bien, y){ return J().filter(j => j.bien === bien && j.type === "Recette" && j.cat === "Loyer" && yr(j) === y); }
function viewBienLoyers(){
  const id = V.bsel, y = V.y;
  const late = J().filter(j => j.bien === id && statut(j) === "En retard" && j.cat === "Loyer").sort((a, b) => a.date.localeCompare(b.date));
  const lateHtml = late.length ? `<div class="card" style="border-color:var(--bad)"><h2>À relancer</h2><div class="rows">${late.map(j => `<div class="row"><div class="main"><div class="t">${MOIS[mo(j)].toLowerCase()} ${yr(j)}</div>
    <div class="s">${eur(j.montant)} · ${(() => { const t = tenantFor(j.bien, j.date); return t ? esc(t.nom) : "locataire non renseigné"; })()}</div></div>
    <button class="btn sm" data-act="relance" data-id="${j.id}">Relancer</button></div>`).join("")}</div></div>` : "";
  const L = loyerLines(id, y), att = sum(L.map(j => j.montant)), rec = sum(L.filter(j => j.pointe === "x").map(j => j.montant));
  const p = att > 0 ? Math.min(100, Math.round(rec / att * 100)) : 0;
  const rows = MOIS.map((nm, m) => {
    const ls = L.filter(j => mo(j) === m).sort((a, b) => a.date.localeCompare(b.date));
    if (!ls.length) return `<div class="row"><span class="chk" style="border-style:dashed"></span><div class="main"><div class="t muted">${nm}</div><div class="s">Aucun loyer prévu</div></div><button class="mini" data-act="rent-add" data-bien="${esc(id)}" data-m="${m}">Ajouter</button></div>`;
    return ls.map(j => { const s = statut(j);
      return `<div class="row"><button class="chk ${j.pointe==="x"?"on":""}" data-act="jtoggle" data-id="${j.id}" aria-label="Loyer encaissé">${ICON.check}</button>
      <button class="rowbtn" data-act="jedit" data-id="${j.id}"><div class="t">${nm}</div><div class="s">${esc(j.lib || "")} ${s !== "Pointé" ? chipJ(j, s) : '<span class="chip ok">Encaissé</span>'}</div></button><div class="amt num">${eur(j.montant)}</div>${j.pointe === "x" ? `<button class="mini" data-act="quit" data-id="${j.id}">Quittance</button>` : ""}</div>`; }).join("");
  }).join("");
  return lateHtml + `<div class="card"><div class="top"><h2>Loyers ${y}</h2><span class="muted small num">${eur(rec)} / ${eur(att)}</span></div>
    <div class="bar"><i class="${rec >= att && att > 0 ? "ok" : ""}" style="width:${p}%"></i></div><div class="rows">${rows}</div></div>`;
}

/* ---------- Pointage (mois) ---------- */
function monthListAll(){
  let L = J();
  if (V.bf !== "all") L = L.filter(j => j.bien === V.bf);
  if (V.mf === "todo") return L.filter(j => statut(j) === "À pointer" || statut(j) === "En retard");
  if (V.mf === "compta") return L.filter(j => j.type === "Dépense" && j.pointe === "x" && !j.compta);
  return L.filter(j => yr(j) === V.y && mo(j) === V.m);
}
function monthList(){ return monthListAll().filter(j => !isArch(j)); }
function viewMonth(){
  const L = monthList().sort((a,b) => b.date.localeCompare(a.date) || (b.upd||0) - (a.upd||0));
  const todo = L.filter(j => j.pointe !== "x" && j.date <= todayIso());
  const LA = monthListAll(), na = LA.length - L.length;
  const rec = sum(LA.filter(j => j.type === "Recette").map(j => j.montant)), dep = sum(LA.filter(j => j.type === "Dépense").map(j => j.montant));
  const mseg = `<div class="seg"><button class="${V.mf==="mois"?"on":""}" data-act="mf" data-v="mois">Ce mois</button><button class="${V.mf==="todo"?"on":""}" data-act="mf" data-v="todo">À pointer</button><button class="${V.mf==="compta"?"on":""}" data-act="mf" data-v="compta">À saisir en compta</button></div>`;
  const summary = V.mf === "mois" ? `<div class="card"><h2>Bilan du mois</h2>${kv("Recettes", eur(rec))}${kv("Dépenses", "− " + eur(dep))}<div class="kv tot"><span>Résultat</span><span class="num ${signCl(rec-dep)}">${eur(rec - dep)}</span></div></div>` : "";
  const help = V.mf === "compta" ? `<div class="small muted">Dépenses déjà payées mais pas encore saisies sur ton site de compta. Touche la ligne, puis « Saisi en compta ».</div>` : "";
  return topbar("Pointage", V.mf === "mois" ? monthNav() : "") + mseg + bienSeg("bf", V.bf, true) + monthActions() + summary + `
  <div class="card"><div class="top"><h2>${V.mf==="mois" ? "Opérations" : V.mf==="todo" ? "À pointer" : "À saisir en compta"} (${L.length})</h2>
    ${V.mf !== "compta" && todo.length ? `<button class="btn sm" data-act="pointall">Tout pointer (${todo.length})</button>` : ""}</div>${help}${na ? `<div class="small muted">${na} ligne(s) archivée(s) masquée(s) · <button class="mini" data-act="arch-view">Voir</button></div>` : ""}
    <div class="rows">${L.length ? L.map(j => jRow(j, V.bf === "all")).join("") : '<div class="empty">Rien ici.</div>'}</div></div>`;
}

/* ---------- Ajouter / modifier ---------- */
function newDraft(extra){
  const bs = bienIds();
  return Object.assign({type:"Recette", bien:bs[0] || "", date:todayIso(), cat:"Loyer", lib:"", mont:"", montAuto:true, compte:"Bien", pt:true, fourn:"", note:"", compta:false, justif:false}, extra || {});
}
function draftFrom(j){ return {type:j.type, bien:j.bien, date:j.date, cat:j.cat, lib:j.lib, mont:fmtNum(j.montant), montAuto:false, compte:j.compte || "Bien", pt:j.pointe === "x", fourn:j.fourn, note:j.note, compta:!!j.compta, justif:j.justif === "x"}; }
function viewAdd(){
  const ed = V.editId ? S.journal.find(j => j.id === V.editId) : null;
  const d = V.draft || (ed ? draftFrom(ed) : newDraft()); V.draft = d;
  const cats = allCats(d.type);
  const bs = bienIds();
  return `<div class="top"><button class="btn ghost sm" data-act="tab" data-v="${ed ? (V.back || "month") : "home"}">${ed ? "‹ Retour" : "‹ Accueil"}</button><button class="q" data-act="help" aria-label="Aide">?</button></div>
  <div class="top"><div class="app">${ed ? "Modifier l'opération" : "Ajouter une opération"}</div></div>
  <div class="card">
    ${modelesRow(ed)}
    <div class="seg">${TYPES.map(t => `<button class="${d.type===t?"on":""}" data-act="dtype" data-v="${t}">${TYPE_LAB[t]}</button>`).join("")}</div>
    <div class="seg">${bs.map(id => `<button class="${d.bien===id?"on":""}" data-act="dbien" data-v="${esc(id)}">${esc(bienName(id))}</button>`).join("")}${!ed && bs.length === 2 ? `<button class="${d.bien==="both"?"on":""}" data-act="dbien" data-v="both">Les 2 (50/50)</button>` : ""}</div>
    <label class="f">Date<input id="f-date" type="date" value="${esc(d.date)}"></label>
    <div class="amtbox"><small>Montant (€)</small><input class="amt-in" id="f-mont" inputmode="none" autocomplete="off" value="${esc(d.mont)}" placeholder="0,00"></div>
    ${npadHtml("f-mont")}
    <label class="f">Catégorie<select id="f-cat"><option value="" ${d.cat===""?"selected":""}>—</option>${cats.map(o => `<option ${o===d.cat?"selected":""}>${esc(o)}</option>`).join("")}</select></label>
    <label class="f">Libellé<input id="f-lib" value="${esc(d.lib)}" placeholder="Facultatif (vide = catégorie)"></label>
    ${d.type === "Dépense" ? `<div><div class="small muted" style="margin-bottom:4px">Payé depuis</div><div class="seg"><button class="${d.compte!=="Perso"?"on":""}" data-act="dcompte" data-v="Bien">Compte du bien</button><button class="${d.compte==="Perso"?"on":""}" data-act="dcompte" data-v="Perso">Compte perso</button></div></div>` : ""}
    <label class="f">Fournisseur / N° de facture<input id="f-fourn" value="${esc(d.fourn)}"></label>
    <label class="f">Note<input id="f-note" value="${esc(d.note)}"></label>
    <div class="seg"><button class="${d.pt?"on":""}" data-act="dtog" data-v="pt">${d.type==="Recette" ? "Encaissé" : "Pointé (passé sur le compte)"}</button>
      ${d.type === "Dépense" ? `<button class="${d.compta?"on":""}" data-act="dtog" data-v="compta">Saisi en compta</button><button class="${d.justif?"on":""}" data-act="dtog" data-v="justif">Justificatif</button>` : ""}</div>
    <div id="f-info"></div>
    <div class="btns"><button class="btn" data-act="save" style="flex:1">Enregistrer</button>
      ${ed ? `<button class="btn ghost" data-act="jdup">Dupliquer</button><button class="btn danger" data-act="jdel">Supprimer</button>` : `<button class="btn ghost" data-act="clear">Effacer</button><button class="btn ghost" data-act="md-open">Enregistrer comme modèle</button>`}</div>
  </div>`;
}
function collectDraft(){
  const d = V.draft; if (!d || V.tab !== "add") return;
  const g = id => { const el = document.getElementById(id); return el ? el.value : null; };
  for (const [id, k] of [["f-date","date"],["f-mont","mont"],["f-cat","cat"],["f-lib","lib"],["f-fourn","fourn"],["f-note","note"]]){ const v = g(id); if (v !== null) d[k] = v; }
}
function autoSuggest(force){
  const d = V.draft; if (!d || d.type === "Sortie" || d.type === "Entrée" || V.editId) return;
  if (!(force || d.montAuto || !parseNum(d.mont))) return;
  const s = suggest(d.bien, d.cat, d.date);
  const el = $("#f-mont"); if (!el) return;
  if (s != null && d.bien !== "both"){ d.mont = fmtNum(s); d.montAuto = true; el.value = d.mont; }
  else if (d.montAuto){ d.mont = ""; el.value = ""; }
}
function prevuMatch(d){
  if (d.type !== "Recette" || d.cat !== "Loyer" || V.editId || d.bien === "both" || !d.date) return null;
  return J().find(j => j.bien === d.bien && j.type === "Recette" && j.cat === "Loyer" && j.pointe !== "x" && yr(j) === +d.date.slice(0,4) && mo(j) === +d.date.slice(5,7) - 1) || null;
}
function updateInfo(){
  const el = $("#f-info"); if (!el || !V.draft) return; collectDraft(); const d = V.draft; const mt = parseNum(d.mont);
  const pm = prevuMatch(d), tv = d.bien !== "both" && POSTES_TARIF.includes(d.cat) ? tarifVigueur(d.bien, d.cat) : null;
  const tinfo = tv ? `<div class="info">Tarif en vigueur : ${eur(tv.montant)} depuis le ${frDate(tv.date)}.</div>` : "";
  el.innerHTML = tinfo + (pm ? `<div class="info">Un loyer de ${eur(pm.montant)} est déjà prévu pour ${MOIS[mo(pm)].toLowerCase()} : il sera mis à jour au lieu d'être ajouté en double.</div>`
    : (d.bien === "both" && mt ? `<div class="info">${bienName(bienIds()[0])} ${eur(splitPartage(mt, 0.5)[0])} · ${bienName(bienIds()[1])} ${eur(splitPartage(mt, 0.5)[1])}.</div>` : ""));
}
function saveOp(){
  collectDraft(); const d = V.draft, mt = parseNum(d.mont), ed = V.editId ? S.journal.find(j => j.id === V.editId) : null;
  if (!d.bien) return toast("Choisis un bien");
  if (!d.date) return toast("Choisis une date");
  if (!mt || mt <= 0) return toast("Saisis un montant supérieur à 0");
  const lib = d.lib.trim() || (d.cat === "Loyer" ? "Loyer " + MOIS[+d.date.slice(5,7)-1].toLowerCase() : d.cat);
  const base = {date:d.date, type:d.type, cat:d.cat, lib, montant:r2(mt), compte:d.type === "Dépense" ? d.compte : (d.cat === "Intérêts placement" ? "Perso" : "Bien"), pointe:d.pt ? "x" : "",
    compta:d.type === "Dépense" && d.compta ? ((ed && ed.compta) || "x") : "", justif:d.type === "Dépense" && d.justif ? "x" : "", fourn:d.fourn.trim(), note:d.note.trim(), upd:Date.now()};
  if (ed){ Object.assign(ed, base, {bien:d.bien}); toast("Opération modifiée"); }
  else if (d.bien === "both"){
    const ids = bienIds().slice(0, 2), h = r2(mt / 2);
    ids.forEach((id, i) => S.journal.push(Object.assign({id:uid(), bien:id}, base, {montant:i ? r2(mt - h) : h})));
    toast("Enregistré sur les 2 biens");
  } else {
    const pm = prevuMatch(d);
    if (pm){ Object.assign(pm, base, {bien:d.bien, lib:pm.lib || lib}); toast("Loyer mis à jour : " + eur(base.montant)); }
    else { S.journal.push(Object.assign({id:uid(), bien:d.bien}, base)); toast("Enregistré : " + eur(base.montant)); }
  }
  V.m = +d.date.slice(5,7) - 1; V.y = +d.date.slice(0,4); V.mf = "mois"; V.bf = "all";
  V.editId = null; V.draft = null; archivePass(false); persist(); V.tab = V.back || "month"; V.back = null; render();
}

/* ---------- Biens ---------- */
function tenantCard(id){
  const t = tenantFor(id, todayIso()), ended = t && t.fin && t.fin < todayIso();
  return `<div class="card" style="padding:12px 16px;gap:4px"><div class="top"><span class="small muted">Locataire actuel</span>${t ? `<button class="mini" data-act="ledit" data-id="${t.id}">Fiche</button>` : `<button class="mini" data-act="lnew">Ajouter</button>`}</div>
    ${t ? `<div class="t" style="font-weight:600;font-size:16px">${esc(t.nom)}${ended ? ' <span class="chip warn">bail terminé</span>' : ""}</div>
      <div class="small muted">Bail depuis le ${t.debut ? frDate(t.debut) : "?"}${t.fin ? " jusqu'au " + frDate(t.fin) : ""} · loyer ${eur(t.loyer)}${t.charges ? " dont charges " + eur(t.charges) : ""}</div>${soldeLine(id)}
      <div class="btns" style="gap:6px">${t.tel ? `<a class="mini" href="tel:${esc(t.tel)}">Appeler</a><a class="mini" href="sms:${esc(t.tel)}">SMS</a>` : ""}${t.email ? `<a class="mini" href="mailto:${esc(t.email)}">E-mail</a>` : ""}</div>`
    : '<div class="small muted">Aucun locataire enregistré pour ce bien.</div>'}</div>`;
}
function viewBiens(){
  const subs = [["vue","Vue"],["loyers","Loyers"],["dep","Dépenses"],["travaux","Travaux"],["loc","Locataires"],["mvt","Arrivée/Départ"],["docs","Documents"],["tarifs","Tarifs"],["rapp","Rapprochement"]], ids = bienIds();
  if (!subs.some(x => x[0] === V.bsub)) V.bsub = "vue";
  const sub = V.bsub; if (!V.bsel || !ids.includes(V.bsel)) V.bsel = ids[0] || "";
  const seg = `<div class="seg">${subs.map(([k,l]) => `<button class="${sub===k?"on":""}" data-act="bsub" data-v="${k}">${l}</button>`).join("")}</div>`;
  const nav = sub === "vue" || sub === "loyers" || sub === "dep" ? yearNav() : "";
  const sel = ["vue","loyers","dep","loc","mvt","docs"].includes(sub) ? bienSeg("bsel", V.bsel, false) + tenantCard(V.bsel) : "";
  let body = "";
  if (sub === "vue") body = viewBienVue(); else if (sub === "loyers") body = viewBienLoyers(); else if (sub === "dep") body = viewBienDep(); else if (sub === "travaux") body = viewTravaux(); else if (sub === "tarifs") body = viewTarifs(); else if (sub === "rapp") body = viewRapp(); else if (sub === "docs") body = viewDocs(); else if (sub === "mvt") body = viewMvt(); else body = viewLoc();
  return topbar("Biens", nav) + seg + sel + body;
}
function catBars(rows, max, restKey){
  return rows.map(r => `<div class="env" style="padding:6px 0;--c:${catColor(r.n)}"><div class="top"><span><span class="cdot" style="background:${catColor(r.n)}"></span>${esc(r.n)}</span><span class="num">${eur(r.v)}${r.reste > 0.005 ? ` <span class="chip warn">reste ${eur(r.reste)}</span>` : ""}</span></div><div class="bar"><i style="width:${max > 0 ? Math.round(r.v / max * 100) : 0}%"></i></div></div>`).join("");
}
function viewBienVue(){
  const id = V.bsel, y = V.y, s = stats(id, y), b = S.biens.find(x => x.id === id);
  const L = J().filter(j => j.bien === id && yr(j) === y && j.type === "Dépense"), cats = {};
  for (const j of L){ const c = cats[j.cat || "Autre"] || (cats[j.cat || "Autre"] = {n:j.cat || "Autre", v:0, reste:0}); c.v += j.montant; if (j.pointe !== "x") c.reste += j.montant; }
  const rows = Object.values(cats).sort((a,b) => b.v - a.v);
  const ops = J().filter(j => j.bien === id && yr(j) === y).sort((a,b) => b.date.localeCompare(a.date));
  const t = live(S.locataires).filter(x => x.bien === id);
  return `
  <div class="card"><div class="top"><h2>${bienPill(id)} ${y}</h2></div>
    ${kv("Solde du compte au 1er janvier", eur(soldeAvant(id, y)))}${kv("Loyers (encaissés + prévus)", eur(s.rec))}${kv("Charges (payées + prévues)", "− " + eur(s.dep))}
    <div class="kv tot"><span>Cash flow</span><span class="num ${signCl(s.cf)}">${eur(s.cf)}</span></div>
    ${kv("Solde du compte au 31/12", eur(soldeBien(id, y)))}
    ${b ? `<div class="small muted">${b.adresse ? esc(b.adresse) + " · " : ""}Loyer ${eur(b.loyer)} · crédit ${eur(b.credit)}/mois${b.regime ? " · " + esc(b.regime) : ""}${t.length ? " · locataire : " + esc(t[t.length-1].nom) : ""}</div>` : ""}</div>
  ${matelasCard(id)}
  ${(() => { const ty = usedTypes(id); if (!bourseOn() || !ty.length) return ""; return `<div class="card" style="border-color:${BOURSE_COL}"><div class="top"><h2 style="color:${BOURSE_COL}">${titleTypes(ty)}</h2><button class="btn sm" style="background:${BOURSE_COL}" data-act="bourse" data-v="${esc(id)}">Remboursement</button></div>${ty.map(c => { const b = bourseOf(id, c); return (ty.length > 1 ? `<div class="small muted" style="margin-top:6px"><b>${c}</b></div>` : "") + kv(c === "Bourse" ? "Mis en bourse" : "Mis sur " + c, eur(b.mis)) + kv("Remboursé", eur(b.remb)) + `<div class="kv tot"><span>Reste à rembourser</span><span class="num" style="color:${BOURSE_COL}">${eur(b.reste)}</span></div>`; }).join("")}</div>`; })()}
  ${placeCard(id)}
  <div class="btns"><button class="btn ghost sm" data-act="bn-edit" data-id="${esc(id)}">Modifier le bien</button><button class="btn ghost sm" data-act="bn-new">Ajouter un bien</button></div>
  <div class="card"><h2>Charges par catégorie</h2>${rows.length ? catBars(rows, rows[0].v) : '<div class="empty">Aucune dépense cette année.</div>'}</div>
  <div class="card"><details><summary><span>Toutes les opérations (${ops.length})</span><span class="muted small">voir</span></summary><div class="rows" style="margin-top:6px">${ops.map(j => jRow(j, false)).join("")}</div></details></div>`;
}
function partagesCard(){
  return `<div class="card"><h2>Frais partagés entre les 2 comptes</h2><div class="small muted">Saisis le total une seule fois : l'appli crée une ligne par compte (part Studio arrondie, T2 = le reste).</div>
    <div class="rows">${partagesList().map(p => { const [a, b] = splitPartage(p.total, p.partStudio);
      return `<div class="row"><div class="main"><div class="t">${esc(p.frais)}</div><div class="s">Total ${eur(p.total)} · Studio ${Math.round(p.partStudio*100)} % (${eur(a)}) · T2 ${eur(b)}</div></div><button class="mini" data-act="partage" data-v="${esc(p.frais)}">Saisir</button></div>`; }).join("")}</div></div>`;
}
function viewBienDep(){
  const id = V.bsel, y = V.y, L = J().filter(j => j.bien === id && yr(j) === y && j.type === "Dépense"), cats = {};
  for (const j of L){ const k = j.cat || "Autre"; const c = cats[k] || (cats[k] = {n:k, v:0, reste:0}); c.v += j.montant; if (j.pointe !== "x") c.reste += j.montant; }
  const rows = Object.values(cats).sort((a, b) => b.v - a.v), total = sum(rows.map(r => r.v)), reste = sum(rows.map(r => r.reste));
  const next = J().filter(j => j.bien === id && statut(j) === "Prévu" && j.type === "Dépense").sort((a, b) => a.date.localeCompare(b.date)).slice(0, 8);
  const all = L.slice().sort((a, b) => b.date.localeCompare(a.date));
  return partagesCard() + `<div class="card"><h2>Dépenses ${esc(bienName(id))} ${y}</h2>${catBars(rows, rows.length ? rows[0].v : 0)}${rows.length ? "" : '<div class="empty">Aucune dépense cette année.</div>'}
    <div class="kv tot"><span>Total</span><span class="num">${eur(total)}</span></div>${kv("dont reste à payer", eur(reste), "muted")}</div>
  <div class="card"><h2>Prochaines dépenses</h2><div class="rows">${next.length ? next.map(j => `<div class="row"><div class="main"><div class="t">${esc(j.lib || j.cat)}</div><div class="s">${frDate(j.date)}</div></div><div class="amt num">${eur(j.montant)}</div></div>`).join("") : '<div class="empty">Rien de prévu.</div>'}</div></div>
  <div class="card"><details><summary><span>Toutes les dépenses (${all.length})</span><span class="muted small">voir</span></summary><div class="rows" style="margin-top:6px">${all.map(j => jRow(j, false)).join("")}</div></details></div>`;
}
function travList(){
  const q = V.fq.trim().toLowerCase();
  const F = live(S.factures).filter(f => !q || (f.fourn + " " + f.desc + " " + f.cat + " " + f.num).toLowerCase().includes(q)).sort((a,b) => (b.date || "").localeCompare(a.date || ""));
  const chip = (f, k, lab) => `<button class="mini ${f[k]==="x"?"on":""}" data-act="ftog" data-id="${f.id}" data-k="${k}">${lab}</button>`;
  return F.length ? F.map(f => `<div class="row" style="align-items:flex-start"><button class="rowbtn" data-act="fedit" data-id="${f.id}"><div class="t">${esc(f.fourn)} · ${esc(f.desc)}</div>
    <div class="s">${f.date ? frDateL(f.date) : "date ?"} · ${esc(f.cat)}${f.num ? " · n° " + esc(f.num) : ""}</div></button>
    <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end"><div class="amt num">${eur(f.prix)}</div><div class="btns" style="gap:4px">${chip(f,"scan","Scanné")}${chip(f,"jdmm","Compta")}</div></div></div>`).join("") : '<div class="empty">Aucune facture.</div>';
}
function viewTravaux(){
  const all = live(S.factures);
  return `<div class="card"><div class="top"><h2>Factures travaux</h2><button class="btn sm" data-act="fnew">Ajouter</button></div>
    ${kv(all.length + " facture(s)", eur(sum(all.map(f => f.prix))))}${kv("Non scannées", String(all.filter(f => f.scan !== "x").length), "muted")}${kv("Non enregistrées en compta", String(all.filter(f => f.jdmm !== "x").length), "muted")}
    <input class="search" id="fq" placeholder="Rechercher (fournisseur, description…)" value="${esc(V.fq)}"></div>
  <div class="card"><div class="rows" id="flist">${travList()}</div></div>`;
}
function viewLoc(){
  const L = live(S.locataires);
  const soon = t => t.fin && t.fin >= todayIso() && t.fin <= new Date(Date.now() + 90 * 864e5).toISOString().slice(0,10);
  return `<div class="card"><div class="top"><h2>Locataires</h2><button class="btn sm" data-act="lnew">Ajouter</button></div>
    <div class="small muted">Ces fiches sont stockées dans l'appli (chiffrées si le verrouillage est activé) et dans la feuille « Locataires » de ton classeur.</div></div>` +
    ([V.bsel].map(id => { const T = L.filter(t => t.bien === id);
      return `<div class="card"><h2>${esc(bienName(id))}</h2>${T.length ? T.map(t => `<div class="env" style="padding:8px 0;gap:6px"><div class="top"><button class="rowbtn" data-act="ledit" data-id="${t.id}"><div class="t" style="font-weight:600">${esc(t.nom)}</div>
        <div class="s">Bail ${t.debut ? frDateL(t.debut) : "?"} → ${t.fin ? frDateL(t.fin) : "en cours"} ${soon(t) ? '<span class="chip warn">fin proche</span>' : ""}</div>
        <div class="s">Loyer ${eur(t.loyer)}${t.charges ? " dont charges " + eur(t.charges) : ""} · dépôt de garantie ${eur(t.depot)}</div>${t.note ? `<div class="s">${esc(t.note)}</div>` : ""}</button></div>
        <div class="btns">${t.tel ? `<a class="mini" href="tel:${esc(t.tel)}">Appeler</a><a class="mini" href="sms:${esc(t.tel)}">SMS</a>` : ""}${t.email ? `<a class="mini" href="mailto:${esc(t.email)}">E-mail</a>` : ""}</div></div>`).join("") : '<div class="empty">Aucun locataire.</div>'}</div>`; }).join(""));
}
function viewTarifs(){
  const ids = bienIds(), hist = S.tarifs.slice().sort((a,b) => b.date.localeCompare(a.date));
  return `<div class="card"><div class="top"><h2>Tarifs en vigueur</h2><button class="btn sm" data-act="tarif-new">Nouveau tarif</button></div>
    <div class="small muted">Un changement de montant = une nouvelle ligne. L'historique n'est jamais modifié.</div>
    ${ids.map(id => `<div class="env" style="padding:6px 0">${bienPill(id)}${POSTES_TARIF.map(p => { const t = tarifVigueur(id, p); return kv(esc(p), t ? eur(t.montant) + ` <span class="muted small">depuis le ${frDate(t.date)}</span>` : "—"); }).join("")}</div>`).join("")}</div>
  <div class="card"><h2>Historique</h2><div class="rows">${hist.length ? hist.map(t => `<div class="row"><div class="main"><div class="t">${bienPill(t.bien)} ${esc(t.poste)}</div><div class="s">à partir du ${frDate(t.date)}${t.note ? " · " + esc(t.note) : ""}${t.app ? " · ajouté ici" : ""}</div></div><div class="amt num">${eur(t.montant)}</div></div>`).join("") : '<div class="empty">Aucun tarif.</div>'}</div></div>`;
}
function viewRapp(){
  const ids = bienIds(), hist = J().filter(j => j.cat === "Écart de rapprochement").sort((a,b) => b.date.localeCompare(a.date));
  return `<div class="card"><h2>Comparer avec le relevé de banque</h2><div class="small muted">Saisis le solde réel du relevé. Si l'écart n'est pas nul, enregistre l'ajustement : une ligne datée est ajoutée au Journal (elle compte dans le solde, pas dans le bénéfice).</div>
    ${ids.map(id => { const calc = soldeBien(id), reel = (S.rapp || {})[id], has = reel !== undefined && reel !== "" && reel !== null, ec = has ? r2(reel - calc) : null;
      return `<div class="env" style="padding:8px 0;gap:6px"><div class="top">${bienPill(id)}<span class="num">${eur(calc)}</span></div><div class="small muted">Solde calculé</div>
        <label class="f">Solde réel du relevé (€)<input id="rp-${esc(id)}" data-bien="${esc(id)}" inputmode="decimal" value="${has ? fmtNum(reel) : ""}" placeholder="0,00"></label>
        ${has ? `<div class="kv"><span>Écart (réel − calculé)</span><span class="num ${ec ? (ec < 0 ? "neg" : "pos") : ""}">${eur(ec)}</span></div>${ec ? `<button class="btn" data-act="rapp-save" data-v="${esc(id)}">Enregistrer l'ajustement de ${eur(Math.abs(ec))}</button>` : `<div class="info">Le solde est juste.</div>`}` : ""}</div>`; }).join("")}</div>
  <div class="card"><h2>Historique des ajustements</h2><div class="rows">${hist.length ? hist.map(j => `<div class="row"><div class="main"><div class="t">${esc(j.lib)}</div><div class="s">${frDate(j.date)} ${bienPill(j.bien)}${j.note ? " · " + esc(j.note) : ""}</div></div><div class="amt num ${isIn(j) ? "pos" : "neg"}">${isIn(j) ? "+" : "−"} ${eur(j.montant)}</div></div>`).join("") : '<div class="empty">Aucun ajustement.</div>'}</div></div>`;
}
function sheetBourse(bien){
  const ids = bienIds(), d = V.bs = Object.assign({bien:ids[0] || "", mont:"", date:todayIso(), confirm:false}, V.bs && V.bs.keep ? V.bs : {}, bien ? {bien} : {});
  const tys = usedTypes(d.bien).length ? usedTypes(d.bien) : ["Bourse"]; if (!d.cat || !tys.includes(d.cat)) d.cat = tys.find(c => bourseOf(d.bien, c).reste > 0) || tys[0];
  const b = bourseOf(d.bien, d.cat), mt = parseNum(d.mont), over = mt && mt > b.reste + 0.005;
  openSheet(`<h2 style="color:${BOURSE_COL}">Remboursement ${d.cat === "Bourse" ? "bourse" : esc(d.cat)}</h2>
    <div class="seg">${ids.map(id => `<button class="${d.bien===id?"on":""}" data-act="bs-bien" data-v="${esc(id)}">${esc(bienName(id))}</button>`).join("")}</div>
    ${tys.length > 1 ? `<div class="seg">${tys.map(c => `<button class="${d.cat===c?"on":""}" data-act="bs-cat" data-v="${esc(c)}">${esc(c)}</button>`).join("")}</div>` : ""}
    <div class="small muted">Mis de côté ${eur(b.mis)} · remboursé ${eur(b.remb)} · reste à rembourser <b>${eur(b.reste)}</b></div>
    <div class="grid2"><label class="f">Montant (€)<input id="b-mont" inputmode="none" value="${esc(d.mont)}"></label><label class="f">Date<input id="b-date" type="date" value="${esc(d.date)}"></label></div>${npadHtml("b-mont")}
    ${over ? `<div class="info bad">Ce montant dépasse le reste à rembourser (${eur(b.reste)}).${d.confirm ? " Touche encore pour enregistrer quand même." : ""}</div>` : ""}
    <div class="btns"><button class="btn" style="background:${BOURSE_COL};flex:1" data-act="b-save">${over && d.confirm ? "Enregistrer quand même" : "Enregistrer"}</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
  V.bs.keep = true;
}
function sheetTarif(){
  const ids = bienIds();
  openSheet(`<h2>Nouveau tarif</h2><div class="small muted">Ajoute une ligne à partir d'une date. Les anciennes lignes restent intactes.</div>
    <label class="f">Bien<select id="tf-bien">${ids.map(id => `<option value="${esc(id)}">${esc(bienName(id))}</option>`).join("")}</select></label>
    <label class="f">Poste<select id="tf-poste">${POSTES_TARIF.map(p => `<option>${esc(p)}</option>`).join("")}</select></label>
    <div class="grid2"><label class="f">À partir du<input id="tf-date" type="date" value="${todayIso().slice(0,8)}01"></label><label class="f">Montant mensuel (€)<input id="tf-mont" inputmode="decimal"></label></div>
    <label class="f">Note<input id="tf-note" placeholder="Ex. nouveau tarif depuis septembre"></label>
    <div class="btns"><button class="btn" data-act="tf-save" style="flex:1">Ajouter</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function sheetPartage(frais){
  const p = partagesList().find(x => x.frais === frais) || {frais, total:0, partStudio:0.5};
  const ids = bienIds(), s1 = ids.includes("STUDIO") ? "STUDIO" : ids[0], s2 = ids.includes("T2") ? "T2" : ids.find(i => i !== s1);
  V.pt = {frais, s1, s2};
  openSheet(`<h2>${esc(frais)} · 2 comptes</h2>
    <div class="grid2"><label class="f">Total (€)<input id="pt-total" inputmode="decimal" value="${p.total ? fmtNum(p.total) : ""}"></label><label class="f">Part ${esc(bienName(s1))} (%)<input id="pt-part" inputmode="decimal" value="${fmtNum(Math.round(p.partStudio * 1000) / 10)}"></label></div>
    <div class="grid2"><label class="f">Date<input id="pt-date" type="date" value="${todayIso()}"></label><label class="f">Payé depuis<select id="pt-compte"><option value="Bien">Compte du bien</option><option value="Perso">Compte perso</option></select></label></div>
    <div class="seg"><button class="on" id="pt-pt" data-act="pt-tog">Pointé (passé sur le compte)</button></div>
    <div id="pt-info" class="info"></div>
    <div class="btns"><button class="btn" data-act="pt-save" style="flex:1">Créer les 2 lignes</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
  V.pt.pt = true; ptInfo();
}
function ptInfo(){ const t = parseNum($("#pt-total").value) || 0, pc = (parseNum($("#pt-part").value) || 0) / 100, [a, b] = splitPartage(t, pc);
  $("#pt-info").textContent = `${bienName(V.pt.s1)} ${eur(a)} · ${bienName(V.pt.s2)} ${eur(b)}`; }

function sheetFacture(id){
  const f = id ? S.factures.find(x => x.id === id) : {fourn:"",num:"",date:todayIso(),cat:"TRAVAUX",desc:"",prix:"",jdmm:"",scan:""};
  const cats = [...new Set(["TRAVAUX","Ameublement","Electricité"].concat(live(S.factures).map(x => x.cat).filter(Boolean)))];
  openSheet(`<h2>${id ? "Modifier la facture" : "Nouvelle facture"}</h2>
    <label class="f">Fournisseur<input id="x-fourn" value="${esc(f.fourn)}"></label>
    <div class="grid2"><label class="f">N° de facture<input id="x-num" value="${esc(f.num)}"></label><label class="f">Date<input id="x-date" type="date" value="${esc(f.date)}"></label></div>
    <div class="grid2"><label class="f">Catégorie<input id="x-cat" list="x-cats" value="${esc(f.cat)}"><datalist id="x-cats">${cats.map(c => `<option>${esc(c)}</option>`).join("")}</datalist></label>
      <label class="f">Prix (€)<input id="x-prix" inputmode="decimal" value="${fmtNum(f.prix)}"></label></div>
    <label class="f">Description<input id="x-desc" value="${esc(f.desc)}"></label>
    <div class="seg"><button class="${f.scan==="x"?"on":""}" data-act="xtog" data-k="scan">Scanné</button><button class="${f.jdmm==="x"?"on":""}" data-act="xtog" data-k="jdmm">Enregistré compta</button></div>
    <div class="btns"><button class="btn" data-act="f-save" data-id="${id||""}" style="flex:1">Enregistrer</button>${id ? `<button class="btn danger" data-act="f-del" data-id="${id}">Supprimer</button>` : ""}<button class="btn ghost" data-act="sheetclose">Fermer</button></div>`);
  V.sf = {scan:f.scan, jdmm:f.jdmm};
}
function sheetLoc(id){
  const t = id ? S.locataires.find(x => x.id === id) : {bien:V.bsel || bienIds()[0] || "",nom:"",tel:"",email:"",debut:"",fin:"",loyer:"",depot:"",note:""};
  openSheet(`<h2>${id ? "Modifier le locataire" : "Nouveau locataire"}</h2>
    ${id && typeof tenantDossier === "function" ? tenantDossier(id) : ""}
    <label class="f">Bien<select id="t-bien">${bienIds().map(b => `<option value="${esc(b)}" ${b===t.bien?"selected":""}>${esc(bienName(b))}</option>`).join("")}</select></label>
    <label class="f">Nom<input id="t-nom" value="${esc(t.nom)}"></label>
    <div class="grid2"><label class="f">Téléphone<input id="t-tel" type="tel" value="${esc(t.tel)}"></label><label class="f">E-mail<input id="t-mail" type="email" autocapitalize="none" value="${esc(t.email)}"></label></div>
    <div class="grid2"><label class="f">Début du bail<input id="t-debut" type="date" value="${esc(t.debut)}"></label><label class="f">Fin du bail<input id="t-fin" type="date" value="${esc(t.fin)}"></label></div>
    <div class="grid2"><label class="f">Loyer charges comprises (€)<input id="t-loyer" inputmode="decimal" value="${fmtNum(t.loyer)}"></label><label class="f">Dont charges (€)<input id="t-chg" inputmode="decimal" value="${fmtNum(t.charges || "")}"></label></div>
    <label class="f">Dépôt de garantie (€)<input id="t-depot" inputmode="decimal" value="${fmtNum(t.depot)}"></label>
    <label class="f">Note<input id="t-note" value="${esc(t.note)}"></label>
    ${id ? `<div class="card" style="padding:12px;gap:6px;background:var(--bg)"><b style="font-size:14px">Le locataire part ?</b><div class="small muted">« Clôturer » enregistre la date de fin, coche les étapes du départ, calcule le dépôt à rendre et, si tu veux, efface son dossier. Rien n'est supprimé sans ton accord.</div><button class="btn ghost sm" data-act="tcl-open" data-id="${id}">Clôturer ce locataire</button></div>` : ""}
    <div class="btns"><button class="btn" data-act="l-save" data-id="${id||""}" style="flex:1">Enregistrer</button>${id ? `<button class="btn danger" data-act="l-del" data-id="${id}">Supprimer</button>` : ""}<button class="btn ghost" data-act="sheetclose">Fermer</button></div>`);
}
function sheetRelance(id){
  const j = S.journal.find(x => x.id === id), t = tenantFor(j.bien, j.date);
  const msg = `Bonjour${t ? " " + t.nom : ""}, sauf erreur de ma part, le loyer de ${MOIS[mo(j)].toLowerCase()} ${yr(j)} (${eur(j.montant)}) pour ${bienName(j.bien)} n'est pas encore arrivé. Pourriez-vous vérifier de votre côté ? Merci d'avance${S.cfg && S.cfg.bailleur ? ", " + S.cfg.bailleur : ""}.`;
  openSheet(`<h2>Relancer · ${esc(bienName(j.bien))}</h2><div class="small muted">${t ? esc(t.nom) + (t.tel ? " · " + esc(t.tel) : " · pas de téléphone") + (t.email ? " · " + esc(t.email) : " · pas d'e-mail") : "Aucun locataire enregistré pour ce bien (onglet Biens › Locataires)."}</div>
    <label class="f">Message<textarea id="r-msg">${esc(msg)}</textarea></label>
    <div class="btns">${t && t.tel ? `<button class="btn" data-act="r-sms" data-tel="${esc(t.tel)}">Envoyer par SMS</button>` : ""}${t && t.email ? `<button class="btn" data-act="r-mail" data-mail="${esc(t.email)}" data-sub="${esc("Loyer de " + MOIS[mo(j)].toLowerCase() + " " + yr(j) + " - " + bienName(j.bien))}">Envoyer par e-mail</button>` : ""}<button class="btn ghost" data-act="r-copy">Copier</button><button class="btn ghost" data-act="sheetclose">Fermer</button></div>`);
}

/* ---------- Bilan ---------- */
function viewBilan(){
  const y = V.y, ids = bienIds(), st = stats(null, y);
  const years = [...new Set(J().map(yr).concat([now0.getFullYear()]))].sort((a,b) => a - b);
  const months = MC.map((nm, m) => { const L = J().filter(j => yr(j) === y && mo(j) === m); return {nm, rec:sum(L.filter(j => j.type==="Recette").map(j => j.montant)), dep:sum(L.filter(j => j.type==="Dépense").map(j => j.montant))}; });
  const mx = Math.max(1, ...months.map(m => Math.max(m.rec, m.dep)));
  let cum = 0; const cumBy = {}; for (const yy of years){ cum += stats(null, yy).bourse; cumBy[yy] = cum; }
  return topbar("Bilan", yearNav()) + `
  <div class="card hero"><div class="lbl">Cash flow ${y} (2 biens)</div><div class="big num">${eur(st.cf)}</div>
    <div class="sub">Loyers ${eur(st.rec)} − charges ${eur(st.dep)}. Encaissé à ce jour : ${eur(st.benef)}.</div></div>
  <div class="btns"><button class="btn ghost sm" data-act="export-open">Exporter un mois ou une année (Excel / PDF)</button></div>
  <div class="card"><h2>Par bien</h2>${ids.map(id => { const s = stats(id, y); return `<div class="env" style="padding:6px 0"><div class="top"><b>${esc(bienName(id))}</b><span class="num ${signCl(s.cf)}">${eur(s.cf)}</span></div>
    <div class="small muted">Loyers ${eur(s.rec)} · charges ${eur(s.dep)} · solde fin d'année ${eur(soldeBien(id, y))}</div></div>`; }).join("")}
    ${kv("Argent mis en épargne cette année (net)", eur(st.ep), "muted")}</div>
  ${perfCard()}
  <div class="card"><h2>Mois par mois</h2>${months.map(m => `<div class="mrow"><span>${m.nm}</span><div class="bars"><div class="bar"><i style="width:${Math.round(m.rec/mx*100)}%"></i></div><div class="bar"><i class="warn" style="width:${Math.round(m.dep/mx*100)}%"></i></div></div><span class="num small ${signCl(m.rec-m.dep)}">${eur(m.rec - m.dep)}</span></div>`).join("")}
    <div class="small muted">Bleu : loyers · orange : charges (encaissé + prévu).</div></div>
  <div class="card"><h2>Toutes les années</h2><div class="rows">${years.slice().reverse().map(yy => { const s = stats(null, yy); return `<div class="row"><div class="main"><div class="t">${yy}</div>
    <div class="s">${ids.map(id => esc(bienName(id)) + " " + eur(stats(id, yy).cf)).join(" · ")}</div><div class="s">Comptes ${eur(sum(ids.map(id => soldeBien(id, yy))))} · bourse versée (cumul) ${eur(cumBy[yy])}</div></div><div class="amt num ${signCl(s.cf)}">${eur(s.cf)}</div></div>`; }).join("")}</div></div>`;
}

/* ---------- Réglages ---------- */
function secCard(){
  if (!secAvailable()) return `<div class="card"><h2>Sécurité</h2><div class="small muted">Le verrouillage est disponible dans l'appli installée sur l'iPhone (adresse web https), pas dans cet aperçu.</div></div>`;
  if (!SEC.on) return `<div class="card"><h2>Sécurité</h2><div class="small muted">Protège l'appli par un code. Tes données (dont les locataires) sont alors chiffrées sur le téléphone.</div>
    <div class="btns"><button class="btn" data-act="sec-on">Activer le verrouillage</button></div></div>`;
  return `<div class="card"><h2>Sécurité</h2><div class="kv"><span>Verrouillage</span><span class="chip">Activé · données chiffrées</span></div>
    <label class="f">Verrouiller après être sorti de l'appli depuis<select id="sec-delay">${[[0,"Tout de suite"],[30,"30 secondes"],[120,"2 minutes"],[300,"5 minutes"]].map(([v,l]) => `<option value="${v}" ${SEC.cfg.delay === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
    <div class="btns">${V.faceOK ? (SEC.cfg.face ? `<button class="btn ghost" data-act="face-off">Désactiver Face ID</button>` : `<button class="btn" data-act="face-on">Activer Face ID</button>`) : ""}
      <button class="btn ghost" data-act="sec-change">Changer le code</button><button class="btn danger" data-act="sec-off">Désactiver</button><button class="btn ghost" data-act="sec-lock">Verrouiller maintenant</button></div>
    ${V.faceOK ? "" : `<div class="small muted">Face ID indisponible ici : le code reste demandé.</div>`}</div>`;
}
function sheetPin(mode){
  const f = (id, lab) => `<label class="f">${lab}<input id="${id}" type="password" inputmode="numeric" autocomplete="off" maxlength="6" pattern="[0-9]*"></label>`;
  const t = {set:"Choisir un code", change:"Changer le code", off:"Désactiver le verrouillage"}[mode];
  openSheet(`<h2>${t}</h2>${mode !== "set" ? f("pin-old", "Code actuel") : ""}${mode !== "off" ? f("pin-new", "Nouveau code (4 à 6 chiffres)") + f("pin-new2", "Confirmer le code") : ""}
    ${mode === "set" ? `<div class="small muted">Si tu oublies le code, il faudra effacer l'appli et réimporter tes données depuis Excel. Un code de 6 chiffres protège mieux qu'un code de 4.</div>` : ""}
    ${mode === "off" ? `<div class="small muted">Les données seront de nouveau stockées sans chiffrement sur ce téléphone.</div>` : ""}
    <div class="btns"><button class="btn" data-act="pin-${mode}" style="flex:1">Valider</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function viewSet(){
  const p = V.pending;
  const pend = p ? `<div class="card" style="border-color:var(--accent)"><h2>Fichier lu : ${esc(p.name)}</h2>
    <div class="small">${p.kind === "json" ? bkSummary(p.data) : p.kind === "dos" ? esc(p.sum) : `${p.d.biens ? p.d.biens.length + " bien(s), " : ""}${p.d.tarifs ? p.d.tarifs.length + " tarif(s), " : ""}${p.d.journal.length} opération(s), ${p.d.factures.length} facture(s), ${p.d.locataires.length} locataire(s).`}</div>
    <div class="btns"><button class="btn" data-act="imp-merge">${p.kind === "json" ? "Restaurer" : p.kind === "dos" ? "Ranger les fichiers" : "Fusionner (recommandé)"}</button>
    ${p.kind !== "echange" ? "" : `<button class="btn ghost" data-act="imp-replace">Remplacer mes données</button>`}<button class="btn ghost" data-act="imp-cancel">Annuler</button></div></div>` : "";
  return `<div class="top"><div class="app">Réglages</div><button class="q" data-act="help" aria-label="Aide">?</button></div>${V.msg ? `<div class="info">${esc(V.msg)}</div>` : ""}${pend}
  <div class="card"><h2>Synchroniser avec Excel</h2>
    <div class="small muted"><b>Excel → appli</b> : dans Excel, bouton « Exporter vers l'appli », puis importe ici <b>export_appli.xlsx</b>. Les lignes déjà connues sont mises à jour, les nouvelles ajoutées, celles supprimées dans Excel retirées.<br><b>Appli → Excel</b> : exporte le journal, enregistre-le dans Fichiers › dossier IMPORT, puis bouton « Importer depuis l'appli » dans Excel.</div>
    <label class="f">Importer un fichier (export_appli.xlsx, sauvegarde .json ou .zip)<input id="file" type="file" accept="*/*"></label>
    <div class="btns"><button class="btn" data-act="exp-journal">Exporter le journal (.xlsx)</button><button class="btn ghost" data-act="exp-json">Sauvegarde légère (.json)</button></div>
    <div class="btns"><button class="btn" data-act="exp-zip">Sauvegarde complète avec fichiers (.zip)</button></div>
    <div class="small muted"><b>Que fait chaque bouton ?</b><br>• <b>Exporter le journal (.xlsx)</b> : sert à l'exploitation dans ton fichier Excel dédié (comptabilité, bilans). Ce n'est pas une sauvegarde.<br><b>Quelle sauvegarde choisir ?</b><br>• <b>Légère (.json)</b> : tes données (biens, opérations, locataires, fiches, états des lieux et inventaires en texte). Petite, mais <b>sans</b> photos ni fichiers (pièces d'identité, contrats, PDF importés).<br>• <b>Complète avec fichiers (.zip)</b> : tout, photos et documents des locataires compris. C'est celle à faire avant de changer de téléphone. Pour restaurer, importe le .zip ci-dessus tel quel (ne le décompresse pas).<br>Aucune n'est chiffrée et le .zip contient des papiers personnels : garde-les dans un endroit privé, jamais dans un dossier partagé.</div></div>
  ${biensCard()}${matelasCardSet()}${bourseCardSet()}${dirCard()}${secCard()}${themeCard()}${confortCard()}${modelesCard()}${archCard()}${demoCard()}${ficheCard()}${guideCard()}${legalCard()}${aideCard()}${histCard()}
  <div class="card"><h2>Données</h2><div class="small muted">${live(S.biens).length} bien(s) · ${live(S.journal).length} opération(s) · ${live(S.factures).length} facture(s) · ${live(S.locataires).length} locataire(s)</div>
    ${V.wipe ? `<div class="small">Cette action efface tout ce qui est stocké sur cet appareil.</div><div class="btns"><button class="btn danger" data-act="wipe-yes">Oui, tout effacer</button><button class="btn ghost" data-act="wipe-no">Annuler</button></div>`
             : `<div class="btns"><button class="btn ghost" data-act="wipe">Tout effacer</button></div>`}</div>
  <div class="ver">Gestion Locative Facile · version ${APP_VERSION}</div>`;
}

function render(){
  if (!S) return;
  if (V.tab === "welcome" && live(S.biens).length && !(V.wz && V.wz.active)) V.tab = "home";
  if (V.doc && (V.tab !== "bld" || V.bsub !== "docs")) V.doc = null;
  document.body.classList.toggle("welcome", V.tab === "welcome");
  renderTabs();
  const main = $("#main");
  const sig = V.tab + "|" + V.bsub + "|" + (V.doc ? V.doc.id : ""), y0 = window.scrollY, same = sig === V.lastSig; V.lastSig = sig;
  main.dataset.tab = V.tab;
  main.innerHTML = V.tab === "welcome" ? viewWelcome() : V.tab === "home" ? viewHome() : V.tab === "guide" ? viewGuide() : V.tab === "cmp" ? viewCompta() : V.tab === "add" ? viewAdd() : V.tab === "month" ? viewMonth() : V.tab === "bld" ? viewBiens() : V.tab === "rent" ? viewRent() : V.tab === "chart" ? viewBilan() : viewSet();
  if (V.tab === "add") updateInfo();
  window.scrollTo(0, same ? y0 : 0);
  if (typeof phHydrate === "function") phHydrate();
}
function openSheet(html){ $("#sheet").innerHTML = '<div class="grab"></div>' + html; $("#sheetbg").hidden = false; }
function closeSheet(){ $("#sheetbg").hidden = true; $("#sheet").innerHTML = ""; }

/* ============ Import ============ */
async function onFile(file){
  try {
    const buf = await file.arrayBuffer(), u8 = new Uint8Array(buf), isZip = /\.zip$/i.test(file.name) || (!/\.(xlsx|xlsm|xls|json|csv|txt)$/i.test(file.name) && u8[0] === 0x50 && u8[1] === 0x4b && u8[2] === 3 && u8[3] === 4);
    if (isZip){
      const fs = zipRead(buf), dj = fs.find(f => f.name === "donnees.json");
      if (dj){
        const obj = JSON.parse(new TextDecoder().decode(dj.data)); if (!obj || !Array.isArray(obj.journal)) throw new Error("Sauvegarde non reconnue.");
        V.pending = {kind:"json", name:file.name, data:obj, zip:fs, d:{journal:obj.journal, biens:obj.biens || [], factures:[], locataires:obj.locataires || []}};
      } else {
        const dos = fs.filter(f => /^Gestion locative\/[^/]+\/Locataires\/[^/]+\/[^/]+\/[^/]+$/.test(f.name) && !/\/00 Fiche\//.test(f.name));
        if (!dos.length) throw new Error("ce ZIP n'est ni une sauvegarde complète ni un dossier rangé de l'appli.");
        const nl = new Set(dos.map(f => f.name.split("/").slice(1, 4).join("/"))).size;
        V.pending = {kind:"dos", name:file.name, dos, sum:"Dossier rangé : " + dos.length + " fichier(s) pour " + nl + " locataire(s). Les fichiers seront ajoutés aux fiches des locataires déjà présents dans l'appli (même nom, même bien). Pour tout restaurer sur un nouvel appareil, utilise plutôt la « Sauvegarde complète avec fichiers (.zip) ».", d:{journal:[], biens:null, factures:[], locataires:[]}};
      }
    } else if (/\.json$/i.test(file.name)){
      const obj = JSON.parse(new TextDecoder().decode(u8)); if (!obj || !Array.isArray(obj.journal)) throw new Error("Sauvegarde non reconnue.");
      V.pending = {kind:"json", name:file.name, data:obj, d:{journal:obj.journal, biens:obj.biens || [], factures:[], locataires:obj.locataires || []}};
    } else {
      const wb = XLSX.read(buf, {type:"array", sheets:["Biens_appli","Tarifs_appli","Journal_appli","Factures_appli","Locataires_appli","Reglages_appli","FraisPartages_appli"]});
      const d = parseEchange(wb); if (!d) throw new Error("feuilles « …_appli » introuvables (utilise le bouton d'export de la macro Excel).");
      V.pending = {kind:"echange", name:file.name, d};
    }
    V.msg = ""; render(); toast("Fichier lu : appuie sur le bouton vert pour valider");
    setTimeout(() => { const c = document.querySelector('#main .card[style*="accent"]'); if (c) c.scrollIntoView({block:"center"}); }, 150);
  } catch(e){ V.pending = null; V.msg = "Lecture impossible : " + e.message; render(); toast("Lecture impossible : " + e.message); }
}
function bkSummary(o){
  const nb = (o.biens || []).filter(b => !b.del).length, nl = (o.locataires || []).filter(x => !x.del).length, no = (o.journal || []).filter(x => !x.del).length;
  return (V.pending && V.pending.zip ? "Sauvegarde avec fichiers (" + V.pending.zip.filter(f => /^fichiers\//.test(f.name)).length + " fichier(s)/photo(s)) : " : "Sauvegarde complète : ") + nb + " bien(s), " + nl + " locataire(s), " + no + " opération(s), bailleur : " + ((o.cfg && o.cfg.bailleur) || "non renseigné") + "." + (o.demo ? " ⚠ Ce sont des données d'exemple (version d'essai), pas tes vraies données." : "") + (!nb ? " ⚠ Aucun bien dans ce fichier." : "");
}
function commitImport(replace){
  const p = V.pending; if (!p) return;
  if (p.kind === "dos"){ restoreDossiers(p.dos).then(r => { V.pending = null; V.msg = r.n + " fichier(s) rangé(s) dans les fiches" + (r.skip ? ", " + r.skip + " déjà présent(s)" : "") + (r.nolo.length ? ". Locataire(s) introuvable(s) dans l'appli : " + r.nolo.join(", ") + " (crée d'abord leur fiche)." : "."); persist(); render(); }).catch(e => toast("Rangement impossible : " + e.message)); return; }
  if (p.kind === "json"){ S = Object.assign(emptyData(), p.data); S.demo = false; if (p.zip) restoreFull(p.zip).then(n => { toast(n + " fichier(s) et photo(s) restauré(s)"); render(); }).catch(e => toast("Fichiers non restaurés : " + e.message)); V.msg = "Sauvegarde restaurée : " + (S.biens || []).filter(b => !b.del).length + " bien(s), " + (S.locataires || []).filter(x => !x.del).length + " locataire(s), bailleur : " + ((S.cfg && S.cfg.bailleur) || "non renseigné") + "."; }
  else {
    const d = p.d, fromExcel = !!d.biens;
    if (replace || S.demo){ const base = emptyData(); S = base; }
    S.demo = false;
    if (d.biens){ const old = new Map(S.biens.map(b => [b.id, b])), ids = new Set(d.biens.map(b => b.id));
      S.biens = d.biens.map(b => { const o = old.get(b.id); if (o && !b.adresse && o.adresse) b.adresse = o.adresse; if (o && o.emprunt && !b.emprunt) b.emprunt = o.emprunt; if (o && o.lmnp) b.lmnp = o.lmnp; if (o && o.desc) b.desc = o.desc; if (o && o.app) b.app = true; return b; }).concat(S.biens.filter(b => b.app && !ids.has(b.id))); }
    if (d.reglages){ S.cfg = S.cfg || {bailleur:"", adr:{}}; if (d.reglages.bailleur) S.cfg.bailleur = d.reglages.bailleur; if (d.reglages.bailleuradresse) S.cfg.bailleurAdr = d.reglages.bailleuradresse; }
    if (d.tarifs){ const k = t => [t.bien, t.poste, t.date].join("|"), have = new Set(d.tarifs.map(k)); S.tarifs = d.tarifs.concat(S.tarifs.filter(t => t.app && !have.has(k(t)))); }
    if (d.partages) S.partages = d.partages;
    const a = mergeJournal(S.journal, d.journal), b = mergeList(S.factures, d.factures), c = mergeList(S.locataires, d.locataires);
    V.msg = `Opérations : ${a.add} ajoutée(s), ${a.upd} mise(s) à jour${a.dup ? ", " + a.dup + " doublon(s) ignoré(s)" : ""}. Factures : ${b.add} / ${b.upd}. Locataires : ${c.add} / ${c.upd}.`;
    if (fromExcel){
      const now = new Set(idsOf(d)), t = Date.now(); let gone = 0;
      for (const list of [S.journal, S.factures, S.locataires]) for (const x of list) if (!x.del && (S.seen || []).includes(x.id) && !now.has(x.id)){ x.del = true; x.upd = t; gone++; }
      if (gone) V.msg += ` ${gone} ligne(s) supprimée(s) dans Excel retirée(s) ici.`;
      S.seen = idsOf(d);
    }
  }
  V.pending = null; migrate(); persist(); render();
}

/* ============ Actions ============ */
function setY(d){ V.y += d; render(); }
function setMonth(d){ V.m += d; if (V.m < 0){ V.m = 11; V.y--; } if (V.m > 11){ V.m = 0; V.y++; } render(); }
const getJ = id => S.journal.find(x => x.id === id);
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) { if (ev.target.id === "sheetbg") closeSheet(); return; }
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a){
    case "tab": collectDraft(); if (v === "add" && V.tab !== "add"){ V.editId = null; V.draft = null; V.back = null; } V.tab = v; render(); break;
    case "go": V.tab = v; if (b.dataset.sub){ V.bsub = b.dataset.sub; if (b.dataset.bien) V.bsel = b.dataset.bien; } if (b.dataset.f){ V.mf = b.dataset.f; V.bf = "all"; } render(); break;
    case "yprev": setY(-1); break; case "ynext": setY(1); break;
    case "mprev": setMonth(-1); break; case "mnext": setMonth(1); break;
    case "bf": V.bf = v; render(); break; case "mf": V.mf = v; render(); break;
    case "bsub": V.bsub = v; render(); break; case "bsel": V.bsel = v; render(); break;
    case "jtoggle": { const j = getJ(id); j.pointe = j.pointe === "x" ? "" : "x"; j.upd = Date.now(); onPointe(j); persist(); render(); { const sr = $("#sres"); if (sr) sr.innerHTML = searchRes(V.sq || ""); } break; }
    case "jedit": closeSheet(); V.back = V.tab; V.editId = id; V.draft = null; V.tab = "add"; render(); break;
    case "jdel": { const j = getJ(V.editId); j.del = true; j.upd = Date.now(); V.editId = null; V.draft = null; persist(); toast("Opération supprimée"); V.tab = V.back || "month"; V.back = null; render(); break; }
    case "rent-add": { const m = +b.dataset.m, bien = b.dataset.bien; V.back = "bld"; V.bsub = "loyers"; V.bsel = bien; V.editId = null; V.draft = newDraft({bien, date: V.y + "-" + pad(m + 1) + "-01", cat:"Loyer", pt:false}); V.tab = "add"; render(); autoSuggest(true); break; }
    case "pointall": { const L = monthList().filter(j => j.pointe !== "x" && j.date <= todayIso()); openSheet(`<h2>Tout pointer ?</h2><div class="small muted">${L.length} opération(s) seront marquées comme passées sur le compte.</div><div class="btns"><button class="btn" data-act="pointall-ok" style="flex:1">Pointer ${L.length} ligne(s)</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); break; }
    case "pointall-ok": { const t = Date.now(); monthList().filter(j => j.pointe !== "x" && j.date <= todayIso()).forEach(j => { j.pointe = "x"; j.upd = t; onPointe(j); }); persist(); closeSheet(); toast("Pointé"); render(); break; }
    case "dtype": collectDraft(); V.draft.type = v; V.draft.cat = v === "Recette" ? "Loyer" : ""; V.draft.montAuto = true; if (v !== "Dépense"){ V.draft.compta = false; V.draft.justif = false; V.draft.compte = "Bien"; } render(); autoSuggest(true); break;
    case "dbien": collectDraft(); V.draft.bien = v; render(); autoSuggest(false); break;
    case "dcompte": collectDraft(); V.draft.compte = v; render(); break;
    case "dtog": collectDraft(); V.draft[v] = !V.draft[v]; render(); break;
    case "save": saveOp(); break;
    case "clear": V.draft = null; render(); break;
    case "relance": sheetRelance(id); break;
    case "r-copy": { const t = $("#r-msg").value; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("Message copié")).catch(() => { $("#r-msg").select(); toast("Sélectionné : copiez-le"); }); break; }
    case "r-mail": { location.href = "mailto:" + b.dataset.mail + "?subject=" + encodeURIComponent(b.dataset.sub) + "&body=" + encodeURIComponent($("#r-msg").value); break; }
    case "r-sms": { const t = encodeURIComponent($("#r-msg").value), sep = /iPhone|iPad|iPod/i.test(navigator.userAgent) ? "&" : "?"; location.href = "sms:" + b.dataset.tel + sep + "body=" + t; break; }
    case "bourse": V.bs = null; sheetBourse(v || ""); break;
    case "bs-bien": { const f = V.bs; f.mont = $("#b-mont").value; f.date = $("#b-date").value; f.confirm = false; sheetBourse(v); break; }
    case "bs-cat": { const f = V.bs; f.mont = $("#b-mont").value; f.date = $("#b-date").value; f.confirm = false; f.cat = v; sheetBourse(f.bien); break; }
    case "b-save": { const f = V.bs; f.mont = $("#b-mont").value; f.date = $("#b-date").value; const mt = parseNum(f.mont);
      if (!mt || mt <= 0) return toast("Saisis un montant"); if (!f.date) return toast("Choisis une date");
      const reste = bourseOf(f.bien, f.cat).reste;
      if (mt > reste + 0.005 && !f.confirm){ f.confirm = true; sheetBourse(f.bien); return; }
      S.journal.push({id:uid(), date:f.date, bien:f.bien, type:"Entrée", cat:f.cat || "Bourse", lib:"Remboursement " + (!f.cat || f.cat === "Bourse" ? "bourse" : f.cat), montant:r2(mt), compte:"Bien", pointe:"x", compta:"", justif:"", fourn:"", note:"", upd:Date.now()});
      V.bs = null; persist(); closeSheet(); toast("Remboursement de " + eur(mt) + " enregistré"); render(); break; }
    case "tarif-new": sheetTarif(); break;
    case "tf-save": { const mt = parseNum($("#tf-mont").value), d = $("#tf-date").value; if (!mt || mt <= 0 || !d) return toast("Date et montant obligatoires");
      S.tarifs.push({bien:$("#tf-bien").value, poste:$("#tf-poste").value, date:d, montant:r2(mt), note:$("#tf-note").value.trim(), app:true, upd:Date.now()}); persist(); closeSheet(); toast("Tarif ajouté"); render(); break; }
    case "partage": sheetPartage(v); break;
    case "pt-tog": V.pt.pt = !V.pt.pt; b.classList.toggle("on", V.pt.pt); break;
    case "pt-save": { const t = parseNum($("#pt-total").value), pc = (parseNum($("#pt-part").value) ?? 50) / 100, d = $("#pt-date").value;
      if (!t || t <= 0) return toast("Saisis le total"); if (!d) return toast("Choisis une date"); if (pc < 0 || pc > 1) return toast("La part doit être entre 0 et 100 %");
      const [x, y2] = splitPartage(t, pc), cat = PARTAGE_CAT[V.pt.frais] || V.pt.frais, now = Date.now(), cpt = $("#pt-compte").value;
      [[V.pt.s1, x], [V.pt.s2, y2]].forEach(([bien, m]) => S.journal.push({id:uid(), date:d, bien, type:"Dépense", cat, lib:V.pt.frais, montant:m, compte:cpt, pointe:V.pt.pt ? "x" : "", compta:"", justif:"", fourn:"", note:"Frais partagés : total " + eur(t).replace(/[\u202f\u00a0]/g, " ") + ", part " + bienName(V.pt.s1) + " " + Math.round(pc*1000)/10 + " %", upd:now}));
      persist(); closeSheet(); toast("2 lignes créées : " + eur(x) + " + " + eur(y2)); render(); break; }
    case "rapp-save": { const reel = (S.rapp || {})[v], calc = soldeBien(v), ec = r2(reel - calc); if (!ec) return;
      S.journal.push({id:uid(), date:todayIso(), bien:v, type:ec > 0 ? "Entrée" : "Sortie", cat:"Écart de rapprochement", lib:"Ajustement sur relevé banque du " + frDate(todayIso()), montant:Math.abs(ec), compte:"Bien", pointe:"x", compta:"", justif:"", fourn:"", note:"Solde réel relevé " + eur(reel).replace(/[\u202f\u00a0]/g, " "), upd:Date.now()});
      persist(); toast("Ajustement enregistré : " + eur(Math.abs(ec))); render(); break; }
    case "fnew": sheetFacture(""); break; case "fedit": sheetFacture(id); break;
    case "ftog": { const f = S.factures.find(x => x.id === id), k = b.dataset.k; f[k] = f[k] === "x" ? "" : "x"; f.upd = Date.now(); persist(); render(); break; }
    case "xtog": { V.sf[b.dataset.k] = V.sf[b.dataset.k] === "x" ? "" : "x"; b.classList.toggle("on"); break; }
    case "f-save": { const fourn = $("#x-fourn").value.trim(); if (!fourn) return toast("Donne le fournisseur");
      const o = {fourn, num:$("#x-num").value.trim(), date:$("#x-date").value, cat:$("#x-cat").value.trim(), desc:$("#x-desc").value.trim(), prix:parseNum($("#x-prix").value) || 0, jdmm:V.sf.jdmm, scan:V.sf.scan, upd:Date.now()};
      if (id) Object.assign(S.factures.find(x => x.id === id), o); else S.factures.push(Object.assign({id:uid()}, o)); persist(); closeSheet(); render(); break; }
    case "f-del": { const f = S.factures.find(x => x.id === id); f.del = true; f.upd = Date.now(); persist(); closeSheet(); render(); break; }
    case "lnew": sheetLoc(""); break; case "ledit": sheetLoc(id); break;
    case "l-save": { const nom = $("#t-nom").value.trim(); if (!nom) return toast("Donne le nom");
      const o = {bien:$("#t-bien").value, nom, tel:$("#t-tel").value.trim(), email:$("#t-mail").value.trim(), debut:$("#t-debut").value, fin:$("#t-fin").value, loyer:parseNum($("#t-loyer").value) || 0, charges:parseNum($("#t-chg").value) || 0, depot:parseNum($("#t-depot").value) || 0, note:$("#t-note").value.trim(), upd:Date.now()};
      if (id) Object.assign(S.locataires.find(x => x.id === id), o); else S.locataires.push(Object.assign({id:uid()}, o)); persist(); closeSheet(); render(); break; }
    case "l-del": { const t = S.locataires.find(x => x.id === id); t.del = true; t.upd = Date.now(); persist(); closeSheet(); render(); break; }
    case "sheetclose": closeSheet(); break;
    case "lk-d": if (SEC.pin.length < 6){ SEC.pin += id; lockDots(); if (SEC.pin.length === 6) lockSubmit(); } break;
    case "lk-del": SEC.pin = SEC.pin.slice(0,-1); lockDots(); break;
    case "lk-ok": lockSubmit(); break;
    case "lk-face": unlockFace().then(ok => ok ? hideLock() : showLock("Face ID non reconnu, utilise le code", true)); break;
    case "lk-forgot": $("#lockmsg").textContent = "Effacer les données de ce téléphone ? Tu pourras réimporter depuis Excel."; $("#lockmsg").className = "bad";
      $("#lockextra").innerHTML = `<button class="btn danger sm" data-act="lk-wipe">Oui, effacer</button><button class="btn ghost sm" data-act="lk-no">Annuler</button>`; break;
    case "lk-no": showLock(); break;
    case "lk-wipe": lsDel(ENC); lsDel(KEY); lsDel(SECK); idbDel("dk"); SEC.on = false; SEC.dk = null; SEC.cfg = {face:false, cred:"", delay:30, fails:0, until:0}; S = null; memCopy = null; $("#lock").hidden = true; startApp(); break;
    case "sec-on": sheetPin("set"); break; case "sec-change": sheetPin("change"); break; case "sec-off": sheetPin("off"); break;
    case "sec-lock": lockNow(); break;
    case "pin-set": { const x = $("#pin-new").value, c = $("#pin-new2").value; if (!/^\d{4,6}$/.test(x)) return toast("Le code doit avoir 4 à 6 chiffres"); if (x !== c) return toast("Les deux codes sont différents");
      secEnable(x).then(() => { closeSheet(); V.msg = ""; toast("Verrouillage activé"); render(); }).catch(() => toast("Activation impossible")); break; }
    case "pin-change": { const o = $("#pin-old").value, x = $("#pin-new").value, c = $("#pin-new2").value; if (!/^\d{4,6}$/.test(x)) return toast("Le code doit avoir 4 à 6 chiffres"); if (x !== c) return toast("Les deux codes sont différents");
      secChange(o, x).then(() => { closeSheet(); toast("Code modifié"); }).catch(() => toast("Code actuel incorrect")); break; }
    case "pin-off": { const o = $("#pin-old").value; secUnwrap(o).then(() => secDisable()).then(() => { closeSheet(); toast("Verrouillage désactivé"); render(); }).catch(() => toast("Code incorrect")); break; }
    case "face-on": faceRegister().then(async cred => { SEC.cfg.cred = cred; await idbPut("dk", SEC.dk); SEC.cfg.face = true; secCfgSave(); toast("Face ID activé"); render(); }).catch(() => toast("Face ID non activé")); break;
    case "face-off": SEC.cfg.face = false; SEC.cfg.cred = ""; secCfgSave(); idbDel("dk"); render(); break;
    case "exp-journal": saveFile("journal_appli.xlsx", buildEchange(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); break;
    case "exp-json": if (S.demo) toast("Attention : ce sont des données d'exemple"); saveFile("mes-locations-sauvegarde.json", JSON.stringify(S,null,1), "application/json"); break;
    case "imp-replace": commitImport(true); break; case "imp-merge": commitImport(false); break;
    case "imp-cancel": V.pending = null; render(); break;
    case "wipe": V.wipe = true; render(); break; case "wipe-no": V.wipe = false; render(); break;
    case "wipe-yes": S = emptyData(); V.wipe = false; V.msg = "Données effacées."; persist(); render(); break;
  }
});
document.addEventListener("input", ev => {
  const t = ev.target;
  if (t.id === "fq"){ V.fq = t.value; $("#flist").innerHTML = travList(); return; }
  if (t.id === "f-mont" && V.draft){ V.draft.montAuto = false; }
  if (t.id === "pt-total" || t.id === "pt-part"){ ptInfo(); return; }
  if (V.tab === "add" && /^f-(mont|date)$/.test(t.id)) updateInfo();
});
document.addEventListener("change", ev => {
  const t = ev.target;
  if (t.id === "file" && t.files[0]) { onFile(t.files[0]); t.value = ""; return; }
  if (/^rp-/.test(t.id)){ const x = parseNum(t.value); S.rapp = S.rapp || {}; S.rapp[t.dataset.bien] = t.value.trim() === "" || x === null ? "" : x; persist(); render(); return; }
  if (t.id === "sec-delay"){ SEC.cfg.delay = +t.value; secCfgSave(); return; }
  if (V.tab === "add" && /^f-(cat|date)$/.test(t.id)){ collectDraft(); autoSuggest(false); updateInfo(); }
});

