/* ============ Documents : bases (photos, PDF images, modèles, solde locataire, performance) ============ */

/* ---------- Photos : stockées dans IndexedDB (jamais dans les données principales) ---------- */
const PH = {db:null, cache:{}};
function phOpen(){ return new Promise(res => { try { const r = indexedDB.open("glf-photos", 1); r.onupgradeneeded = () => r.result.createObjectStore("p"); r.onsuccess = () => { PH.db = r.result; res(PH.db); }; r.onerror = () => res(null); } catch(e){ res(null); } }); }
async function phPut(id, obj){ PH.cache[id] = obj; const db = PH.db || await phOpen(); if (!db) return;
  return new Promise(res => { try { const tx = db.transaction("p", "readwrite"); tx.objectStore("p").put(obj, id); tx.oncomplete = tx.onerror = tx.onabort = () => res(); } catch(e){ res(); } }); }
async function phGet(id){ if (PH.cache[id]) return PH.cache[id]; const db = PH.db || await phOpen(); if (!db) return null;
  return new Promise(res => { try { const q = db.transaction("p").objectStore("p").get(id); q.onsuccess = () => { if (q.result) PH.cache[id] = q.result; res(q.result || null); }; q.onerror = () => res(null); } catch(e){ res(null); } }); }
async function phDel(id){ delete PH.cache[id]; const db = PH.db || await phOpen(); if (!db) return;
  return new Promise(res => { try { const tx = db.transaction("p", "readwrite"); tx.objectStore("p").delete(id); tx.oncomplete = tx.onerror = tx.onabort = () => res(); } catch(e){ res(); } }); }
function phCompress(file){ return new Promise((res, rej) => { const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => { const k = Math.min(1, 1000 / Math.max(img.width, img.height)), c = document.createElement("canvas"); c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res({d:c.toDataURL("image/jpeg", 0.6), w:c.width, h:c.height}); };
  img.onerror = () => { URL.revokeObjectURL(url); rej(new Error("image")); }; img.src = url; }); }
async function phHydrate(){ for (const im of document.querySelectorAll("img[data-ph]")){ if (im.src && im.dataset.ok) continue; const o = await phGet(im.dataset.ph); if (o){ im.src = o.d; im.dataset.ok = "1"; } } }

/* ---------- PDF : images JPEG + écriture finale (remplace PdfDoc.finish) ---------- */
PdfDoc.prototype.image = function(x, y, w, h, o){   // o = {d:"data:image/jpeg;base64,…", w, h}
  this.imgs = this.imgs || []; this.pageImg = this.pageImg || {};
  const k = this.imgs.length; this.imgs.push(o); const p = this.pages.length - 1; (this.pageImg[p] = this.pageImg[p] || []).push(k);
  this.cur.push(`q ${w.toFixed(1)} 0 0 ${h.toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)} cm /Im${k} Do Q`); };
PdfDoc.prototype.finish = function(sub){
  const n = this.pages.length, imgs = this.imgs || [], parts = [], off = []; let pos = 0;
  const put = s => { parts.push(s); pos += s.length; };
  put("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
  const add = body => { off.push(pos); put(off.length + " 0 obj\n" + body + "\nendobj\n"); };
  const idPage = i => 5 + i * 2, idCont = i => 6 + i * 2, idImg = k => 5 + n * 2 + k;
  add("<< /Type /Catalog /Pages 2 0 R >>");
  add("<< /Type /Pages /Kids [" + this.pages.map((_, i) => idPage(i) + " 0 R").join(" ") + "] /Count " + n + " >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
  this.pages.forEach((ops, i) => {
    const head = [], foot = [];
    if (!this.clean){ this.cur = head; this.text(this.M, this.H - 40, "Gestion Locative Facile", {size:11, bold:true, color:"#0E6B5C"}); this.text(this.W - this.M, this.H - 40, sub || this.title, {size:9.5, right:true, color:"#5C6B66"}); this.line(this.M, this.H - 48, this.W - this.M, this.H - 48);
    this.cur = foot; this.line(this.M, 44, this.W - this.M, 44); this.text(this.M, 30, "Généré le " + frDate(todayIso()), {size:8.5, color:"#5C6B66"}); this.text(this.W - this.M, 30, "Page " + (i + 1) + " / " + n, {size:8.5, right:true, color:"#5C6B66"}); } else if (n > 1){ this.cur = foot; this.text(this.W - this.M, 24, "Page " + (i + 1) + " / " + n, {size:8, right:true, color:"#8A9690"}); }
    const stream = head.concat(ops, foot).join("\n"), used = (this.pageImg || {})[i] || [];
    add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + this.W + " " + this.H + "] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>" + (used.length ? " /XObject << " + used.map(k => "/Im" + k + " " + idImg(k) + " 0 R").join(" ") + " >>" : "") + " >> /Contents " + idCont(i) + " 0 R >>");
    add("<< /Length " + stream.length + " >>\nstream\n" + stream + "\nendstream");
  });
  imgs.forEach(o => { const bin = atob(o.d.split(",")[1]);
    add("<< /Type /XObject /Subtype /Image /Width " + o.w + " /Height " + o.h + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + bin.length + " >>\nstream\n" + bin + "\nendstream"); });
  const startx = pos; let xref = "xref\n0 " + (off.length + 1) + "\n0000000000 65535 f \n" + off.map(o => String(o).padStart(10, "0") + " 00000 n \n").join("");
  put(xref + "trailer\n<< /Size " + (off.length + 1) + " /Root 1 0 R >>\nstartxref\n" + startx + "\n%%EOF");
  const out = parts.join(""), u = new Uint8Array(out.length); for (let i = 0; i < out.length; i++) u[i] = out.charCodeAt(i) & 255; return u;
};
/* texte en plusieurs lignes + tableau avec retour à la ligne et saut de page */
function wrapTxt(s, size, maxW, bold){ const out = []; for (const para of String(s ?? "").split("\n")){ let line = ""; for (const w of para.split(" ")){ const t = line ? line + " " + w : w; if (pdfW(t, size, bold) > maxW && line){ out.push(line); line = w; } else line = t; } out.push(line); } return out; }
function dTable(d, cols, rows, o){
  o = o || {}; const size = o.size || 9.5, lh = size + 3.5, pd = 4, tw = cols.reduce((a, c) => a + c.w, 0);
  const head = () => { d.need(34); d.rect(d.M, d.y - 4, tw, 16, "#E6F0ED"); let x = d.M; cols.forEach(c => { d.text(c.right ? x + c.w - pd : x + pd, d.y, c.h, {size:size - 0.5, bold:true, right:c.right, color:"#0E6B5C"}); x += c.w; }); d.y -= 18; };
  head();
  for (const r of rows){ const cells = r.cells || r, L = cells.map((s, i) => wrapTxt(s, size, cols[i].w - 2 * pd, false)), n = Math.max(1, ...L.map(l => l.length)), h = n * lh + 4;
    if (d.y - h < 60){ d.newPage(); head(); }
    if (typeof r.fill === "string") d.rect(d.M, d.y - (n - 1) * lh - 5, tw, h, r.fill);
    let x = d.M; L.forEach((ls, i) => { ls.forEach((ln, k) => d.text(cols[i].right ? x + cols[i].w - pd : x + pd, d.y - k * lh, ln, {size, right:cols[i].right, color:r.color || "#1B2430"})); x += cols[i].w; });
    d.y -= (n - 1) * lh + 5; d.line(d.M, d.y, d.M + tw, d.y); d.y -= lh - 2; }
  d.y -= 6;
}
async function pdfPhotos(d, ids, label){
  const objs = []; for (const id of ids){ const o = await phGet(id); if (o) objs.push(o); } if (!objs.length) return;
  d.need(30); d.text(d.M, d.y, label, {size:8.5, bold:true, color:"#5C6B66"}); d.y -= 8;
  const W = 118, gap = 9; let x = d.M, rowH = 0;
  for (const o of objs){ const h = Math.min(100, W * o.h / o.w), w = h === 100 ? 100 * o.w / o.h : W;
    if (x + w > d.W - d.M + 1){ x = d.M; d.y -= rowH + 8; rowH = 0; }
    if (d.y - h < 60){ d.newPage(); x = d.M; rowH = 0; }
    d.image(x, d.y - h, w, h, o); x += w + gap; rowH = Math.max(rowH, h); }
  d.y -= rowH + 12;
}

/* ---------- Modèles ---------- */
const ETATS = ["Neuf", "Bon", "Moyen", "Mauvais"], RANK = {"Neuf":0, "Bon":1, "Moyen":2, "Mauvais":3};
const EDL_PIECES = [
  ["Entrée / couloir", ["Porte d'entrée et serrure", "Sol", "Murs", "Plafond", "Prises et éclairage"]],
  ["Pièce de vie / séjour", ["Sol", "Murs", "Plafond", "Fenêtres et volets", "Prises et éclairage", "Chauffage / climatisation"]],
  ["Cuisine", ["Sol", "Murs", "Plafond", "Fenêtre", "Évier et robinetterie", "Plaques de cuisson", "Hotte", "Placards", "Prises et éclairage"]],
  ["Chambre", ["Sol", "Murs", "Plafond", "Fenêtres et volets", "Placards", "Prises et éclairage", "Chauffage / climatisation"]],
  ["Salle d'eau", ["Sol", "Murs", "Plafond", "Lavabo et robinetterie", "Douche / baignoire", "Ventilation", "Prises et éclairage"]],
  ["WC", ["Sol", "Murs", "Cuvette et chasse", "Éclairage"]]
];
/* liste minimale du mobilier d'un meublé (décret n° 2015-981 du 31 juillet 2015) */
const INV_DEF = [
  ["Chambre", ["Matelas", "Sommier / lit", "Couette ou couverture", "Oreillers", "Occultation des fenêtres (volets, rideaux, stores)", "Rangement (armoire, commode)"]],
  ["Séjour", ["Table", "Sièges (chaises, canapé)", "Étagères de rangement", "Luminaires"]],
  ["Cuisine", ["Plaques de cuisson", "Four ou four à micro-ondes", "Réfrigérateur", "Congélateur ou compartiment congélation (-6 °C)", "Vaisselle (assiettes, verres, couverts)", "Ustensiles de cuisine (casseroles, poêle, etc.)"]],
  ["Entretien", ["Matériel d'entretien ménager (aspirateur ou balai, seau)"]]
];
const mkItem = nom => ({id:uid(), nom, etat:"", com:"", ph:[]});
const mkPiece = (nom, items) => ({id:uid(), nom, items:(items || []).map(mkItem)});
const docList = k => (S[k] = S[k] || []);
const docGet = (k, id) => docList(k).find(x => x.id === id && !x.del);
const docCur = () => V.doc ? docGet(V.doc.kind === "edl" ? "edl" : "inv", V.doc.id) : null;
const bienAdr = id => { const b = S.biens.find(x => x.id === id); return (b && b.adresse) || ""; };
const bienDesc = id => { const b = S.biens.find(x => x.id === id); return (b && b.desc) || {}; };

/* ---------- Solde et historique des loyers du locataire ---------- */
function soldeLoc(bien){
  const t = tenantFor(bien, todayIso()), start = t && t.debut ? t.debut : "0000-00-00", end = t && t.fin && t.fin < todayIso() ? t.fin : todayIso();
  const L = J().filter(j => j.bien === bien && j.type === "Recette" && j.cat === "Loyer" && j.date >= start && j.date <= end).sort((a, b) => a.date.localeCompare(b.date));
  const du = r2(sum(L.map(j => j.montant))), recu = r2(sum(L.filter(j => j.pointe === "x").map(j => j.montant)));
  return {t, L, du, recu, solde:r2(recu - du), retard:L.filter(j => j.pointe !== "x")};
}
function soldeLine(id){
  const s = soldeLoc(id); if (!s.t) return "";
  return `<div class="small ${s.solde < -0.005 ? "neg" : "muted"}">Loyers reçus ${eur(s.recu)} sur ${eur(s.du)} dus${s.solde < -0.005 ? " · en retard de " + eur(-s.solde) : s.solde > 0.005 ? " · en avance de " + eur(s.solde) : " · à jour"}</div>`;
}

/* ---------- Performance (page Bilan) ---------- */
function occupation(id, y){
  const t0 = Date.parse(y + "-01-01"), tEnd = Math.min(Date.parse(y + "-12-31"), Date.parse(todayIso())); if (tEnd < t0) return null;
  const days = Math.round((tEnd - t0) / 864e5) + 1;
  const iv = live(S.locataires).filter(t => t.bien === id).map(t => [Math.max(t0, t.debut ? Date.parse(t.debut) : t0), Math.min(tEnd, t.fin ? Date.parse(t.fin) : tEnd)]).filter(x => x[1] >= x[0]).sort((a, b) => a[0] - b[0]);
  let cov = 0, cur = null; for (const x of iv){ if (!cur) cur = x.slice(); else if (x[0] <= cur[1] + 864e5) cur[1] = Math.max(cur[1], x[1]); else { cov += Math.round((cur[1] - cur[0]) / 864e5) + 1; cur = x.slice(); } }
  if (cur) cov += Math.round((cur[1] - cur[0]) / 864e5) + 1; return Math.min(100, Math.round(cov / days * 100));
}
const pct = v => (Math.round(v * 100) / 100).toString().replace(".", ",") + " %";
function perfCard(){
  const y = V.y, ids = bienIds(); let sumLoy = 0, sumRes = 0, sumPrix = 0, allPrix = true;
  const rows = ids.map(id => { const c = comptaBien(id, y), b = S.biens.find(x => x.id === id) || {}, prix = N(b.lmnp && b.lmnp.prix), s = stats(id, y), occ = occupation(id, y), e = empOf(id), ey = empYear(id, y);
    sumLoy += c.loyers; sumRes += c.resultat; if (prix > 0) sumPrix += prix; else allPrix = false;
    const rb = prix > 0 ? pct(c.loyers / prix * 100) : "—", rn = prix > 0 ? pct(c.resultat / prix * 100) : "—";
    return `<div class="env" style="padding:8px 0;gap:3px"><div class="top">${bienPill(id)}<span class="num ${signCl(s.cf)}">${eur(s.cf)}</span></div>
      ${kv("Loyers de l'année", eur(c.loyers))}${kv("Résultat indicatif (après intérêts)", eur(c.resultat), signCl(c.resultat))}
      ${kv("Rendement brut / net", rb + " / " + rn)}${occ != null ? kv("Taux d'occupation " + y, occ + " %") : ""}
      ${e && ey ? kv("Capital restant dû fin " + y, eur(ey.crd)) + kv("Capital déjà remboursé", eur(r2(e.capital - ey.crd))) : '<div class="small muted">Emprunt non renseigné (Compta › Logements).</div>'}
      ${prix > 0 ? "" : '<div class="small muted">Prix d\'achat non renseigné : pas de rendement (Compta › Logements).</div>'}</div>`; }).join("");
  const tot = sumPrix > 0 && allPrix ? `<div class="kv tot"><span>Rendement brut / net, tous biens</span><span class="num">${pct(sumLoy / sumPrix * 100)} / ${pct(sumRes / sumPrix * 100)}</span></div>` : "";
  return `<div class="card"><h2>Performance ${y}</h2><div class="small muted">Cash flow en haut à droite : loyers moins toutes les dépenses, crédit compris. Le rendement net utilise le résultat de la page Compta.</div>${rows}${tot}</div>`;
}
