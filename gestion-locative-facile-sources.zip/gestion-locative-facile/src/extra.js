/* ============ Extras : thèmes, nouveautés, aide, confort, exports ============ */
/* RÈGLE : à chaque nouvelle fonction, mettre à jour CHANGELOG (ci-dessous), le mode d'emploi HELP ET la fiche publique src/fiche.html (et, pour une grosse nouveauté, les affiches : voir src/affiches/README.txt). */
const APP_VERSION = "1.0.0";
const CHANGELOG = [
  {v:"1.0.0", date:"2026-10-26", titre:"Première version", items:["Gestion locative sur téléphone : loyers, quittances, locataires, baux, états des lieux, annonces, candidatures et bilans.","Location meublée ou vide : le bail, le dépôt de garantie et les délais s'adaptent au type choisi pour chaque logement.","Guide du bailleur : différences meublé / vide, colocation, régimes fiscaux, démarches et liens utiles. Courrier d'option LMNP prérempli.","Tes données restent sur ton téléphone : aucun envoi sur internet."]}
];

/* ---------- Petits utilitaires ---------- */
const pref = (k, d) => { const v = lsGet(k); return v == null ? d : v; };
const stripAcc = s => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const CAT_COL = ["#0E8F7E","#C2528B","#D98A1F","#4F7BD9","#8E5BD1","#C2503B","#5E9B3A","#2F8FB5","#B07A3C","#6C7A89"];
const catColor = n => { let h = 0; for (const c of String(n || "Autre")) h = (h * 31 + c.charCodeAt(0)) >>> 0; return CAT_COL[h % CAT_COL.length]; };
const lastDay = (y, m) => y + "-" + pad(m + 1) + "-" + pad(new Date(y, m + 1, 0).getDate());
const soldeAt = (id, iso) => { const b = S.biens.find(x => x.id === id); return r2(N(b && b.solde0) + sum(J().filter(j => j.bien === id && j.date <= iso).map(impact))); };
const nbsp = s => String(s).replace(/[  ]/g, " ");

/* ---------- Thèmes ---------- */
const PAL_NAMES = {emeraude:"Émeraude", ocean:"Océan", violet:"Violet", soleil:"Coucher de soleil", rose:"Rose"};
const schedGet = () => { try { return Object.assign({from:"20:00", to:"07:00"}, JSON.parse(lsGet("glf-sched") || "{}")); } catch(e){ return {from:"20:00", to:"07:00"}; } };
function themeCard(){
  const cur = pref("glf-pal", "emeraude"), mode = pref("glf-theme", "auto"), sc = schedGet();
  return `<div class="card"><h2>Apparence</h2>
    <div class="small muted">Couleur de l'appli</div>
    <div class="pals">${Object.keys(PAL_NAMES).map(k => `<button class="pal ${cur === k ? "on" : ""}" data-act="pal" data-v="${k}"><i style="background:${LOC_PALS[k][0]}"></i>${PAL_NAMES[k]}</button>`).join("")}</div>
    <div class="small muted">Mode clair ou sombre</div>
    <div class="seg">${[["auto","Automatique"],["light","Clair"],["dark","Sombre"],["sched","Horaires"]].map(([k, l]) => `<button class="${mode === k ? "on" : ""}" data-act="tmode" data-v="${k}">${l}</button>`).join("")}</div>
    ${mode === "sched" ? `<div class="tl"><label class="f">Sombre à partir de<input type="time" id="sc-from" value="${sc.from}"></label><label class="f">Clair à partir de<input type="time" id="sc-to" value="${sc.to}"></label></div>
      <div class="small muted">L'heure est vérifiée chaque minute et quand tu reviens dans l'appli.</div>` : mode === "auto" ? `<div class="small muted">Suit le réglage de ton iPhone.</div>` : ""}</div>`;
}
function confortCard(){
  const st = pref("glf-start", "home"), rm = pref("glf-remind", "1");
  return `<div class="card"><h2>Confort</h2>
    <div class="small muted">Écran au démarrage (aussi après le code)</div>
    <div class="seg"><button class="${st === "home" ? "on" : ""}" data-act="set-start" data-v="home">Accueil</button><button class="${st === "add" ? "on" : ""}" data-act="set-start" data-v="add">Ajouter</button></div>
    <div class="small muted">Rappel des lignes à pointer (une fois par jour)</div>
    <div class="seg"><button class="${rm === "1" ? "on" : ""}" data-act="set-remind" data-v="1">Activé</button><button class="${rm === "0" ? "on" : ""}" data-act="set-remind" data-v="0">Désactivé</button></div></div>`;
}
setInterval(() => applyTheme(), 60000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) applyTheme(); });
try { matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => applyTheme()); } catch(e){}

/* ---------- Mode d'emploi (aide par écran) ---------- */
const HELP = {
  welcome:{t:"Premier lancement", p:"Quelques minutes pour installer tes biens.", l:[
    "Le bailleur (toi) apparaît sur les quittances et les bilans.",
    "Pour chaque bien : le nom, l'adresse, le solde du compte à une date de départ, le loyer, la mensualité de crédit et le régime fiscal.",
    "Le locataire est facultatif : tu peux l'ajouter plus tard dans Biens › Locataires.",
    "Si tu as déjà le classeur Excel, importe plutôt export_appli.xlsx : tout est repris tel quel."]},
  home:{t:"Accueil", p:"Le résumé de tes deux biens en un coup d'œil.", l:[
    "Le gros chiffre est le solde de tes comptes appartements. En dessous : un solde par bien.",
    "Le bandeau violet Bourse montre l'argent placé, pas dépensé, qu'il reste à récupérer. Le bouton enregistre un remboursement.",
    "Les trois tuiles (retard, à pointer, à saisir en compta) sont cliquables.",
    "Le bénéfice réalisé ne compte que ce qui est vraiment passé sur le compte (pointé)."]},
  cmp:{t:"Compta", p:"Ce qu'il faut pour remplir ta compta en ligne.", l:[
    "Les 5 onglets suivent le site : Synthèse, Logements, Échéances, Dépenses, Recettes. Remplis le site dans cet ordre.",
    "Dépenses et Recettes : une ligne par facture, avec l'article du site. Touche le rond quand c'est saisi. « Articles » change l'article d'une catégorie.",
    "Échéances : date, total, capital, intérêts pour chaque mois. Compare avec l'échéancier de ta banque.",
    "PDF : le dossier à imprimer, avec une case à cocher par ligne. Excel : mêmes colonnes que le site.",
    "Choisis l'année et le bien (ou « Tous »). Le résultat = loyers − charges − intérêts d'emprunt − assurance emprunteur.",
    "Les charges sont rangées par poste, comme sur le site. Le regroupement est indicatif : on l'ajustera.",
    "Emprunt : renseigne capital, taux, durée et date de la 1re échéance. L'appli calcule les intérêts de chaque année.",
    "« À ne pas oublier » (Synthèse) : TA liste de déclaration, cochée automatiquement d'après le journal de l'année. ❌ = rien trouvé, à vérifier. « Personnaliser ma liste » : choisis les postes à suivre, par logement ou global. « Word ⬇ » exporte la liste en .docx à imprimer. « Word ⬆ » importe TA liste Word : l'appli reconnaît les postes, te montre ce qu'elle a compris et tu vérifies avant d'enregistrer.",
    "« À saisir en compta » ouvre les dépenses payées pas encore saisies sur le site.",
    "Excel ou PDF : un fichier prêt à garder ou à consulter pendant que tu remplis le site."]},
  add:{t:"Ajouter une opération", p:"Une opération = une ligne du journal (comme dans Excel).", l:[
    "Choisis le type (Recette, Dépense, Épargne, Entrée), le bien et la date. « Les 2 (50/50) » coupe le montant entre les deux biens.",
    "Le montant se tape au pavé. Il est proposé automatiquement d'après le tarif en vigueur (tu peux le changer).",
    "« Pointé » = l'argent est vraiment passé sur le compte. Sans pointage, la ligne reste prévue et ne bouge pas le solde.",
    "Un loyer déjà prévu pour le mois est mis à jour, pas ajouté en double.",
    "Les modèles remplissent le formulaire en un appui. Ils se créent avec « Enregistrer comme modèle ».",
    "En modification, « Dupliquer » crée une copie que tu ajustes ensuite."]},
  month:{t:"Pointage", p:"Le mois, ligne par ligne.", l:[
    "Touche le rond d'une ligne pour la pointer quand tu la vois passer sur le relevé de banque.",
    "« À pointer » regroupe tout ce qui est passé mais pas encore vérifié. « À saisir en compta » : dépenses payées, pas encore saisies sur ton site de compta.",
    "Rechercher : un mot, un montant, une date ou un mois, dans tout le journal.",
    "Exporter : le bilan d'un mois ou d'une année complète, en Excel ou en PDF.",
    "Clôturer le mois : tu saisis le solde réel du relevé, l'appli crée l'ajustement si besoin et te propose ce que tu peux mettre de côté.",
    "Les lignes prévues sont archivées 30 jours après pointage (elles restent comptées partout). Le lien « archivées » les montre."]},
  "bld-loyers":{t:"Biens › Loyers", p:"Les loyers du bien choisi, mois par mois.", l:[
    "Le locataire actuel est affiché en haut.",
    "Touche le rond pour marquer un loyer encaissé. Touche la ligne pour le modifier. « Ajouter » crée un mois manquant.",
    "« À relancer » liste les loyers en retard ; « Relancer » prépare un SMS poli.",
    "Sur un loyer encaissé, « Quittance » fabrique le PDF."]},
  "bld-dep":{t:"Biens › Dépenses", p:"Les dépenses du bien choisi.", l:[
    "Total par catégorie, prochaines dépenses, puis la liste complète.",
    "Frais partagés (CFE, comptabilité, CGA/OGA, Rendement locatif) : tu saisis le total une fois, l'appli crée une ligne par bien."]},
  "bld-vue":{t:"Biens › Vue", p:"La fiche d'un bien pour l'année choisie.", l:[
    "La jauge montre le matelas (12 mois de loyer, on n'y touche pas), ce qui est réservé pour les 3 prochains mois et ce qui est utilisable.",
    "Livrets et placements : l'argent placé compte dans le total du bien ; « Ajouter des intérêts » note ce que le placement rapporte.",
    "« Modifier le bien » change le nom, l'adresse, le loyer ou le crédit. « Ajouter un bien » en crée un autre.",
    "Solde au 1er janvier, loyers, charges, cash flow et solde au 31/12.",
    "Le bloc Bourse donne le mis en bourse, le remboursé et le reste.",
    "Les charges sont rangées par catégorie, avec le reste à payer."]},
  "bld-travaux":{t:"Biens › Travaux", p:"Les factures de travaux et d'équipement.", l:[
    "Touche une facture pour la modifier. « Scanné » et « Compta » se cochent d'un appui.",
    "La recherche filtre par fournisseur, description ou numéro."]},
  "bld-loc":{t:"Biens › Locataires", p:"Une fiche simple par locataire.", l:[
    "Nom, téléphone, bail, loyer et dépôt de garantie. Appeler, SMS ou e-mail en un appui.",
    "Les fiches restent sur ton téléphone (chiffrées si le code est activé) et dans le classeur Excel.",
    "Dans la fiche : le dossier de candidature, les documents du locataire (miniatures) et « Clôturer ce locataire » pour son départ.",
    "Le nom, l'adresse du bien et le loyer sont repris dans les relances, les quittances et les bilans (Excel et PDF).",
    "« Dont charges » sert à séparer loyer et charges sur la quittance."]},
  "rent":{t:"Location", p:"Du candidat au départ du locataire, sans serveur : tout passe par ton e-mail.", l:[
    "1. Annonce : remplis les infos du bien, ajoute tes photos, crée le PDF à envoyer par Mail ou Messages, ou copie le texte pour un site d'annonces. Onglet « Mon texte » : écris ou importe (Word, .txt) ton propre texte ; il est utilisé tel quel, sans blocs ajoutés.",
    "2. Candidats : envoie le lien du 1er formulaire (infos de base) à chaque personne intéressée. Quand son e-mail arrive, copie le texte et colle-le avec « Coller une candidature ou un dossier reçu » : la fiche se remplit. Tu peux aussi créer une fiche à la main.",
    "3. Visite : note la date. « Écrire au candidat » propose toujours le bon courrier suivant ; après la visite il contient le 2e lien, le formulaire « dossier complet ».",
    "4. Dossier complet : le candidat y dépose chaque pièce (identité, domicile, contrat de travail, bulletins, avis d'imposition, garant…). Les fichiers portent leur vrai nom. Enregistre-les dans Fichiers, puis colle le texte « DOSSIER » et joins les fichiers : les pièces se cochent toutes seules.",
    "5. La note compare les revenus au loyer charges comprises (3 fois = vert). Elle est indicative : ne refuse jamais pour un motif discriminatoire.",
    "6. Retenir : crée le locataire du bien, garde son dossier dans sa fiche et prépare l'arrivée (bail, inventaire, état des lieux).",
    "7. Pendant la location : dans la fiche du locataire, « Documents du locataire » : ajoute depuis Fichiers (iCloud Drive…) ses papiers. Miniature ou « Ouvrir » = grand affichage, bouton pour enregistrer ou partager.",
    "8. Départ : fiche du locataire › « Clôturer ce locataire ». Date de fin, retenues, dépôt à rendre, étapes cochées ; tu choisis d'effacer ou non son dossier. Le suivi détaillé est dans Biens › Arrivée/Départ.",
    "Les fiches, pièces et documents restent sur cet appareil et ne sont pas dans la sauvegarde. Efface les dossiers des candidats non retenus."]},
  "bld-mvt":{t:"Biens › Arrivée/Départ", p:"La démarche complète, étape par étape.", l:[
    "Deux listes : le départ (en haut) et l'arrivée. Coche chaque étape quand elle est faite : la date s'inscrit.",
    "Les boutons ouvrent directement le bon document. À la sortie, l'inventaire et l'état des lieux reprennent ceux de l'entrée.",
    "Départ : « Clôturer ce locataire » (fiche du locataire) coche seul les étapes retenues, dépôt restitué et locataire clos.",
    "Ce sont des repères généraux : vérifie les délais et les règles sur service-public.fr avant chaque location."]},
  "bld-docs":{t:"Biens › Documents", p:"Tout ce qu'il faut pour un locataire, sans autre site.", l:[
    "Lettres : « Faire signer sur l\'écran » (bailleur, et locataire pour la restitution du dépôt) : le PDF signé est rangé dans les documents du locataire.",
    "Les papiers personnels d'un locataire (identité, contrat…) se rangent dans sa fiche, pas ici.",
    "Inventaire ou état des lieux d\'entrée : tu peux choisir un fichier (PDF, Excel, CSV) : l\'appli le recopie vierge dans la liste. « Garder comme modèle » ★ en fait ta liste standard, proposée par défaut pour chaque nouveau document.",
    "Avant de signer, « PDF de relecture » sort le document sans signature pour le relire avec le locataire.",
    "À la création d'un état des lieux ou d'un inventaire, tu peux reprendre la liste d'un autre document pour le préparer à l'avance.",
    "Le solde montre ce qui a été reçu par rapport à ce qui est dû depuis le début du bail. « Relancer » prépare le message.",
    "État des lieux : choisis les pièces, ouvre-en une, note l'état de chaque élément (Neuf, Bon, Moyen, Mauvais), ajoute des observations et des photos. Les compteurs et les clés se notent en haut.",
    "À la sortie, crée l'état de sortie : il reprend l'entrée. Ce qui est plus dégradé apparaît en rouge dans le PDF.",
    "Inventaire du mobilier : la liste minimale légale d'un meublé est préremplie. Ajoute ou retire des articles.",
    "Importer un document déjà fait : bail signé, état des lieux ou inventaire. Un inventaire Excel ou CSV est lu ; les autres formats sont gardés tels quels. L'état des lieux importé devient l'état d'entrée, prêt pour la sortie.",
    "Faire signer : le bailleur puis le locataire signent au doigt, sur ce téléphone. La date et l'heure sont ajoutées, avec une page de preuve. C'est une signature électronique simple, valable mais moins forte qu'un service certifié.",
    "Les photos et les documents importés restent sur le téléphone : ils ne vont ni dans la sauvegarde ni dans Excel, mais les photos sont jointes au PDF.",
    "Bail et lettres : relis chaque champ. Le dépôt de garantie ne peut pas dépasser 2 mois de loyer hors charges. Ces modèles ne remplacent pas un conseil juridique."]},
  "bld-tarifs":{t:"Biens › Tarifs", p:"Les montants qui changent en cours d'année.", l:[
    "Le tarif en vigueur est la ligne la plus récente dont la date est passée.",
    "« Nouveau tarif » ajoute une ligne. L'historique ne se modifie jamais.",
    "Les formulaires se pré-remplissent avec le tarif en vigueur."]},
  "bld-rapp":{t:"Biens › Rapprochement", p:"Comparer l'appli avec le relevé de banque.", l:[
    "Tape le solde réel du relevé. L'écart = réel − calculé.",
    "Si l'écart n'est pas nul, un bouton crée une seule ligne datée (qui compte dans le solde, pas dans le bénéfice).",
    "Rien n'est jamais corrigé en silence : une correction est toujours une nouvelle ligne."]},
  chart:{t:"Bilan", p:"Les chiffres de l'année.", l:[
    "Le cash flow = loyers − charges (encaissé + prévu).",
    "« Par bien » compare le Studio et le T2. « Mois par mois » : bleu = loyers, orange = charges.",
    "« Toutes les années » : résultats, soldes et bourse versée cumulée.",
    "Le bouton Exporter produit le bilan d'un mois ou de l'année complète (par bien, mois par mois, par catégorie, toutes les opérations), en Excel ou en PDF."]},
  set:{t:"Réglages", p:"Échange avec Excel, sécurité et confort.", l:[
    "Excel → appli : importe export_appli.xlsx. Appli → Excel : exporte le journal, puis lance l'import dans le classeur.",
    "Sauvegarde légère (.json) : tes données, sans photos ni fichiers. Sauvegarde complète avec fichiers (.zip) : tout, y compris pièces d'identité, contrats et photos des locataires ; à faire avant de changer de téléphone, et à restaurer en important le .zip tel quel.",
    "Aucune sauvegarde n'est chiffrée : garde-les dans un endroit privé, jamais dans un dossier partagé.",
    "Le code et Face ID chiffrent tes données sur le téléphone. Si tu oublies le code, il faut tout effacer puis réimporter depuis Excel.",
    "Matelas de sécurité : le nombre de mois de loyer que tu gardes toujours de côté (12 par défaut) et les mois de charges réservés (3). Ça règle le calcul de « Argent utilisable ».",
    "Où enregistrer les exports : sur PC ou Android, choisis un dossier une fois et tout s'y enregistre. Sur iPhone, iOS rouvre en général le dernier dossier utilisé dans « Enregistrer dans Fichiers ».",
    "Fiche de l'appli : une page de présentation à partager (bouton « Partager avec le descriptif ») et 3 affiches A4 + une carte d'aperçu, à voir en grand et à enregistrer ou envoyer.",
    "Bailleur et biens : modifiables ici. Le bailleur est repris sur les quittances et les bilans.",
    "Apparence : 5 palettes, et le mode sombre automatique, fixe ou à horaires.",
    "Limites : l'appli n'écrit jamais de formule dans Excel et ne touche pas aux colonnes calculées. Les exports PDF et Excel passent par la feuille de partage Apple (« Enregistrer dans Fichiers »)."]}
};
const helpKey = () => V.tab === "welcome" ? "welcome" : V.tab === "bld" ? "bld-" + V.bsub : V.tab;
const helpHtml = k => { const h = HELP[k]; return h ? `<h2>${esc(h.t)}</h2><p class="muted" style="margin:0">${esc(h.p)}</p><ul style="margin:4px 0 0;padding-left:18px;display:flex;flex-direction:column;gap:6px;font-size:14.5px">${h.l.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : ""; };
function sheetHelp(){ openSheet(helpHtml(helpKey()) + `<div class="btns"><button class="btn ghost" data-act="guide">Tout le guide</button><button class="btn" data-act="sheetclose">Compris</button></div>`); }
function sheetGuide(){
  openSheet(`<h2>Tout le guide</h2>${Object.keys(HELP).map(k => `<details class="h"><summary><span>${esc(HELP[k].t)}</span><span class="muted small">voir</span></summary><p class="muted">${esc(HELP[k].p)}</p><ul>${HELP[k].l.map(x => `<li>${esc(x)}</li>`).join("")}</ul></details>`).join("")}
    <div class="btns"><button class="btn ghost" data-act="tour">Revoir le parcours guidé</button><button class="btn" data-act="sheetclose">Fermer</button></div>`);
}
const TOUR = [
  ["Bienvenue", "Cette appli suit les loyers, les charges et les soldes de tes deux biens, et parle avec ton classeur Excel."],
  ["L'accueil", "Le solde de chaque bien, la bourse à récupérer et ce qu'il reste à faire. Le bouton ? de chaque écran explique la page."],
  ["Ajouter", "Le + du milieu ajoute une opération : type, bien, date, montant au pavé. Les modèles remplissent tout en un appui."],
  ["Pointer", "Quand une ligne est passée sur le relevé de banque, touche son rond. C'est ce qui fait bouger le solde."],
  ["Avec Excel", "Dans Réglages, importe export_appli.xlsx pour charger tes vrais biens. Tu vois pour l'instant des données d'exemple."]
];
function sheetTour(i){
  V.tourI = i; const [t, p] = TOUR[i], last = i === TOUR.length - 1;
  openSheet(`<div class="small muted">Étape ${i + 1} sur ${TOUR.length}</div><h2>${esc(t)}</h2><p style="margin:0;font-size:15px">${esc(p)}</p>
    <div class="btns">${i ? `<button class="btn ghost" data-act="tour-prev">Retour</button>` : ""}<button class="btn" style="flex:1" data-act="${last ? "tour-end" : "tour-next"}">${last ? "C'est parti" : "Suivant"}</button>${last ? "" : `<button class="btn ghost" data-act="tour-end">Passer</button>`}</div>`);
}
function sheetNews(e){ openSheet(`<div class="small muted">Nouveautés · version ${esc(e.v)} · ${frDate(e.date)}</div><h2>${esc(e.titre)}</h2><ul style="margin:0;padding-left:18px;display:flex;flex-direction:column;gap:6px;font-size:14.5px">${e.items.map(x => `<li>${esc(x)}</li>`).join("")}</ul><div class="btns"><button class="btn" style="flex:1" data-act="sheetclose">Compris</button></div>`); }
function histCard(){
  const all = V.histAll, L = all ? CHANGELOG : CHANGELOG.slice(0, 5);
  return `<div class="card"><h2>Historique des mises à jour</h2><div class="rows">${L.map(e => `<div class="row" style="align-items:flex-start"><div class="main"><div class="t">${esc(e.titre)}</div><div class="s">Version ${esc(e.v)} · ${frDate(e.date)}</div>
    <ul style="margin:4px 0 0;padding-left:16px;font-size:13px;color:var(--muted)">${e.items.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div></div>`).join("")}</div>
    ${!all && CHANGELOG.length > 5 ? `<div class="btns"><button class="btn ghost sm" data-act="hist-all">Voir les ${CHANGELOG.length - 5} autres mises à jour</button></div>` : ""}${all && CHANGELOG.length > 5 ? `<div class="btns"><button class="btn ghost sm" data-act="hist-less">Réduire</button></div>` : ""}</div>`;
}
const FICHE_TXT = "Gestion Locative Facile : l'appli de gestion locative sur téléphone.\n• Loyers, relances et quittances\n• Compta LMNP facilitée (PDF et Excel)\n• Bail, état des lieux et inventaire signés à l'écran\n• Annonce, candidatures et dossier du locataire\n• Bilans par mois ou par année\n• Sans serveur : tes données restent sur ton téléphone";
const AFFICHES = [["apercu.png", "Carte d'aperçu du lien"]];
const ficheUrl = () => new URL("fiche.html", location.href).toString();
const ficheCard = () => `<div class="card"><h2>Fiche de l'appli (à partager)</h2>
  <div class="small muted">Une page de présentation claire avec toutes les fonctions. « Partager » envoie le lien avec un court descriptif au-dessus (points importants) ; la page est mise à jour à chaque nouvelle version de l'appli.</div>
  <div class="affs">${AFFICHES.map(a => `<button type="button" data-act="aff-open" data-f="${a[0]}"><img src="${a[0]}" alt="${a[1]}" loading="lazy"><span>${a[1]}</span></button>`).join("")}</div>
  <div class="btns"><button class="btn sm" data-act="fiche-share">Partager avec le descriptif</button><button class="btn sm ghost" data-act="fiche-open">Voir la fiche</button><button class="btn sm ghost" data-act="fiche-copy">Copier le lien</button></div></div>`;
const aideCard = () => `<div class="card"><h2>Aide</h2><div class="btns"><button class="btn" data-act="guide">Tout le guide</button><button class="btn ghost" data-act="tour">Parcours guidé</button><button class="btn ghost" data-act="demo">Mode démo</button></div>
  <div class="small muted">Le mode démo charge des données d'exemple à la place des données de cet appareil.</div></div>`;

/* ---------- Routines de démarrage (aussi après le code) ---------- */
function bootRoutines(){
  if (!S) return;
  applyTheme();
  if (!live(S.biens).length && !S.demo){ V.tab = "welcome"; V.wz = V.wz || {step:0}; lsSet("glf-ver", APP_VERSION); render(); return; }
  V.tab = pref("glf-start", "home") === "add" ? "add" : "home"; if (V.tab === "add"){ V.editId = null; V.draft = null; V.back = null; }
  if (archivePass(false)) persist();
  render();
  const last = lsGet("glf-ver"), hadData = !!window.HAD_DATA;
  if (!last){ lsSet("glf-ver", APP_VERSION); if (hadData) return sheetNews(CHANGELOG[0]); }
  else if (last !== APP_VERSION){ lsSet("glf-ver", APP_VERSION); return sheetNews(CHANGELOG[0]); }
  if (pref("glf-remind", "1") === "1" && lsGet("glf-rday") !== todayIso()){
    const c = counts(now0.getFullYear()), n = c.pointer + c.retard;
    if (n > 0){ lsSet("glf-rday", todayIso());
      openSheet(`<h2>À pointer</h2><p style="margin:0">${c.pointer ? c.pointer + " ligne(s) à pointer" : ""}${c.pointer && c.retard ? " et " : ""}${c.retard ? c.retard + " loyer(s) en retard" : ""}.</p>
        <div class="btns"><button class="btn" style="flex:1" data-act="remind-go">Voir</button><button class="btn ghost" data-act="sheetclose">Plus tard</button></div>`); }
  }
}

/* ---------- Recherche dans tout le journal ---------- */
function searchJ(q){
  const toks = stripAcc(q).split(/\s+/).filter(Boolean); if (!toks.length) return [];
  return J().filter(j => { const h = stripAcc([j.lib, j.cat, j.fourn, j.note, j.type, bienName(j.bien), j.bien, frDate(j.date), j.date, MOIS[mo(j)], fmtNum(j.montant), r2(j.montant).toFixed(2).replace(".", ",")].join(" "));
    return toks.every(t => h.includes(t) || h.includes(t.replace(".", ","))); }).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 80);
}
function searchRes(q){ const L = searchJ(q); return q.trim() ? (L.length ? `<div class="small muted">${L.length}${L.length === 80 ? "+" : ""} résultat(s)</div><div class="rows">${L.map(j => jRow(j, true)).join("")}</div>` : '<div class="empty">Aucun résultat.</div>') : '<div class="empty">Tape un mot (« assurance »), un montant (« 413,02 »), une date (« 10/2026 ») ou un mois (« mars »).</div>'; }
function sheetSearch(){ openSheet(`<h2>Rechercher</h2><input class="search" id="sq" placeholder="Mot, montant, date, mois…" autocomplete="off" value="${esc(V.sq || "")}"><div id="sres">${searchRes(V.sq || "")}</div><div class="btns"><button class="btn ghost" data-act="sheetclose">Fermer</button></div>`); }

/* ---------- Modèles, doublon ---------- */
function modelesCard(){
  const M = S.modeles || [];
  return `<div class="card"><h2>Modèles d'ajout rapide</h2>${M.length ? `<div class="rows">${M.map(m => `<div class="row"><div class="main"><div class="t">${esc(m.nom)}</div><div class="s">${esc(m.type)} · ${esc(m.bien === "both" ? "Les 2" : bienName(m.bien))} · ${esc(m.cat || "")}${m.montant ? " · " + eur(m.montant) : ""}</div></div><button class="mini" data-act="md-del" data-id="${m.id}">Supprimer</button></div>`).join("")}</div>`
    : '<div class="small muted">Aucun modèle. Dans « Ajouter », remplis le formulaire puis touche « Enregistrer comme modèle ».</div>'}</div>`;
}
function sheetModele(){ openSheet(`<h2>Enregistrer comme modèle</h2><label class="f">Nom du modèle<input id="md-nom" placeholder="Ex. Syndic Studio"></label><div class="small muted">Le type, le bien, la catégorie, le libellé et le montant sont repris du formulaire.</div><div class="btns"><button class="btn" style="flex:1" data-act="md-save">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); }
function dupOp(id){
  const j = S.journal.find(x => x.id === id); if (!j) return;
  const c = Object.assign({}, j, {id:uid(), pointe:"", compta:"", justif:"", upd:Date.now()}); delete c.arch; delete c.done; delete c.del;
  if (c.date > todayIso()) c.fut = true; else delete c.fut;
  S.journal.push(c); persist(); V.back = V.back || "month"; V.editId = c.id; V.draft = null; V.tab = "add"; toast("Copie créée : ajuste-la puis enregistre"); render();
}

/* ---------- Archivage des lignes prévues ---------- */
const ARCH_DAYS = 30;
function archivePass(force){
  const t = todayIso(); let ch = 0;
  for (const j of S.journal){
    if (j.del) continue;
    if (j.arch && j.pointe !== "x"){ j.arch = false; ch++; }
    if (!j.fut && j.pointe !== "x" && j.date > t){ j.fut = true; ch++; }
    if (!j.fut || j.arch || j.pointe !== "x") continue;
    if (j.type === "Dépense" && !j.compta) continue;          // reste à saisir en compta : on ne le cache pas
    if (!j.done){ j.done = t; ch++; if (!force) continue; }
    const age = Math.round((new Date(t) - new Date(j.done)) / 864e5);
    if (force || age >= ARCH_DAYS){ j.arch = true; ch++; }
  }
  return ch;
}
const isArch = j => !!j.arch && j.pointe === "x";
const archList = () => J().filter(isArch);
const onPointe = j => { if (j.pointe === "x"){ if (j.fut) j.done = todayIso(); } else { j.arch = false; delete j.done; } };
const monthActions = () => `<div class="btns"><button class="btn ghost sm" data-act="srch">Rechercher</button><button class="btn ghost sm" data-act="export-open">Exporter</button>${V.mf === "mois" ? '<button class="btn ghost sm" data-act="clot-open">Clôturer le mois</button>' : ""}</div>`;
const modelesRow = ed => (ed || !(S.modeles || []).length) ? "" : `<div><div class="small muted" style="margin-bottom:4px">Modèles</div><div class="seg">${S.modeles.map(m => `<button data-act="md-use" data-id="${m.id}">${esc(m.nom)}</button>`).join("")}</div></div>`;
function archCard(){
  const n = archList().length;
  return `<div class="card"><h2>Archives</h2><div class="small muted">Les lignes prévues sont rangées ${ARCH_DAYS} jours après avoir été pointées. Elles restent comptées dans tous les soldes et bilans, et restent visibles dans Loyers, Biens et la recherche.</div>
    <div class="kv"><span>Lignes archivées</span><span class="num">${n}</span></div>
    <div class="btns"><button class="btn ghost" data-act="arch-now">Archiver maintenant</button>${n ? `<button class="btn ghost" data-act="arch-view">Voir les archivées</button>` : ""}</div></div>`;
}
function sheetArch(){ const L = archList().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 120);
  openSheet(`<h2>Lignes archivées (${archList().length})</h2><div class="rows">${L.map(j => `<div class="row"><div class="main"><div class="t">${esc(j.lib || j.cat)}</div><div class="s">${frDate(j.date)} ${bienPill(j.bien)} · ${eur(j.montant)}</div></div><button class="mini" data-act="arch-restore" data-id="${j.id}">Désarchiver</button></div>`).join("") || '<div class="empty">Aucune.</div>'}</div><div class="btns"><button class="btn ghost" data-act="sheetclose">Fermer</button></div>`); }

/* ---------- Clôture de fin de mois ---------- */
function sheetCloture(y, m){
  V.cl = {y, m}; const end = lastDay(y, m), nxt = m === 11 ? lastDay(y + 1, 0) : lastDay(y, m + 1), done = (S.clotures || []).find(c => c.ym === y + "-" + pad(m + 1));
  const rows = bienIds().map(id => { const calc = soldeAt(id, end), prev = r2(sum(J().filter(j => j.bien === id && j.type === "Dépense" && j.pointe !== "x" && j.date > end && j.date <= nxt).map(j => j.montant)));
    return `<div class="env" style="padding:8px 0;gap:6px"><div class="top">${bienPill(id)}<span class="num">${eur(calc)}</span></div><div class="small muted">Solde calculé au ${frDate(end)}</div>
      <label class="f">Solde réel du relevé (€)<input id="cl-r-${esc(id)}" data-bien="${esc(id)}" inputmode="decimal" placeholder="${fmtNum(calc)}"></label>
      <div class="kv"><span>Écart (réel − calculé)</span><span class="num" id="cl-e-${esc(id)}">${eur(0)}</span></div>
      <div class="small muted">Charges prévues le mois suivant : ${eur(prev)}</div>
      ${bourseOn() ? `<label class="f">À mettre de côté (€)<select id="cl-p-${esc(id)}"><option>Bourse</option><option>Livret A</option><option>PEL</option><option>Autre placement</option></select><input id="cl-s-${esc(id)}" data-bien="${esc(id)}" data-auto="1" data-prev="${prev}" inputmode="decimal" value="${fmtNum(Math.max(0, r2(calc - prev)))}"></label>` : ""}</div>`; }).join("");
  openSheet(`<h2>Clôture de ${MOIS[m].toLowerCase()} ${y}</h2>
    ${done ? `<div class="info">Ce mois est déjà clôturé (${frDate(done.ts)}).</div><div class="btns"><button class="btn danger" data-act="clot-undo" data-id="${done.id}">Annuler cette clôture</button></div>` : ""}
    <div class="small muted">1. Compare avec le relevé de banque. 2. Choisis ce que tu mets de côté (proposé : solde moins les charges prévues du mois suivant). Laisse le solde réel vide pour ne rien ajuster.</div>${rows}
    <div class="btns"><button class="btn" style="flex:1" data-act="clot-do">Clôturer le mois</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
const matelasCardSet = () => `<div class="card"><h2>Matelas de sécurité</h2>
  <div class="small muted">Le « matelas » est l'argent que tu gardes toujours de côté, exprimé en mois de loyer, avant de considérer que le reste est « utilisable » (page Accueil). Chacun choisit : 12 mois pour une grosse sécurité, 3 à 6 pour un matelas plus léger, 0 pour ne rien garder. Le « réservé » couvre les charges des prochains mois.</div>
  <div class="kv"><span>Matelas (mois de loyer)</span><span class="seg" style="width:auto"><button data-act="set-mat" data-k="matMois" data-v="-1">−</button><button class="on" style="min-width:48px">${matMois()}</button><button data-act="set-mat" data-k="matMois" data-v="1">+</button></span></div>
  <div class="kv"><span>Réservé (mois de charges à venir)</span><span class="seg" style="width:auto"><button data-act="set-mat" data-k="resMois" data-v="-1">−</button><button class="on" style="min-width:48px">${resMois()}</button><button data-act="set-mat" data-k="resMois" data-v="1">+</button></span></div>
  <div class="small muted">Valeurs par défaut : 12 et 3. Ça ne change aucune donnée, seulement le calcul de l'argent utilisable.</div></div>`;
const dirCard = () => { const ok = !!window.showDirectoryPicker;
  if (ok) setTimeout(() => dirGet().then(h => { const e = $("#dir-name"); if (e) e.textContent = h ? "Dossier actuel : « " + h.name + " »" : "Aucun dossier choisi : l'appli te demande où enregistrer à chaque fois."; }), 0);
  return `<div class="card"><h2>Où enregistrer les exports ?</h2>
  ${ok ? `<div class="small muted">Choisis un dossier une seule fois (par exemple un dossier OneDrive ou iCloud Drive) : le journal, les sauvegardes, les PDF et les bilans s'y enregistrent ensuite directement, sans repasser par la fenêtre « Enregistrer ». <b>Les sauvegardes gardent toujours le même nom : la nouvelle remplace l'ancienne</b>, tu n'accumules pas 20 fichiers. L'appli ne peut pas ouvrir le dossier à ta place : retrouve-le dans ton explorateur de fichiers. Si le dossier est supprimé ou l'accès refusé, l'enregistrement normal reprend.</div>
  <div class="small" id="dir-name"></div>
  <div class="btns"><button class="btn sm" data-act="dir-pick">Choisir le dossier</button><button class="btn sm ghost" data-act="dir-off">Ne plus utiliser</button></div>`
  : `<div class="small muted">Sur iPhone et iPad, Apple ne permet pas à une appli de mémoriser un dossier ni de l'ouvrir. Les sauvegardes gardent toujours le même nom (mes-locations-sauvegarde.json, …-complete.zip, journal_appli.xlsx) : si le fichier existe déjà dans le dossier, iOS propose « Remplacer » : choisis-le pour ne garder qu'une version. À l'enregistrement, choisis « Enregistrer dans Fichiers » : iOS rouvre en général le dernier dossier utilisé, donc après une première fois dans le bon dossier (OneDrive, iCloud Drive), tu y retombes directement. Sur un PC (Chrome ou Edge) ou un téléphone Android, un dossier fixe peut être choisi ici.</div>`}</div>`; };
const bourseCardSet = () => { const on = bourseOn(); return `<div class="card"><h2>Argent mis de côté (bourse, livret…)</h2>
  <div class="small muted">Chaque mois, tu peux mettre de côté l'argent qui reste sur le compte d'un bien, puis suivre ce qui est placé et ce qui est remboursé. Cet argent peut aller en bourse ou dans un autre placement (assurance vie, livret…) : l'appli ne fait que le suivre. Si tu n'en as pas besoin, masque cette partie : rien n'est supprimé.</div>
  <div class="seg"><button class="${on ? "on" : ""}" data-act="set-bourse" data-v="1">Affiché</button><button class="${on ? "" : "on"}" data-act="set-bourse" data-v="0">Masqué</button></div></div>`; };
function clUpdate(t){
  const id = t.dataset.bien, end = lastDay(V.cl.y, V.cl.m);
  if (/^cl-s-/.test(t.id)){ t.dataset.auto = "0"; return; }
  const calc = soldeAt(id, end), v = parseNum(t.value), has = t.value.trim() !== "" && v !== null, real = has ? v : calc, ec = has ? r2(v - calc) : 0;
  $("#cl-e-" + id).textContent = eur(ec); const s = $("#cl-s-" + id);
  if (s && s.dataset.auto === "1") s.value = fmtNum(Math.max(0, r2(real - N(+s.dataset.prev))));
}
function clotureDo(){
  const {y, m} = V.cl, end = lastDay(y, m), ym = y + "-" + pad(m + 1), made = [], t = Date.now();
  if ((S.clotures || []).find(c => c.ym === ym)) return toast("Ce mois est déjà clôturé");
  for (const id of bienIds()){
    const rr = $("#cl-r-" + id).value, calc = soldeAt(id, end), v = parseNum(rr);
    if (rr.trim() !== "" && v !== null){ const ec = r2(v - calc);
      if (ec){ const o = {id:uid(), date:end, bien:id, type:ec > 0 ? "Entrée" : "Sortie", cat:"Écart de rapprochement", lib:"Ajustement sur relevé banque du " + frDate(end), montant:Math.abs(ec), compte:"Bien", pointe:"x", compta:"", justif:"", fourn:"", note:"Solde réel relevé " + nbsp(eur(v)), upd:t}; S.journal.push(o); made.push(o.id); } }
    const sv = $("#cl-s-" + id) ? parseNum($("#cl-s-" + id).value) : null, pcat = $("#cl-p-" + id) ? $("#cl-p-" + id).value : "Bourse";
    if (sv && sv > 0){ const o = {id:uid(), date:end, bien:id, type:"Sortie", cat:pcat, lib:"Mise de côté fin " + MOIS[m].toLowerCase(), montant:r2(sv), compte:"Bien", pointe:"x", compta:"", justif:"", fourn:"", note:"Clôture de " + MOIS[m].toLowerCase() + " " + y, upd:t}; S.journal.push(o); made.push(o.id); }
  }
  S.clotures = (S.clotures || []).concat([{id:uid(), ym, ids:made, ts:todayIso()}]); persist(); closeSheet(); toast(made.length ? made.length + " ligne(s) créée(s)" : "Mois clôturé, rien à ajouter"); render();
}

/* ---------- PDF fabriqué dans l'appli (Helvetica, texte, plusieurs pages) ---------- */
const WIN = {"€":0x80,"‚":0x82,"„":0x84,"…":0x85,"‘":0x91,"’":0x92,"“":0x93,"”":0x94,"•":0x95,"–":0x96,"—":0x97};
function pdfStr(s){ s = String(s ?? "").replace(/[  ]/g, " ").replace(/−/g, "-").replace(/[→›]/g, ">").replace(/‹/g, "<"); let o = "";
  for (const ch of s){ const c = ch.codePointAt(0); let b = WIN[ch] ?? (c < 256 ? c : 63); if (b < 32) b = 32; o += (b === 40 || b === 41 || b === 92) ? "\\" + String.fromCharCode(b) : String.fromCharCode(b); } return o; }
function pdfW(s, size, bold){ let w = 0; for (const ch of String(s).replace(/[  ]/g, " ")){ w += /[0-9€]/.test(ch) ? 556 : /[ ,.]/.test(ch) ? 278 : /[-−+]/.test(ch) ? 333 : /[il|!']/.test(ch) ? 240 : /[mwMW]/.test(ch) ? 800 : /[A-Z]/.test(ch) ? 670 : 520; } return w * size / 1000 * (bold ? 1.06 : 1); }
const hexRgb = h => [1, 3, 5].map(i => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(3)).join(" ");
function PdfDoc(title){
  this.title = title; this.pages = []; this.W = 595; this.H = 842; this.M = 42; this.newPage();
}
PdfDoc.prototype.newPage = function(){ this.cur = []; this.pages.push(this.cur); this.y = this.H - 70; };
PdfDoc.prototype.need = function(h){ if (this.y - h < 60) this.newPage(); };
PdfDoc.prototype.text = function(x, y, s, o){ o = o || {}; const size = o.size || 10, w = pdfW(s, size, o.bold), xx = o.right ? x - w : o.center ? x - w / 2 : x;
  this.cur.push(`BT ${hexRgb(o.color || "#1B2430")} rg /${o.bold ? "F2" : "F1"} ${size} Tf ${xx.toFixed(1)} ${y.toFixed(1)} Td (${pdfStr(s)}) Tj ET`); };
PdfDoc.prototype.rect = function(x, y, w, h, c){ this.cur.push(`${hexRgb(c)} rg ${x.toFixed(1)} ${y.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re f`); };
PdfDoc.prototype.line = function(x1, y1, x2, y2, c){ this.cur.push(`${hexRgb(c || "#DDE5E1")} RG 0.6 w ${x1} ${y1} m ${x2} ${y2} l S`); };
PdfDoc.prototype.pill = function(x, y, s, col){ const w = pdfW(s, 8.5, true) + 12; this.rect(x, y - 3, w, 13, col); this.text(x + 6, y + 0.5, s, {size:8.5, bold:true, color:"#FFFFFF"}); return w; };
PdfDoc.prototype.para = function(str, size, gap){ const max = this.W - 2 * this.M; let line = "";
  const flush = () => { if (line){ this.need(size + 6); this.text(this.M, this.y, line, {size}); this.y -= gap || size + 5; line = ""; } };
  for (const w of String(str).split(" ")){ const t = line ? line + " " + w : w; if (pdfW(t, size) > max){ flush(); line = w; } else line = t; }
  flush(); };
PdfDoc.prototype.h = function(s, size){ this.need(34); this.y -= 8; this.text(this.M, this.y, s, {size:size || 13, bold:true, color:"#0E6B5C"}); this.y -= 16; };
PdfDoc.prototype.finish = function(sub){
  const n = this.pages.length, parts = ["%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"], off = [];
  const add = body => { off.push(parts.join("").length); parts.push((off.length) + " 0 obj\n" + body + "\nendobj\n"); };
  const idPage = i => 5 + i * 2, idCont = i => 6 + i * 2;
  add("<< /Type /Catalog /Pages 2 0 R >>");
  add("<< /Type /Pages /Kids [" + this.pages.map((_, i) => idPage(i) + " 0 R").join(" ") + "] /Count " + n + " >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
  this.pages.forEach((ops, i) => {
    const head = [], foot = [];
    this.cur = head; this.text(this.M, this.H - 40, "Gestion Locative Facile", {size:11, bold:true, color:"#0E6B5C"}); this.text(this.W - this.M, this.H - 40, sub || this.title, {size:9.5, right:true, color:"#5C6B66"}); this.line(this.M, this.H - 48, this.W - this.M, this.H - 48);
    this.cur = foot; this.line(this.M, 44, this.W - this.M, 44); this.text(this.M, 30, "Généré le " + frDate(todayIso()), {size:8.5, color:"#5C6B66"}); this.text(this.W - this.M, 30, "Page " + (i + 1) + " / " + n, {size:8.5, right:true, color:"#5C6B66"});
    const stream = head.concat(ops, foot).join("\n");
    add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + this.W + " " + this.H + "] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents " + idCont(i) + " 0 R >>");
    add("<< /Length " + stream.length + " >>\nstream\n" + stream + "\nendstream");
  });
  const body = parts.join(""); let xref = "xref\n0 " + (off.length + 1) + "\n0000000000 65535 f \n" + off.map(o => String(o).padStart(10, "0") + " 00000 n \n").join("");
  const out = body + xref + "trailer\n<< /Size " + (off.length + 1) + " /Root 1 0 R >>\nstartxref\n" + body.length + "\n%%EOF";
  const u = new Uint8Array(out.length); for (let i = 0; i < out.length; i++) u[i] = out.charCodeAt(i) & 255; return u;
};

/* ---------- Bilan d'un mois : données, Excel, PDF ---------- */
function monthBilan(y, m){
  const end = lastDay(y, m), start = y + "-" + pad(m + 1) + "-01", L = J().filter(j => yr(j) === y && mo(j) === m).sort((a, b) => a.date.localeCompare(b.date));
  const per = bienIds().map(id => { const l = L.filter(j => j.bien === id), rec = sum(l.filter(j => j.type === "Recette").map(j => j.montant)), dep = sum(l.filter(j => j.type === "Dépense").map(j => j.montant));
    return {id, rec:r2(rec), dep:r2(dep), res:r2(rec - dep), recP:r2(sum(l.filter(j => j.type === "Recette" && j.pointe === "x").map(j => j.montant))), depP:r2(sum(l.filter(j => j.type === "Dépense" && j.pointe === "x").map(j => j.montant))),
      debut:soldeAt(id, new Date(new Date(start) - 864e5).toISOString().slice(0, 10)), fin:soldeAt(id, end)}; });
  const fixes = []; for (const id of bienIds()) for (const p of POSTES_TARIF){ const v = tarifFor(id, p, end); if (v != null) fixes.push([bienName(id), p, v]); }
  const part = partagesList().map(p => { const [a, b] = splitPartage(p.total, p.partStudio); return [p.frais, p.total, (Math.round(p.partStudio * 1000) / 10) + " %", a, b]; });
  const info = bienIds().map(id => { const bn = S.biens.find(b => b.id === id) || {}, T = live(S.locataires).filter(t => t.bien === id && (!t.debut || t.debut <= end) && (!t.fin || t.fin >= start)), tt = T.length ? T : [tenantFor(id, end)].filter(Boolean);
    return {id, nom:bn.nom || id, adresse:bn.adresse || "", regime:bn.regime || "", tenants:tt}; });
  return {y, m, end, L, per, fixes, part, info, bailleur:(S.cfg && S.cfg.bailleur) || "", badr:(S.cfg && S.cfg.bailleurAdr) || "", tot:{rec:r2(sum(per.map(p => p.rec))), dep:r2(sum(per.map(p => p.dep)))}};
}
function bilanXlsx(y, m){
  const B = monthBilan(y, m), wb = XLSX.utils.book_new(), dt = iso => isoToSerial(iso);
  const add = (name, aoa, widths, fmt) => { const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = widths.map(w => ({wch:w}));
    for (const k of Object.keys(ws)){ if (k[0] === "!") continue; const c = ws[k]; if (c.t === "n" && fmt && fmt(k, c)) c.z = fmt(k, c); } XLSX.utils.book_append_sheet(wb, ws, name); };
  const money = "#,##0.00 \"€\"";
  add("Bilan", [["Bilan de " + MOIS[m].toLowerCase() + " " + y], [B.bailleur ? "Bailleur : " + B.bailleur + (B.badr ? " · " + B.badr : "") : ""], ["Bien", "Recettes prévues", "Dépenses prévues", "Résultat", "Recettes encaissées", "Dépenses payées", "Solde début de mois", "Solde fin de mois"]]
    .concat(B.per.map(p => [bienName(p.id), p.rec, p.dep, p.res, p.recP, p.depP, p.debut, p.fin])).concat([["Total", B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep), r2(sum(B.per.map(p => p.recP))), r2(sum(B.per.map(p => p.depP))), r2(sum(B.per.map(p => p.debut))), r2(sum(B.per.map(p => p.fin)))]]),
    [22, 16, 16, 14, 18, 16, 18, 18], (k, c) => /^[B-H]/.test(k) && +k.slice(1) > 3 ? money : null);
  add("Fixes", [["Tarifs en vigueur fin " + MOIS[m].toLowerCase()], [], ["Bien", "Poste", "Montant mensuel"]].concat(B.fixes).concat([[], ["Frais partagés", "Total", "Part Studio (%)", "Montant Studio", "Montant T2"]]).concat(B.part).concat([[], ["Biens et locataires"], ["Bien", "Adresse", "Régime", "Locataire", "Téléphone", "E-mail", "Début du bail", "Fin du bail", "Loyer charges comprises", "Dont charges", "Dépôt de garantie"]]).concat(B.info.flatMap(i => (i.tenants.length ? i.tenants : [null]).map(t => [i.nom, i.adresse, i.regime, t ? t.nom : "(aucun locataire)", t ? t.tel : "", t ? t.email : "", t ? frDate(t.debut) : "", t ? (t.fin ? frDate(t.fin) : "en cours") : "", t ? t.loyer : "", t ? t.charges || 0 : "", t ? t.depot : ""]))),
    [22, 30, 18, 22, 16, 26, 14, 14, 18, 14, 16], (k, c) => /^[B-K]/.test(k) && +k.slice(1) > 3 ? money : null);
  const ops = [["Date", "Bien", "Type", "Catégorie", "Libellé", "Montant", "Compte", "Pointé", "Saisi compta", "Fournisseur / n° facture", "Note"]].concat(B.L.map(j => [dt(j.date), bienName(j.bien), j.type, j.cat, j.lib, j.montant, j.compte || "Bien", j.pointe === "x" ? "x" : "", j.compta ? "x" : "", j.fourn, j.note]));
  add("Opérations", ops, [12, 16, 11, 26, 34, 14, 10, 8, 12, 24, 30], (k, c) => k[0] === "A" && +k.slice(1) > 1 ? "dd/mm/yyyy" : (k[0] === "F" && +k.slice(1) > 1 ? money : null));
  return XLSX.write(wb, {type:"array", bookType:"xlsx", compression:true});
}
function bilanPdf(y, m){
  const B = monthBilan(y, m), d = new PdfDoc("Bilan"), M = d.M, R = d.W - M;
  d.text(M, d.y, "Bilan de " + MOIS[m].toLowerCase() + " " + y, {size:20, bold:true}); d.y -= 26;
  d.text(M, d.y, "Du " + frDate(y + "-" + pad(m + 1) + "-01") + " au " + frDate(B.end), {size:10, color:"#5C6B66"}); d.y -= 13;
  if (B.bailleur) d.para("Bailleur : " + B.bailleur + (B.badr ? " - " + B.badr : ""), 10, 13);
  d.h("Par bien");
  const cols = [M, 220, 300, 380, R]; ["Bien", "Recettes", "Dépenses", "Résultat", "Solde fin de mois"].forEach((t, i) => d.text(i ? [0, 285, 365, 445, R][i] : M, d.y, t, {size:9, bold:true, right:i > 0, color:"#5C6B66"})); d.y -= 6; d.line(M, d.y, R, d.y); d.y -= 15;
  for (const p of B.per){ d.pill(M, d.y, bienName(p.id), BIEN_COL[p.id] || "#0E6B5C"); [p.rec, p.dep, p.res, p.fin].forEach((v, i) => d.text([285, 365, 445, R][i], d.y, eur(v), {size:10, right:true, bold:i === 2})); d.y -= 20; }
  d.line(M, d.y + 8, R, d.y + 8); d.text(M, d.y - 4, "Total", {size:10, bold:true}); [B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep), r2(sum(B.per.map(p => p.fin)))].forEach((v, i) => d.text([285, 365, 445, R][i], d.y - 4, eur(v), {size:10, right:true, bold:true})); d.y -= 22;
  d.para("Les montants comptent les lignes prévues et pointées du mois ; le solde ne compte que ce qui est passé sur le compte.", 8.5, 12);
  d.h("Biens et locataires");
  for (const i of B.info){ d.need(60); d.pill(M, d.y, i.nom.slice(0, 18), BIEN_COL[i.id] || "#0E6B5C"); d.text(M + 120, d.y, [i.adresse, i.regime].filter(Boolean).join(" - ").slice(0, 70), {size:9.5, color:"#5C6B66"}); d.y -= 15;
    for (const t of i.tenants){ d.para("Locataire : " + t.nom + (t.tel ? " - " + t.tel : "") + (t.email ? " - " + t.email : ""), 9.5, 12.5);
      d.para("Bail du " + (t.debut ? frDate(t.debut) : "?") + " au " + (t.fin ? frDate(t.fin) : "en cours") + " - loyer charges comprises " + eur(t.loyer) + (t.charges ? " (dont charges " + eur(t.charges) + ")" : "") + " - dépôt de garantie " + eur(t.depot), 9.5, 12.5); }
    if (!i.tenants.length) d.para("Aucun locataire enregistré.", 9.5, 12.5); d.y -= 4; }
  d.h("Tarifs en vigueur");
  for (const f of B.fixes){ d.need(16); d.text(M, d.y, f[0] + " · " + f[1], {size:10}); d.text(R, d.y, eur(f[2]), {size:10, right:true}); d.y -= 15; }
  d.h("Frais partagés entre les 2 comptes");
  for (const f of B.part){ d.need(16); d.text(M, d.y, f[0], {size:10}); d.text(R, d.y, "Total " + eur(f[1]) + " · Studio " + eur(f[3]) + " · T2 " + eur(f[4]), {size:9.5, right:true}); d.y -= 15; }
  d.h("Opérations (" + B.L.length + ")");
  const head = () => { ["Date", "Bien", "Catégorie · libellé"].forEach((t, i) => d.text([M, M + 58, M + 118][i], d.y, t, {size:9, bold:true, color:"#5C6B66"})); d.text(R - 40, d.y, "Montant", {size:9, bold:true, right:true, color:"#5C6B66"}); d.text(R, d.y, "Pointé", {size:9, bold:true, right:true, color:"#5C6B66"}); d.y -= 5; d.line(M, d.y, R, d.y); d.y -= 14; };
  head();
  for (const j of B.L){ if (d.y < 78){ d.newPage(); head(); }
    d.text(M, d.y, frDate(j.date), {size:9}); d.pill(M + 58, d.y, String(j.bien).slice(0, 7), BIEN_COL[j.bien] || "#0E6B5C");
    const lib = ((j.cat || "") + (j.lib && j.lib !== j.cat ? " · " + j.lib : "")).slice(0, 46); d.text(M + 118, d.y, lib, {size:9});
    d.text(R - 40, d.y, (isIn(j) ? "+ " : "- ") + eur(j.montant), {size:9, right:true, color:isIn(j) ? "#1E7F4F" : "#1B2430"}); d.text(R, d.y, j.pointe === "x" ? "oui" : "", {size:9, right:true, color:"#5C6B66"}); d.y -= 15; }
  if (!B.L.length) d.text(M, d.y, "Aucune opération ce mois-ci.", {size:10, color:"#5C6B66"});
  return d.finish("Bilan " + MOIS[m].toLowerCase() + " " + y);
}
/* ---------- Bilan d'une année : données, Excel, PDF ---------- */
function yearBilan(y){
  const ids = bienIds(), L = J().filter(j => yr(j) === y).sort((a, b) => a.date.localeCompare(b.date)), S0 = (y - 1) + "-12-31", S1 = y + "-12-31";
  const sm = (l, t, pt) => r2(sum(l.filter(j => (t === "R" ? j.type === "Recette" : j.type === "Dépense") && (!pt || j.pointe === "x")).map(j => j.montant)));
  const per = ids.map(id => { const l = L.filter(j => j.bien === id), rec = sm(l, "R"), dep = sm(l, "D"); return {id, rec, dep, res:r2(rec - dep), recP:sm(l, "R", 1), depP:sm(l, "D", 1), debut:soldeAt(id, S0), fin:soldeAt(id, S1)}; });
  const mois = MOIS.map((nom, m) => { const l = L.filter(j => mo(j) === m); return {nom, par:ids.map(id => { const x = l.filter(j => j.bien === id), r = sm(x, "R"), d = sm(x, "D"); return {rec:r, dep:d, res:r2(r - d)}; }), rec:sm(l, "R"), dep:sm(l, "D"), res:r2(sm(l, "R") - sm(l, "D"))}; });
  const cats = []; for (const id of ids) for (const t of ["Recette", "Dépense"]){ const g = {}; L.filter(j => j.bien === id && j.type === t).forEach(j => { const c = j.cat || "Sans catégorie"; (g[c] = g[c] || {t:0, n:0}); g[c].t += j.montant; g[c].n++; });
    Object.keys(g).sort((a, b) => g[b].t - g[a].t).forEach(c => cats.push([bienName(id), t, c, r2(g[c].t), g[c].n])); }
  const tot = {rec:r2(sum(per.map(p => p.rec))), dep:r2(sum(per.map(p => p.dep)))};
  return {y, L, ids, per, mois, cats, tot, bailleur:(S.cfg && S.cfg.bailleur) || "", badr:(S.cfg && S.cfg.bailleurAdr) || ""};
}
function bilanAnXlsx(y){
  const B = yearBilan(y), wb = XLSX.utils.book_new(), dt = iso => isoToSerial(iso), money = "#,##0.00 \"€\"";
  const add = (name, aoa, widths, fmt) => { const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = widths.map(w => ({wch:w}));
    for (const k of Object.keys(ws)){ if (k[0] === "!") continue; const c = ws[k]; if (c.t === "n" && fmt && fmt(k, c)) c.z = fmt(k, c); } XLSX.utils.book_append_sheet(wb, ws, name); };
  add("Bilan annuel", [["Bilan de l'année " + y], [B.bailleur ? "Bailleur : " + B.bailleur + (B.badr ? " · " + B.badr : "") : ""], ["Bien", "Recettes prévues", "Dépenses prévues", "Résultat", "Recettes encaissées", "Dépenses payées", "Solde début d'année", "Solde fin d'année"]]
    .concat(B.per.map(p => [bienName(p.id), p.rec, p.dep, p.res, p.recP, p.depP, p.debut, p.fin])).concat([["Total", B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep), r2(sum(B.per.map(p => p.recP))), r2(sum(B.per.map(p => p.depP))), r2(sum(B.per.map(p => p.debut))), r2(sum(B.per.map(p => p.fin)))]]),
    [22, 16, 16, 14, 18, 16, 18, 18], (k, c) => /^[B-H]/.test(k) && +k.slice(1) > 3 ? money : null);
  const head = ["Mois"]; B.ids.forEach(id => head.push(bienName(id) + " recettes", bienName(id) + " dépenses", bienName(id) + " résultat")); head.push("Total recettes", "Total dépenses", "Total résultat");
  add("Mois par mois", [["Mois par mois en " + y], [], head].concat(B.mois.map(m => { const r = [m.nom]; m.par.forEach(p => r.push(p.rec, p.dep, p.res)); r.push(m.rec, m.dep, m.res); return r; }))
    .concat([["Total année"].concat(...B.per.map(p => [p.rec, p.dep, p.res]), [B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep)])]), head.map((_, i) => i ? 16 : 14), (k, c) => k[0] !== "A" && +k.slice(1) > 3 ? money : null);
  add("Par catégorie", [["Totaux par bien et par catégorie en " + y], [], ["Bien", "Type", "Catégorie", "Total", "Nombre de lignes"]].concat(B.cats), [22, 12, 30, 16, 16], (k, c) => k[0] === "D" && +k.slice(1) > 3 ? money : null);
  add("Opérations", [["Date", "Bien", "Type", "Catégorie", "Libellé", "Montant", "Compte", "Pointé", "Saisi compta", "Fournisseur / n° facture", "Note"]].concat(B.L.map(j => [dt(j.date), bienName(j.bien), j.type, j.cat, j.lib, j.montant, j.compte || "Bien", j.pointe === "x" ? "x" : "", j.compta ? "x" : "", j.fourn, j.note])),
    [12, 16, 11, 26, 34, 14, 10, 8, 12, 24, 30], (k, c) => k[0] === "A" && +k.slice(1) > 1 ? "dd/mm/yyyy" : (k[0] === "F" && +k.slice(1) > 1 ? money : null));
  return XLSX.write(wb, {type:"array", bookType:"xlsx", compression:true});
}
function bilanAnPdf(y){
  const B = yearBilan(y), d = new PdfDoc("Bilan"), M = d.M, R = d.W - M, X = [285, 365, 445, R];
  d.text(M, d.y, "Bilan de l'année " + y, {size:20, bold:true}); d.y -= 26;
  d.text(M, d.y, "Du 01/01/" + y + " au 31/12/" + y, {size:10, color:"#5C6B66"}); d.y -= 13;
  if (B.bailleur) d.para("Bailleur : " + B.bailleur + (B.badr ? " - " + B.badr : ""), 10, 13);
  d.h("Par bien");
  ["Bien", "Recettes", "Dépenses", "Résultat", "Solde fin d'année"].forEach((t, i) => d.text(i ? X[i - 1] : M, d.y, t, {size:9, bold:true, right:i > 0, color:"#5C6B66"})); d.y -= 6; d.line(M, d.y, R, d.y); d.y -= 15;
  for (const p of B.per){ d.pill(M, d.y, bienName(p.id), BIEN_COL[p.id] || "#0E6B5C"); [p.rec, p.dep, p.res, p.fin].forEach((v, i) => d.text(X[i], d.y, eur(v), {size:10, right:true, bold:i === 2})); d.y -= 20; }
  d.line(M, d.y + 8, R, d.y + 8); d.text(M, d.y - 4, "Total", {size:10, bold:true}); [B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep), r2(sum(B.per.map(p => p.fin)))].forEach((v, i) => d.text(X[i], d.y - 4, eur(v), {size:10, right:true, bold:true})); d.y -= 22;
  d.para("Les montants comptent les lignes prévues et pointées de l'année (crédit compris) ; le solde ne compte que ce qui est passé sur le compte.", 8.5, 12);
  d.h("Mois par mois");
  ["Mois", "Recettes", "Dépenses", "Résultat"].forEach((t, i) => d.text(i ? X[i - 1] : M, d.y, t, {size:9, bold:true, right:i > 0, color:"#5C6B66"})); d.y -= 6; d.line(M, d.y, R, d.y); d.y -= 15;
  for (const m of B.mois){ d.need(16); d.text(M, d.y, m.nom, {size:10}); [m.rec, m.dep, m.res].forEach((v, i) => d.text(X[i], d.y, eur(v), {size:10, right:true, bold:i === 2})); d.y -= 15; }
  d.line(M, d.y + 8, R, d.y + 8); d.text(M, d.y - 4, "Année", {size:10, bold:true}); [B.tot.rec, B.tot.dep, r2(B.tot.rec - B.tot.dep)].forEach((v, i) => d.text(X[i], d.y - 4, eur(v), {size:10, right:true, bold:true})); d.y -= 22;
  d.h("Par catégorie");
  let last = ""; for (const c of B.cats){ const k = c[0] + c[1]; if (k !== last){ d.need(34); d.y -= 4; d.pill(M, d.y, c[0].slice(0, 18), BIEN_COL[B.ids.find(i => bienName(i) === c[0])] || "#0E6B5C"); d.text(M + 120, d.y, c[1] === "Recette" ? "Recettes" : "Dépenses", {size:9.5, bold:true, color:"#5C6B66"}); d.y -= 16; last = k; }
    d.need(15); d.text(M + 8, d.y, (c[2] || "").slice(0, 50) + (c[4] > 1 ? " (" + c[4] + ")" : ""), {size:9.5}); d.text(R, d.y, eur(c[3]), {size:9.5, right:true}); d.y -= 14; }
  d.h("Opérations (" + B.L.length + ")");
  const head = () => { ["Date", "Bien", "Catégorie · libellé"].forEach((t, i) => d.text([M, M + 58, M + 118][i], d.y, t, {size:9, bold:true, color:"#5C6B66"})); d.text(R - 40, d.y, "Montant", {size:9, bold:true, right:true, color:"#5C6B66"}); d.text(R, d.y, "Pointé", {size:9, bold:true, right:true, color:"#5C6B66"}); d.y -= 5; d.line(M, d.y, R, d.y); d.y -= 14; };
  head();
  for (const j of B.L){ if (d.y < 78){ d.newPage(); head(); }
    d.text(M, d.y, frDate(j.date), {size:9}); d.pill(M + 58, d.y, String(j.bien).slice(0, 7), BIEN_COL[j.bien] || "#0E6B5C");
    const lib = ((j.cat || "") + (j.lib && j.lib !== j.cat ? " · " + j.lib : "")).slice(0, 46); d.text(M + 118, d.y, lib, {size:9});
    d.text(R - 40, d.y, (isIn(j) ? "+ " : "- ") + eur(j.montant), {size:9, right:true, color:isIn(j) ? "#1E7F4F" : "#1B2430"}); d.text(R, d.y, j.pointe === "x" ? "oui" : "", {size:9, right:true, color:"#5C6B66"}); d.y -= 15; }
  if (!B.L.length) d.text(M, d.y, "Aucune opération cette année.", {size:10, color:"#5C6B66"});
  return d.finish("Bilan " + y);
}
function sheetExport(){
  const set = new Set(J().map(j => j.date.slice(0, 7))); set.add(V.y + "-" + pad(V.m + 1)); const sel = V.y + "-" + pad(V.m + 1);
  const list = [...set].sort().reverse().slice(0, 48);
  const yrs = [...new Set(J().map(j => j.date.slice(0, 4)).concat([String(V.y)]))].sort().reverse();
  openSheet(`<h2>Exporter un bilan</h2><label class="f">Période<select id="ex-m"><optgroup label="Année complète">${yrs.map(y => `<option value="A${y}">Année ${y}</option>`).join("")}</optgroup><optgroup label="Un mois">${list.map(k => `<option value="${k}" ${k === sel ? "selected" : ""}>${MOIS[+k.slice(5) - 1]} ${k.slice(0, 4)}</option>`).join("")}</optgroup></select></label>
    <div class="small muted"><b>Un mois</b> : Excel en 3 feuilles (Bilan, Fixes, Opérations) ; PDF de plusieurs pages.<br><b>Année complète</b> : Excel en 4 feuilles (Bilan annuel, Mois par mois, Par catégorie, Opérations) ; PDF avec le bilan par bien, les 12 mois, les totaux par catégorie et toutes les opérations. Pratique pour la compta de fin d'année.<br>Ensuite, choisis « Enregistrer dans Fichiers ».</div>
    <div class="btns"><button class="btn" data-act="ex-xlsx" style="flex:1">Excel (.xlsx)</button><button class="btn" data-act="ex-pdf" style="flex:1">PDF</button></div><div class="btns"><button class="btn ghost" data-act="sheetclose">Fermer</button></div>`);
}

/* ---------- Quittance de loyer (PDF) ---------- */
function sheetQuittance(id){
  const j = S.journal.find(x => x.id === id), t = tenantFor(j.bien, j.date), cfg = S.cfg = S.cfg || {bailleur:"", adr:{}}, bn = S.biens.find(b => b.id === j.bien) || {}; V.q = id;
  const chg = Math.min(N(t && t.charges), j.montant), adr = bn.adresse || (cfg.adr || {})[j.bien] || "";
  openSheet(`<h2>Quittance · ${esc(bienName(j.bien))} · ${MOIS[mo(j)].toLowerCase()} ${yr(j)}</h2>
    <label class="f">Bailleur (nom)<input id="q-bail" value="${esc(cfg.bailleur || "")}"></label>
    <label class="f">Adresse du bailleur<input id="q-badr" value="${esc(cfg.bailleurAdr || "")}"></label>
    <label class="f">Locataire<input id="q-loc" value="${esc(t ? t.nom : "")}" placeholder="Nom du locataire"></label>
    <label class="f">Adresse du logement<input id="q-adr" value="${esc(adr)}"></label>
    <div class="grid2"><label class="f">Loyer hors charges (€)<input id="q-loyer" inputmode="decimal" value="${fmtNum(r2(j.montant - chg))}"></label><label class="f">Charges (€)<input id="q-chg" inputmode="decimal" value="${fmtNum(chg)}"></label></div>
    <label class="f">Montant réellement reçu (€) <span class="muted small">— à changer seulement si le locataire a payé moins : le document devient un reçu</span><input id="q-recu" inputmode="decimal" placeholder="${fmtNum(j.montant)}"></label>
    <label class="f">Fait à (ville)<input id="q-ville" value="${esc(cfg.ville || "")}"></label>
    <div class="small muted">Ces informations restent sur ton téléphone (chiffrées si le code est activé).</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="quit-pdf">Créer le PDF</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
/* montant en lettres (français) */
function enLettres(n){
  const U = ["zéro","un","deux","trois","quatre","cinq","six","sept","huit","neuf","dix","onze","douze","treize","quatorze","quinze","seize","dix-sept","dix-huit","dix-neuf"], D = ["","","vingt","trente","quarante","cinquante","soixante"];
  const sub100 = x => { if (x < 20) return U[x]; const d = Math.floor(x / 10), u = x % 10;
    if (d === 7 || d === 9) { const base = d === 7 ? "soixante" : "quatre-vingt", r = 10 + u; return base + (d === 7 && u === 1 ? " et " : "-") + U[r]; }
    if (d === 8) return u ? "quatre-vingt-" + U[u] : "quatre-vingts";
    return D[d] + (u === 1 ? " et un" : u ? "-" + U[u] : ""); };
  const sub1000 = x => { const c = Math.floor(x / 100), r = x % 100; let s = "";
    if (c) s = (c === 1 ? "cent" : U[c] + " cent") + (r === 0 && c > 1 ? "s" : ""); if (r) s += (s ? " " : "") + sub100(r); return s; };
  n = Math.floor(n); if (n === 0) return "zéro"; const k = Math.floor(n / 1000), r = n % 1000; let s = "";
  if (k) s = (k === 1 ? "mille" : sub1000(k).replace(/(vingt|cent)s$/, "$1") + " mille"); if (r) s += (s ? " " : "") + sub1000(r); return s; }
const montantLettres = v => { const e = Math.floor(v + 1e-9), c = Math.round((v - e) * 100); return enLettres(e) + " euro" + (e > 1 ? "s" : "") + (c ? " et " + enLettres(c) + " centime" + (c > 1 ? "s" : "") : ""); };
function quittancePdf(j, o){
  const y = yr(j), m = mo(j), debut = y + "-" + pad(m + 1) + "-01", fin = lastDay(y, m), total = r2(o.loyer + o.chg), recu = o.recu != null ? o.recu : total, partiel = recu < total - 0.005;
  const d = new PdfDoc(partiel ? "Reçu" : "Quittance"), M = d.M, R = d.W - M;
  d.text(d.W / 2, d.y, partiel ? "REÇU DE PAIEMENT PARTIEL" : "QUITTANCE DE LOYER", {size:22, bold:true, center:true, color:"#0E6B5C"}); d.y -= 22;
  d.text(d.W / 2, d.y, "Période du " + frDate(debut) + " au " + frDate(fin), {size:11, center:true, color:"#5C6B66"}); d.y -= 34;
  const bloc = (t, l) => { d.text(M, d.y, t, {size:10, bold:true, color:"#5C6B66"}); d.y -= 15; l.filter(Boolean).forEach(x => { d.text(M, d.y, x, {size:11}); d.y -= 15; }); d.y -= 10; };
  bloc("BAILLEUR (nom, prénom, adresse)", [o.bail || "(à renseigner)", o.badr]); bloc("LOCATAIRE (nom, prénom)", [o.loc || "(à renseigner)"]); bloc("LOGEMENT LOUÉ (adresse)", [bienName(j.bien), o.adr]);
  d.line(M, d.y, R, d.y); d.y -= 18;
  d.text(M, d.y, "Loyer (hors charges)", {size:11}); d.text(R, d.y, eur(o.loyer), {size:11, right:true}); d.y -= 18;
  d.text(M, d.y, "Provision pour charges", {size:11}); d.text(R, d.y, eur(o.chg), {size:11, right:true}); d.y -= 8; d.line(M, d.y, R, d.y); d.y -= 20;
  d.text(M, d.y, "Total du terme (loyer + charges)", {size:12, bold:true}); d.text(R, d.y, eur(total), {size:12, bold:true, right:true}); d.y -= 20;
  if (partiel){ d.text(M, d.y, "Montant versé", {size:12, bold:true}); d.text(R, d.y, eur(recu), {size:12, bold:true, right:true}); d.y -= 18;
    d.text(M, d.y, "Reste dû", {size:12, bold:true, color:"#B3261E"}); d.text(R, d.y, eur(r2(total - recu)), {size:12, bold:true, right:true, color:"#B3261E"}); d.y -= 30; }
  else d.y -= 14;
  if (partiel) d.para("Je soussigné(e) " + (o.bail || "………") + ", propriétaire (ou mandataire) du logement désigné ci-dessus, reconnais avoir reçu de " + (o.loc || "………") + " la somme de " + eur(recu) + " (" + montantLettres(recu) + "), à valoir sur le loyer et les charges de la période indiquée (total " + eur(total) + "). Il reste dû " + eur(r2(total - recu)) + ". Ce document est un reçu : il ne vaut pas quittance et ne libère pas le locataire du solde.", 10.5, 15);
  else d.para("Je soussigné(e) " + (o.bail || "………") + ", propriétaire (ou mandataire) du logement désigné ci-dessus, déclare avoir reçu de " + (o.loc || "………") + " la somme de " + eur(total) + " (" + montantLettres(total) + "), au titre du paiement du loyer et des charges pour la période indiquée, et lui en donne quittance, sous réserve de tous mes droits.", 10.5, 15);
  d.y -= 8;
  if (!partiel){ d.para("Cette quittance annule tous les reçus qui auraient pu être établis précédemment en cas de paiement partiel du montant du présent terme.", 10.5, 15); d.y -= 8; }
  d.para("Date de paiement : " + frDate(j.date), 10.5, 15);
  d.y -= 24; d.text(M, d.y, "Fait" + (o.ville ? " à " + o.ville : "") + ", le " + frDate(todayIso()), {size:10.5}); d.y -= 50; d.text(R, d.y, "Signature du bailleur ou de son mandataire", {size:10, right:true, color:"#5C6B66"});
  d.y -= 40; d.para("Document remis gratuitement au locataire (art. 21 de la loi du 6 juillet 1989).", 8.5, 12);
  return d.finish((partiel ? "Reçu " : "Quittance ") + MOIS[m].toLowerCase() + " " + y);
}

/* ---------- Actions (écran en plus de celles de views.js) ---------- */
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a){
    case "help": sheetHelp(); break;
    case "guide": sheetGuide(); break;
    case "tour": sheetTour(0); break;
    case "tour-next": sheetTour(V.tourI + 1); break; case "tour-prev": sheetTour(V.tourI - 1); break;
    case "tour-end": lsSet("glf-tour", "1"); closeSheet(); break;
    case "hist-all": V.histAll = true; render(); break;
    case "hist-less": V.histAll = false; render(); break;
    case "demo": openSheet(`<h2>Version d'essai</h2><p style="margin:0">Cela remplace les données affichées par de faux biens, adresses, locataires, un état des lieux et un inventaire d'exemple. ${SEC.on || S.demo ? "" : "Tes données sont mises de côté sur cet appareil : le bouton « Retrouver mes données » (Réglages) les remet. "}Exporte quand même une sauvegarde avant.</p><div class="btns"><button class="btn danger" data-act="demo-ok">Charger les données d'exemple</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); break;
    case "demo-back": { let sv = null; try { sv = JSON.parse(localStorage.getItem("glf-avant-essai")); } catch(e){} if (!sv) return toast("Aucune sauvegarde de côté");
      S = Object.assign(emptyData(), sv); S.demo = false; persist(); try { localStorage.removeItem("glf-avant-essai"); } catch(e){} V.tab = "home"; toast("Tes données sont revenues"); render(); break; }
    case "demo-ok": if (!SEC.on && !S.demo){ try { localStorage.setItem("glf-avant-essai", JSON.stringify(S)); } catch(e){} } S = demoData(true); persist(); closeSheet(); V.tab = "home"; toast("Données d'exemple chargées"); render(); break;
    case "pal": lsSet("glf-pal", v); applyTheme(); render(); break;
    case "tmode": lsSet("glf-theme", v); applyTheme(); render(); break;
    case "set-start": lsSet("glf-start", v); render(); break;
    case "fiche-share": try { await navigator.share({title:"Gestion Locative Facile", text:FICHE_TXT, url:ficheUrl()}); } catch(e){ if (!e || e.name !== "AbortError"){ try { await navigator.clipboard.writeText(FICHE_TXT + "\n" + ficheUrl()); toast("Descriptif et lien copiés"); } catch(e2){ toast("Partage impossible"); } } } break;
    case "aff-open": { const f = b.dataset.f, a = AFFICHES.find(x => x[0] === f); if (!a) break; openSheet(`<h2>${esc(a[1])}</h2><img src="${esc(f)}" alt="${esc(a[1])}" style="width:100%;border-radius:12px;border:1px solid var(--bd)">
      <div class="small muted">« Partager » ouvre la feuille de partage : tu peux l'envoyer, l'enregistrer dans Photos ou dans Fichiers, ou l'imprimer. Elle est mise à jour avec l'appli.</div>
      <div class="btns"><button class="btn" style="flex:1" data-act="aff-share" data-f="${esc(f)}">Partager / enregistrer</button><button class="btn ghost" data-act="sheetclose">Fermer</button></div>`); break; }
    case "aff-share": { const f = b.dataset.f; try { const r = await fetch(f + "?v=" + APP_VERSION), buf = await r.arrayBuffer(); await saveFile(f, buf, /\.png$/.test(f) ? "image/png" : "image/jpeg"); } catch(e){ toast("Image indisponible : vérifie ta connexion"); } break; }
    case "fiche-open": window.open(ficheUrl(), "_blank"); break;
    case "fiche-copy": try { await navigator.clipboard.writeText(ficheUrl()); toast("Lien copié"); } catch(e){ toast("Copie impossible : " + ficheUrl()); } break;
    case "dir-pick": try { const h = await showDirectoryPicker({mode:"readwrite", id:"glf-export"}); await dirSet(h); toast("Dossier choisi : " + h.name); render(); } catch(e){ if (!e || e.name !== "AbortError") toast("Dossier impossible : " + ((e && e.message) || "erreur")); } break;
    case "dir-off": await dirSet(null); toast("Enregistrement normal rétabli"); render(); break;
    case "set-mat": { const k = b.dataset.k; S.cfg = S.cfg || {bailleur:"", adr:{}}; const lim = k === "matMois" ? [0, 36] : [1, 6], cur = k === "matMois" ? matMois() : resMois(); S.cfg[k] = Math.max(lim[0], Math.min(lim[1], cur + (+v))); persist(); render(); break; }
    case "set-bourse": S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.bourse = v === "1"; persist(); render(); break;
    case "set-remind": lsSet("glf-remind", v); render(); break;
    case "remind-go": closeSheet(); V.tab = "month"; V.mf = "todo"; V.bf = "all"; render(); break;
    case "srch": V.sq = ""; sheetSearch(); setTimeout(() => { const e = $("#sq"); if (e) e.focus(); }, 60); break;
    case "jdup": dupOp(V.editId); break;
    case "md-open": collectDraft(); sheetModele(); break;
    case "md-save": { const nom = $("#md-nom").value.trim(); if (!nom) return toast("Donne un nom au modèle"); const d = V.draft;
      (S.modeles = S.modeles || []).push({id:uid(), nom, type:d.type, bien:d.bien, cat:d.cat, lib:d.lib, montant:parseNum(d.mont) || 0, compte:d.compte}); persist(); closeSheet(); toast("Modèle enregistré"); render(); break; }
    case "md-use": { const m = S.modeles.find(x => x.id === id); if (!m) break; V.editId = null; V.draft = newDraft({type:m.type, bien:m.bien, cat:m.cat, lib:m.lib, mont:m.montant ? fmtNum(m.montant) : "", montAuto:!m.montant, compte:m.compte || "Bien", pt:false}); render(); if (!m.montant) autoSuggest(true); toast("Modèle « " + m.nom + " » appliqué"); break; }
    case "md-del": S.modeles = S.modeles.filter(x => x.id !== id); persist(); render(); break;
    case "arch-now": openSheet(`<h2>Archiver maintenant ?</h2><p style="margin:0">Toutes les lignes prévues déjà pointées sont rangées dans les archives, sans attendre ${ARCH_DAYS} jours. Les soldes et bilans ne changent pas.</p><div class="btns"><button class="btn" style="flex:1" data-act="arch-ok">Archiver</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); break;
    case "arch-ok": { archivePass(true); persist(); closeSheet(); toast(archList().length + " ligne(s) archivée(s)"); render(); break; }
    case "arch-view": sheetArch(); break;
    case "arch-restore": { const j = S.journal.find(x => x.id === id); if (j){ j.arch = false; j.fut = false; delete j.done; } persist(); sheetArch(); render(); break; }
    case "clot-open": sheetCloture(V.y, V.m); break;
    case "clot-do": clotureDo(); break;
    case "clot-undo": { const c = (S.clotures || []).find(x => x.id === id); if (!c) break; const t = Date.now(); S.journal.forEach(j => { if (c.ids.includes(j.id)){ j.del = true; j.upd = t; } }); S.clotures = S.clotures.filter(x => x.id !== id); persist(); closeSheet(); toast("Clôture annulée"); render(); break; }
    case "export-open": sheetExport(); break;
    case "ex-xlsx": case "ex-pdf": { const k = $("#ex-m").value;
      if (k[0] === "A"){ const y = +k.slice(1), nm = "bilan-annee-" + y; if (a === "ex-xlsx") saveFile(nm + ".xlsx", bilanAnXlsx(y), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); else saveFile(nm + ".pdf", bilanAnPdf(y), "application/pdf"); break; }
      const y = +k.slice(0, 4), m = +k.slice(5) - 1, nm = "bilan-" + k;
      if (a === "ex-xlsx") saveFile(nm + ".xlsx", bilanXlsx(y, m), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      else saveFile(nm + ".pdf", bilanPdf(y, m), "application/pdf"); break; }
    case "quit": sheetQuittance(id); break;
    case "quit-pdf": { const j = S.journal.find(x => x.id === V.q), o = {bail:$("#q-bail").value.trim(), badr:$("#q-badr").value.trim(), loc:$("#q-loc").value.trim(), adr:$("#q-adr").value.trim(), loyer:parseNum($("#q-loyer").value) || 0, chg:parseNum($("#q-chg").value) || 0, recu:($("#q-recu").value.trim() === "" ? null : parseNum($("#q-recu").value)), ville:$("#q-ville").value.trim()};
      if (!(o.loyer + o.chg > 0)) return toast("Saisis le montant");
      S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.bailleur = o.bail; S.cfg.bailleurAdr = o.badr; S.cfg.ville = o.ville; { const bn = S.biens.find(b => b.id === j.bien); if (bn && o.adr) bn.adresse = o.adr; } persist();
      saveFile("quittance-" + j.bien + "-" + j.date.slice(0, 7) + ".pdf", quittancePdf(j, o), "application/pdf"); break; }
    case "np": { const el = $("#" + b.dataset.t); if (!el) break; let s = el.value;
      if (v === "del") s = s.slice(0, -1);
      else if (v === ","){ if (!s.includes(",")) s = (s || "0") + ","; }
      else { const dec = s.split(",")[1]; if (dec === undefined || dec.length < 2) s = (s === "0" ? "" : s) + v; }
      el.value = s; el.dispatchEvent(new Event("input", {bubbles:true})); break; }
  }
});
document.addEventListener("input", ev => {
  const t = ev.target;
  if (t.id === "sq"){ V.sq = t.value; $("#sres").innerHTML = searchRes(t.value); return; }
  if (/^cl-[rs]-/.test(t.id)) clUpdate(t);
});
document.addEventListener("change", ev => {
  const t = ev.target;
  if (t.id === "sc-from" || t.id === "sc-to"){ const s = schedGet(); s[t.id === "sc-from" ? "from" : "to"] = t.value || s[t.id === "sc-from" ? "from" : "to"]; lsSet("glf-sched", JSON.stringify(s)); applyTheme(); }
});
const npadHtml = target => `<div class="npad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button type="button" data-act="np" data-t="${target}" data-v="${n}">${n}</button>`).join("")}<button type="button" data-act="np" data-t="${target}" data-v=",">,</button><button type="button" data-act="np" data-t="${target}" data-v="0">0</button><button type="button" data-act="np" data-t="${target}" data-v="del" aria-label="Effacer">⌫</button></div>`;


/* ---------- Premier lancement, biens, bailleur ---------- */
const slugBien = nom => { let b = stripAcc(nom).toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 14) || "BIEN", id = b, i = 2; while ((S.biens || []).some(x => x.id === id)) id = b + "_" + i++; return id; };
const bienFields = b => `<label class="f">Nom du bien<input id="bn-nom" value="${esc(b.nom || "")}" placeholder="Ex. Studio, T2, Garage…"></label>
  <label class="f">Adresse du logement<input id="bn-adr" value="${esc(b.adresse || "")}" placeholder="N°, rue, code postal, ville"></label>
  <div class="grid2"><label class="f">Solde du compte au départ (€)<input id="bn-solde" inputmode="decimal" value="${fmtNum(b.solde0 ?? "")}" placeholder="0,00"></label><label class="f">à la date du<input id="bn-date" type="date" value="${esc(b.date0 || todayIso())}"></label></div>
  <div class="small muted">Le solde de départ, c'est l'argent présent sur le compte de ce bien à cette date. Ensuite tout se calcule avec les opérations pointées.</div>
  <div class="grid2"><label class="f">Loyer mensuel (€)<input id="bn-loyer" inputmode="decimal" value="${fmtNum(b.loyer ?? "")}" placeholder="0,00"></label><label class="f">Mensualité de crédit (€)<input id="bn-credit" inputmode="decimal" value="${fmtNum(b.credit ?? "")}" placeholder="0,00"></label></div>
  <label class="f">Type de location<select id="bn-bail"><option value="meuble" ${b.bail !== "vide" ? "selected" : ""}>Meublée</option><option value="vide" ${b.bail === "vide" ? "selected" : ""}>Vide (non meublée)</option></select></label>
  <div class="small muted">Le type règle le bail (durée, préavis), le dépôt de garantie maximum et les documents demandés (l'inventaire du mobilier n'est utile qu'en meublé). La colocation est expliquée dans le Guide du bailleur.</div>
  <label class="f">Régime fiscal<input id="bn-regime" value="${esc(b.regime || (b.bail === "vide" ? "Revenus fonciers" : "LMNP"))}"></label>
  <label class="f">Notes<input id="bn-notes" value="${esc(b.notes || "")}"></label>`;
function readBien(old){
  const nom = $("#bn-nom").value.trim(); if (!nom){ toast("Donne un nom au bien"); return null; }
  const b = {id:old ? old.id : slugBien(nom), nom, adresse:$("#bn-adr").value.trim(), solde0:parseNum($("#bn-solde").value) || 0, date0:$("#bn-date").value || todayIso(), loyer:parseNum($("#bn-loyer").value) || 0, credit:parseNum($("#bn-credit").value) || 0, bail:$("#bn-bail").value === "vide" ? "vide" : "meuble", regime:$("#bn-regime").value.trim(), notes:$("#bn-notes").value.trim(), upd:Date.now()};
  if (old){ Object.assign(old, b); return old; }
  b.app = true; S.biens.push(b); return b;
}
const locFields = t => `<label class="f">Nom du locataire<input id="t-nom" value="${esc(t.nom || "")}"></label>
  <div class="grid2"><label class="f">Téléphone<input id="t-tel" type="tel" value="${esc(t.tel || "")}"></label><label class="f">E-mail<input id="t-mail" type="email" autocapitalize="none" value="${esc(t.email || "")}"></label></div>
  <div class="grid2"><label class="f">Début du bail<input id="t-debut" type="date" value="${esc(t.debut || "")}"></label><label class="f">Fin du bail<input id="t-fin" type="date" value="${esc(t.fin || "")}"></label></div>
  <div class="grid2"><label class="f">Loyer charges comprises (€)<input id="t-loyer" inputmode="decimal" value="${fmtNum(t.loyer ?? "")}"></label><label class="f">Dont charges (€)<input id="t-chg" inputmode="decimal" value="${fmtNum(t.charges || "")}"></label></div>
  <label class="f">Dépôt de garantie (€)<input id="t-depot" inputmode="decimal" value="${fmtNum(t.depot ?? "")}"></label>`;
function readLoc(bien){
  const nom = $("#t-nom").value.trim(); if (!nom){ toast("Donne le nom du locataire"); return null; }
  return {id:uid(), bien, nom, tel:$("#t-tel").value.trim(), email:$("#t-mail").value.trim(), debut:$("#t-debut").value, fin:$("#t-fin").value, loyer:parseNum($("#t-loyer").value) || 0, charges:parseNum($("#t-chg").value) || 0, depot:parseNum($("#t-depot").value) || 0, note:"", upd:Date.now()};
}
function viewWelcome(){
  const w = V.wz = V.wz || {step:0}, st = w.step, dots = `<div class="small muted" style="text-align:center">Étape ${Math.min(st, 4)} sur 4</div>`;
  const p = V.pending ? `<div class="card" style="border-color:var(--accent)"><h2>Fichier lu : ${esc(V.pending.name)}</h2><div class="small">${V.pending.kind === "json" ? bkSummary(V.pending.data) : V.pending.kind === "dos" ? esc(V.pending.sum) : (V.pending.d.biens ? V.pending.d.biens.length + " bien(s), " : "") + V.pending.d.journal.length + " opération(s), " + V.pending.d.locataires.length + " locataire(s)."}</div>
    <div class="btns"><button class="btn" data-act="imp-merge" style="flex:1">Importer</button><button class="btn ghost" data-act="imp-cancel">Annuler</button></div></div>` : "";
  if (st === 0) return `<div class="top"><div class="app">Gestion Locative Facile</div><button class="q" data-act="help" aria-label="Aide">?</button></div>
    <div class="card hero"><div class="lbl">Bienvenue</div><div class="big" style="font-size:30px">Ta location, en toute simplicité</div><div class="sub">Loyers, quittances, baux, états des lieux et bilans, pour un logement meublé ou vide.</div></div>
    ${V.msg ? `<div class="info">${esc(V.msg)}</div>` : ""}${p}
    <div class="card"><h2>Comment ça marche</h2><div class="rows">
      <div class="row"><div class="main"><div class="t">1. Tu crées tes biens</div><div class="s">Nom, adresse, solde du compte, loyer, crédit. Puis le locataire.</div></div></div>
      <div class="row"><div class="main"><div class="t">2. Tu saisis et tu pointes</div><div class="s">Chaque loyer ou charge est une ligne. Tu la pointes quand elle est passée sur le relevé de banque.</div></div></div>
      <div class="row"><div class="main"><div class="t">3. Tu obtiens bilans et quittances</div><div class="s">En Excel ou en PDF, avec le bailleur, les biens et les locataires.</div></div></div>
      <div class="row"><div class="main"><div class="t">Tout reste sur ton téléphone</div><div class="s">Aucun envoi sur internet. Tu peux verrouiller l'appli par un code (Réglages).</div></div></div></div></div>
    <div class="btns"><button class="btn" style="flex:1" data-act="wz-go">Créer mon premier bien</button></div>
    <div class="card"><h2>J'ai déjà une sauvegarde</h2><div class="small muted">Importe la sauvegarde de l'appli (.json ou .zip) pour retrouver tes biens, tes opérations, tes locataires et tes documents. Un classeur Excel au format de l'appli est aussi accepté.</div>
      <label class="f">Fichier de sauvegarde<input id="file" type="file" accept="*/*"></label></div>
    <div class="btns"><button class="btn ghost" data-act="wz-demo">Voir avec des données d'exemple</button><button class="btn ghost" data-act="go" data-v="guide">Guide du bailleur</button></div>
    <div class="small muted" style="text-align:center;margin:10px 0">Outil d'aide : ne remplace ni un notaire, ni un avocat, ni un expert-comptable. Tes données restent sur ton téléphone. <a href="confidentialite.html" target="_blank" rel="noopener">Confidentialité</a></div>`;
  if (st === 1) return `<div class="top"><button class="btn ghost sm" data-act="wz-back">‹ Retour</button><button class="q" data-act="help" aria-label="Aide">?</button></div>${dots}
    <div class="card"><h2>Le bailleur</h2><div class="small muted">C'est toi : ce nom et cette adresse apparaissent sur les quittances et les bilans.</div>
      <label class="f">Nom du bailleur<input id="wz-bail" value="${esc((S.cfg && S.cfg.bailleur) || "")}" placeholder="Prénom Nom"></label>
      <label class="f">Adresse du bailleur<input id="wz-badr" value="${esc((S.cfg && S.cfg.bailleurAdr) || "")}" placeholder="N°, rue, code postal, ville"></label>
      <div class="btns"><button class="btn" style="flex:1" data-act="wz-bail">Suivant</button><button class="btn ghost" data-act="wz-next2">Passer</button></div></div>`;
  if (st === 2) return `<div class="top"><button class="btn ghost sm" data-act="wz-back">‹ Retour</button><button class="q" data-act="help" aria-label="Aide">?</button></div>${dots}
    <div class="card"><h2>${live(S.biens).length ? "Un autre bien" : "Ton premier bien"}</h2>${bienFields({})}<div class="btns"><button class="btn" style="flex:1" data-act="wz-bien">Suivant</button></div></div>`;
  if (st === 3){ const b = S.biens.find(x => x.id === w.bien) || {};
    return `<div class="top"><div class="app">${esc(b.nom || "Bien")}</div><button class="q" data-act="help" aria-label="Aide">?</button></div>${dots}
    <div class="card"><h2>Le locataire (facultatif)</h2><div class="small muted">Repris sur la quittance et les bilans. Tu peux le faire plus tard dans Biens › Locataires.</div>${locFields({loyer:b.loyer})}
      <div class="btns"><button class="btn" style="flex:1" data-act="wz-loc">Enregistrer</button><button class="btn ghost" data-act="wz-skip">Passer</button></div></div>`; }
  return `<div class="top"><div class="app">C'est prêt</div></div>
    <div class="card"><h2>${live(S.biens).length} bien(s) créé(s)</h2><div class="rows">${live(S.biens).map(b => `<div class="row"><div class="main"><div class="t">${bienPill(b.id)}</div><div class="s">${esc(b.adresse || "adresse non renseignée")} · loyer ${eur(b.loyer)} · crédit ${eur(b.credit)}</div></div></div>`).join("")}</div>
      <div class="small muted">Pour ajouter les loyers du mois : onglet Loyers, bouton « Ajouter ». Pour les autres opérations : le + du milieu.</div>
      <div class="btns"><button class="btn" style="flex:1" data-act="wz-end">Ouvrir mon appli</button><button class="btn ghost" data-act="wz-more">Ajouter un autre bien</button></div></div>`;
}
function sheetBien(id){
  const b = id ? S.biens.find(x => x.id === id) : {};
  openSheet(`<h2>${id ? "Modifier le bien" : "Ajouter un bien"}</h2>${bienFields(b)}
    <div class="btns"><button class="btn" style="flex:1" data-act="bn-save" data-id="${id || ""}">Enregistrer</button>${id && !S.journal.some(j => j.bien === id && !j.del) ? `<button class="btn danger" data-act="bn-del" data-id="${id}">Supprimer</button>` : ""}<button class="btn ghost" data-act="sheetclose">Annuler</button></div>
    ${id ? `<div class="small muted">L'identifiant « ${esc(id)} » ne change pas (il fait le lien avec Excel). Un bien qui a déjà des opérations ne peut pas être supprimé.</div>` : ""}`);
}
function sheetBailleur(){ const c = S.cfg || {};
  openSheet(`<h2>Bailleur</h2><label class="f">Nom<input id="bl-nom" value="${esc(c.bailleur || "")}"></label><label class="f">Adresse<input id="bl-adr" value="${esc(c.bailleurAdr || "")}"></label>
    <div class="btns"><button class="btn" style="flex:1" data-act="bl-save">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); }
const biensCard = () => `<div class="card"><h2>Bailleur et biens</h2>
  <div class="kv"><span>Bailleur</span><span>${esc((S.cfg && S.cfg.bailleur) || "non renseigné")}</span></div>
  <div class="btns"><button class="btn ghost sm" data-act="bl-open">Modifier le bailleur</button></div>
  <div class="rows">${live(S.biens).map(b => `<div class="row"><div class="main"><div class="t">${bienPill(b.id)}</div><div class="s">${esc(b.adresse || "adresse non renseignée")}</div></div><button class="mini" data-act="bn-edit" data-id="${b.id}">Modifier</button></div>`).join("")}</div>
  <div class="btns"><button class="btn ghost sm" data-act="bn-new">Ajouter un bien</button></div></div>`;
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, w = V.wz = V.wz || {step:0};
  switch (a){
    case "wz-go": w.step = 1; w.active = true; render(); break;
    case "wz-back": w.step = w.step === 2 && live(S.biens).length ? 4 : Math.max(0, w.step - 1); render(); break;
    case "wz-bail": S.cfg = S.cfg || {}; S.cfg.bailleur = $("#wz-bail").value.trim(); S.cfg.bailleurAdr = $("#wz-badr").value.trim(); persist(); w.step = 2; render(); break;
    case "wz-next2": w.step = 2; render(); break;
    case "wz-bien": { const nb = readBien(null); if (!nb) break; persist(); w.bien = nb.id; w.step = 3; render(); break; }
    case "wz-loc": { const t = readLoc(w.bien); if (!t) break; S.locataires.push(t); persist(); w.step = 4; render(); break; }
    case "wz-skip": w.step = 4; render(); break;
    case "wz-more": w.step = 2; render(); break;
    case "wz-end": V.wz = null; V.tab = "home"; lsSet("glf-tour", "1"); render(); toast("Bienvenue ! Le bouton ? explique chaque écran"); break;
    case "wz-demo": S = demoData(); persist(); V.wz = null; V.tab = "home"; render(); break;
    case "bn-new": sheetBien(""); break; case "bn-edit": sheetBien(id); break;
    case "bn-save": { const old = id ? S.biens.find(x => x.id === id) : null, nb = readBien(old); if (!nb) break; persist(); closeSheet(); toast(id ? "Bien modifié" : "Bien ajouté"); if (!id) V.bsel = nb.id; render(); break; }
    case "bn-del": S.biens = S.biens.filter(x => x.id !== id); persist(); closeSheet(); render(); break;
    case "bl-open": sheetBailleur(); break;
    case "bl-save": S.cfg = S.cfg || {}; S.cfg.bailleur = $("#bl-nom").value.trim(); S.cfg.bailleurAdr = $("#bl-adr").value.trim(); persist(); closeSheet(); toast("Bailleur enregistré"); render(); break;
  }
});
