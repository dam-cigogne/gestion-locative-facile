/* ============ Version publique : Guide du bailleur, courrier d'option LMNP, avertissements ============ */
const GUIDE_DATE = "octobre 2026";
const GUIDE_WARN = `<div class="small muted" style="margin:8px 0">Outil d'aide à la gestion : ce guide ne remplace ni un notaire, ni un avocat, ni un expert-comptable. Les règles et les montants changent : vérifie toujours sur les sites officiels avant de décider. Dernière relecture : ${GUIDE_DATE}.</div>`;
const gtbl = (heads, rows) => `<table class="gt"><thead><tr>${heads.map(h => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${r.map((c, i) => i === 0 ? `<th>${c}</th>` : `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
const glink = (u, t) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`;
const gsec = (id, titre, corps) => `<details class="card gsec" ${V.gopen === id ? "open" : ""} data-g="${id}"><summary><b>${titre}</b></summary><div class="gbody">${corps}</div></details>`;

function guideSections(){
  return [
    gsec("nv", "Location meublée ou vide ?", gtbl(["", "Vide (non meublée)", "Meublée"], [
      ["Durée mini du bail", "3 ans", "1 an, ou 9 mois (étudiant)"],
      ["Dépôt de garantie max", "1 mois de loyer hors charges", "2 mois de loyer hors charges"],
      ["Préavis du locataire", "3 mois (1 mois en zone tendue et cas particuliers)", "1 mois"],
      ["Préavis du bailleur", "6 mois avant l'échéance", "3 mois avant l'échéance"],
      ["Motifs de congé du bailleur", "Vente, reprise pour habiter, motif légitime et sérieux", "Les mêmes"],
      ["Mobilier", "Aucun", "Liste minimale fixée par décret (inventaire annexé)"],
      ["Impôt", "Revenus fonciers", "Bénéfices industriels et commerciaux (LMNP / LMP)"]
    ]) + `<div class="small" style="margin-top:8px"><b>Le bail doit indiquer</b> : la durée, le loyer et sa révision, les charges et leur mode de récupération, le dépôt de garantie.<br><b>À annexer</b> : l'état des lieux, l'inventaire du mobilier (meublé), le dossier de diagnostics (DPE, plomb, risques naturels, amiante, électricité, gaz selon le cas), les extraits du règlement de copropriété.<br><b>Le congé du bailleur</b> se fait par lettre recommandée, 3 mois (meublé) ou 6 mois (vide) avant l'échéance.</div>
      <div class="small muted">Le décret sur le mobilier d'un meublé : ${glink("https://www.legifrance.gouv.fr/affichTexte.do?cidTexte=JORFTEXT000030967884", "décret n° 2015-981")}.</div>`),
    gsec("co", "Colocation : un bail pour chacun, ou un bail pour tous ?", gtbl(["", "Baux individuels (un par colocataire)", "Bail collectif (un seul pour tous)"], [
      ["Loyer", "Chacun paie sa part", "Le total est dû : les colocataires s'arrangent entre eux"],
      ["Signature", "Individuelle", "Collective"],
      ["Clause de solidarité", "Non", "Possible ; elle dure jusqu'à 6 mois après le départ d'un colocataire"],
      ["Garant", "Engagement sur une part", "Engagement sur la totalité du loyer et des charges"],
      ["Dépôt de garantie", "Une part par colocataire", "La totalité, un seul dépôt"],
      ["Départ d'un colocataire", "Simple : tu le remplaces par un nouveau bail individuel", "Avenant au bail ; le loyer total reste dû, les colocataires remplacent le partant"],
      ["Rendu du dépôt au départ", "Sa part", "Rien tant que le bail dure : à régler entre colocataires"],
      ["Assurance", "Individuelle", "Collective"]
    ]) + `<div class="small muted" style="margin-top:6px">Dans l'appli, crée un bien par chambre en baux individuels, ou un seul bien avec plusieurs locataires en bail collectif. Vérifie les règles de surface et de décence avant de louer.</div>`),
    gsec("fi", "Régimes fiscaux : comment choisir ?", gtbl(["", "Micro-foncier", "Foncier au réel", "Micro-BIC", "BIC réel simplifié"], [
      ["Pour quelle location", "Vide", "Vide", "Meublée", "Meublée"],
      ["Principe", "Abattement forfaitaire (30 %)", "Charges réelles déduites", "Abattement forfaitaire (50 %)", "Charges réelles + amortissements"],
      ["Charges déductibles", "Aucune (forfait)", "Toutes sauf construction, reconstruction, agrandissement", "Aucune (forfait)", "Toutes + amortissements"],
      ["Engagement si option", "Aucun", "3 ans", "Aucun", "2 ans"],
      ["Comptable utile", "Non", "Non", "Non", "Oui, en général"],
      ["Plus-value à la revente", "Régime des particuliers", "Régime des particuliers", "Régime des particuliers", "Régime des particuliers (LMNP)"],
      ["À retenir", "Simple si peu de charges", "Intéressant avec beaucoup de travaux", "Simple si peu de charges", "Le plus avantageux avec un crédit ou des travaux"]
    ]) + `<div class="small" style="margin-top:8px"><b>LMNP ou LMP ?</b> Tu es LMNP (non professionnel) par défaut, sans condition. Tu deviens LMP (professionnel) si tes recettes dépassent un seuil fixé par la loi <b>et</b> dépassent les autres revenus de ton foyer, avec inscription au registre du commerce. Les déficits ne s'imputent alors pas pareil. Vérifie les seuils sur ${glink("https://www.impots.gouv.fr", "impots.gouv.fr")}.</div>
      <div class="small muted">Les seuils des régimes « micro » évoluent : consulte le site des impôts avant de choisir.</div>`),
    gsec("de", "Dépenses déductibles : foncier réel ou BIC réel", gtbl(["Dépense", "Foncier réel", "BIC réel"], [
      ["Frais de notaire", "Non", "Oui (en charge, ou ajoutés à la valeur du bien)"],
      ["Frais d'agence", "Non", "Oui (en charge, ou à l'actif)"],
      ["Frais de comptabilité", "Non", "Oui"],
      ["Amortissements", "Non", "Oui"],
      ["Travaux", "Oui, sauf construction, reconstruction, agrandissement", "Oui, tous"],
      ["Charges de copropriété et autres", "Oui, si non récupérables sur le locataire", "Oui, toutes"],
      ["Frais de gestion", "Forfait", "Réels"],
      ["Abonnements, conseils", "Non", "Oui, s'ils concernent l'activité"],
      ["Commissions versées à des tiers", "Oui", "Oui"],
      ["Frais et intérêts d'emprunt", "Oui", "Oui"],
      ["Taxes (taxe foncière, CFE)", "Oui (la CFE ne concerne que le meublé)", "Oui"],
      ["Assurances (PNO, loyers impayés)", "Oui", "Oui"],
      ["Frais de procédure", "Oui", "Oui"]
    ]) + `<div class="small muted" style="margin-top:6px">En BIC réel, pense à inscrire le bien à l'actif de l'entreprise pour pouvoir l'amortir.</div>`),
    gsec("am", "Amortir : ordres de grandeur par composant", gtbl(["Composant", "Taux annuel", "Durée"], [
      ["Gros œuvre", "1,25 % à 2 %", "50 à 80 ans"],
      ["Second œuvre extérieur", "6,66 % à 8,33 %", "12 à 15 ans"],
      ["Second œuvre intérieur", "5,55 % à 8,33 %", "12 à 18 ans"],
      ["Finitions", "6,66 % à 20 %", "5 à 15 ans"],
      ["Toiture", "4 % à 5 %", "20 à 25 ans"],
      ["Installations électriques", "4 % à 5 %", "20 à 25 ans"],
      ["Étanchéité", "6 % à 7 %", "14 à 16 ans"],
      ["Ascenseur", "6 % à 7 %", "14 à 16 ans"],
      ["Agencements intérieurs", "6 % à 7 %", "14 à 16 ans"]
    ]) + `<div class="small muted" style="margin-top:6px">Fourchettes moyennes données à titre indicatif : à valider avec ton expert-comptable. Le terrain ne s'amortit pas.</div>`),
    gsec("me", "Meubler : exemple de budget (appartement de 45 m²)", gtbl(["Pièce", "Montant"], [
      ["Cuisine : frigo, lave-linge, meubles, hotte, vaisselle", "2 060 €"],
      ["Chambre : lit, matelas, literie, dressing, commode, lampes", "857 €"],
      ["Salle de bain : armoire, accessoires", "109 €"],
      ["Salon et bureau : écran, canapé, rangements, tapis", "908 €"],
      ["Divers : luminaires, stores, déco, aspirateur, ménage", "575 €"],
      ["<b>Total</b>", "<b>4 509 €</b>"]
    ]) + `<div class="small muted" style="margin-top:6px">Garde toutes les factures : en BIC réel, le mobilier s'amortit. Vérifie aussi la liste minimale du décret 2015-981 (literie, plaques de cuisson, four ou micro-ondes, réfrigérateur, vaisselle, rangements, luminaires, etc.).</div>`),
    gsec("dm", "Démarches pour commencer (meublé)", `<div class="small"><b>1. Déclarer le début d'activité.</b> Une location meublée est une activité commerciale : déclare-la avec le formulaire P0i (personne physique, activité non salariée) via le guichet des formalités d'entreprises. Tu obtiens un numéro SIRET.<br><b>2. Choisir ton centre des impôts.</b> Retrouve ton service des impôts des entreprises (SIE) sur ${glink("https://www.impots.gouv.fr/contacts", "impots.gouv.fr/contacts")}.<br><b>3. Opter pour le réel simplifié</b> (si tu veux amortir) : par lettre recommandée au SIE. L'appli prépare le courrier ci-dessous.<br><b>4. Deuxième logement meublé.</b> Déclare-le en modification de ton activité (formulaire P2-P4 i) plutôt qu'en nouvelle création.<br><b>5. Tenir ta comptabilité</b> : l'onglet Compta de l'appli te prépare les exports ; tu peux aussi passer par un expert-comptable en ligne.</div>
      <div class="btns"><button class="btn" data-act="lmnp-open">Courrier d'option LMNP (PDF)</button></div>`),
    gsec("ca", "Choisir un locataire", `<div class="small"><b>Pièces autorisées</b> : la liste est limitative, fixée par le décret n° 2015-1437 du 5 novembre 2015. L'appli te la rappelle dans le dossier du candidat ; ne demande rien d'autre.<br><b>Vérifier un avis d'imposition</b> : le ${glink("https://cfsmsp.impots.gouv.fr", "service de vérification en ligne des avis")} (numéro fiscal + référence de l'avis).<br><b>Se protéger des impayés</b> : la garantie ${glink("https://www.visale.fr", "Visale")} (caution gratuite d'Action Logement, sous conditions) ou une assurance loyers impayés.<br><b>Rédiger le bail</b> : l'appli crée le bail en PDF (meublé ou vide) ; tu peux aussi comparer avec un modèle comme celui de ${glink("https://www.rentila.com", "Rentila")}.</div>`),
    gsec("an", "Une bonne annonce", `<div class="small">Une trame qui fonctionne :<br><b>1. Accroche et date</b> : surface, ce qui rend le logement unique, date de disponibilité.<br><b>2. Localisation</b> : rue, commerces, transports, accès rapides, employeurs proches.<br><b>3. Visite virtuelle</b> : l'entrée, la pièce de vie, la cuisine, la chambre, la salle de bain, les rangements.<br><b>4. Le « plus »</b> : équipements fournis (lave-linge, écran plat, literie de qualité), rénovation récente.<br><b>5. Loyer et détails</b> : loyer, charges et ce qu'elles comprennent, profil recherché.<br><b>6. Contact</b> : date de disponibilité répétée et mode de contact.</div><div class="btns"><button class="btn ghost" data-act="go" data-v="rent">Créer une annonce</button></div>`),
    gsec("li", "Liens utiles", `<div class="small">${glink("https://www.impots.gouv.fr", "impots.gouv.fr")} : impôts, SIE, avis d'imposition<br>${glink("https://www.service-public.fr", "service-public.fr")} : fiches pratiques sur la location<br>${glink("https://www.visale.fr", "Visale")} : garantie des loyers<br>${glink("https://www.legifrance.gouv.fr", "Légifrance")} : les textes de loi<br>${glink("https://www.anil.org", "ANIL")} : conseils juridiques gratuits sur le logement</div>`)
  ].join("");
}
function viewGuide(){
  return topbar("Guide du bailleur") + `<div class="btns"><button class="btn ghost sm" data-act="tab" data-v="${live(S.biens).length ? 'home' : 'welcome'}">‹ Retour</button></div>
    <div class="info">Les différences entre location meublée et vide, la colocation, les impôts et les démarches, au même endroit. Touche un titre pour l'ouvrir.</div>
    ${guideSections()}${GUIDE_WARN}`;
}
const guideCard = () => `<div class="card"><h2>Guide du bailleur</h2><div class="small muted">Meublé ou vide, colocation, régimes fiscaux, démarches, liens utiles, courrier d'option LMNP.</div><div class="btns"><button class="btn" data-act="go" data-v="guide">Ouvrir le guide</button></div></div>`;
const legalCard = () => `<div class="card"><h2>À savoir</h2><div class="small muted">Gestion Locative Facile est un outil d'aide : il ne remplace ni un notaire, ni un avocat, ni un expert-comptable. Les règles (baux, délais, impôts) changent : vérifie sur les sites officiels. Tes données restent sur ton téléphone ; aucune n'est envoyée.</div>
  <div class="btns"><a class="btn ghost sm" href="confidentialite.html" target="_blank" rel="noopener">Politique de confidentialité</a></div></div>`;

/* ---------- Courrier d'option pour le réel simplifié (LMNP) ---------- */
function sheetLmnp(){
  const c = bailleurInfo(), biens = live(S.biens).filter(b => bkind(b.id) === "meuble");
  openSheet(`<h2>Courrier d'option LMNP</h2><div class="info">Lettre à envoyer en recommandé avec accusé de réception à ton service des impôts des entreprises (SIE), pour opter pour le régime réel simplifié. Relis-la, imprime-la, signe-la.</div>
    ${dxF("lm-nom", "Ton nom et prénom", c.nom)}${dxF("lm-adr", "Ton adresse (rue, code postal, ville)", c.adr)}${dxF("lm-tel", "Téléphone (facultatif)", "", 'inputmode="tel"')}${dxF("lm-mail", "E-mail (facultatif)", "", 'type="email" autocapitalize="none"')}
    ${dxF("lm-sie", "Adresse de ton SIE (voir impots.gouv.fr/contacts)", "", 'placeholder="Service des impôts des entreprises, rue, code postal, ville"')}
    ${dxF("lm-bien", "Adresse du logement loué en meublé", biens[0] ? bienAdr(biens[0].id) : "")}
    ${dxF("lm-ville", "Fait à", (S.cfg && S.cfg.ville) || "")}
    <div class="btns"><button class="btn" style="flex:1" data-act="lmnp-pdf">Créer le courrier (PDF)</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function lmnpPdf(o){
  const d = new PdfDoc("Option pour le régime réel simplifié"), M = d.M, R = d.W - M, P = (s, g) => { d.para(s, 11, g || 16); d.y -= 6; };
  d.clean = true;
  [o.nom, o.adr, o.tel && "Tél. " + o.tel, o.mail].filter(Boolean).forEach(l => { d.text(M, d.y, l, {size:11}); d.y -= 15; });
  d.y -= 14; (o.sie || "Service des impôts des entreprises (SIE)").split(/\n|,\s(?=\d{5}\b)/).forEach(l => { d.text(R, d.y, l.trim(), {size:11, right:true}); d.y -= 15; });
  d.y -= 8; d.text(R, d.y, (o.ville ? o.ville + ", le " : "Le ") + frDate(todayIso()), {size:11, right:true}); d.y -= 34;
  d.text(M, d.y, "Objet : option pour le régime réel simplifié, loueur en meublé non professionnel (LMNP)", {size:11, bold:true}); d.y -= 16;
  d.text(M, d.y, "Lettre recommandée avec accusé de réception", {size:10.5}); d.y -= 32;
  P("Madame, Monsieur,");
  P("Je vous informe, par la présente, de ma décision d'opter pour le régime réel simplifié d'imposition des bénéfices industriels et commerciaux, concernant mon activité de loueur en meublé non professionnel.", 17);
  P("Le bien objet de cette décision est situé : " + (o.bien || "………") + ".", 17);
  P("Vous remerciant de l'attention que vous voudrez bien apporter à ma demande, je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.", 17);
  d.y -= 24; d.text(R, d.y, "Signature", {size:11, right:true}); d.y -= 54; d.text(R, d.y, o.nom || "", {size:11, right:true});
  return d.finish("Courrier d'option LMNP");
}
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  switch (b.dataset.act){
    case "lmnp-open": sheetLmnp(); break;
    case "lmnp-pdf": { const o = {nom:dxV("lm-nom"), adr:dxV("lm-adr"), tel:dxV("lm-tel"), mail:dxV("lm-mail"), sie:dxV("lm-sie"), bien:dxV("lm-bien"), ville:dxV("lm-ville")};
      if (!o.nom) return toast("Indique ton nom");
      S.cfg = S.cfg || {}; if (!S.cfg.bailleur) S.cfg.bailleur = o.nom; if (!S.cfg.bailleurAdr) S.cfg.bailleurAdr = o.adr; if (o.ville) S.cfg.ville = o.ville; persist();
      saveFile("courrier-option-lmnp.pdf", lmnpPdf(o), "application/pdf"); break; }
  }
});
document.addEventListener("toggle", ev => { const t = ev.target; if (t && t.classList && t.classList.contains("gsec") && t.open) V.gopen = t.dataset.g; }, true);
document.addEventListener("change", ev => { const t = ev.target; if (!t || t.id !== "bn-bail") return; const r = $("#bn-regime"); if (r && ["", "LMNP", "Revenus fonciers"].includes(r.value.trim())) r.value = t.value === "vide" ? "Revenus fonciers" : "LMNP"; });
