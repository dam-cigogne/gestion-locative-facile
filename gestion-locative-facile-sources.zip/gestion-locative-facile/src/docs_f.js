/* ============ Arrivée / Départ du locataire : démarche pas à pas, avec accès direct aux documents ============ */
const MVT = {
  arr: {titre:"Arrivée d'un locataire", etapes:[
    ["dos", "Dossier du candidat vérifié", "Pièce d'identité, justificatifs de revenus, garant éventuel. Ne demande que les pièces autorisées par le décret n° 2015-1437 (liste limitative).", ["cand", "Candidatures"]],
    ["diag", "Diagnostics à jour", "DPE (le logement classé G ne peut plus être loué en résidence principale), risques (ERP), plomb avant 1949, électricité et gaz si installation de plus de 15 ans, amiante selon l'âge de l'immeuble. Garde-les dans les documents du bien.", ["docs", "Pièces à joindre"]],
    ["bail", "Bail préparé et relu", "Remplis le bail, puis crée le PDF de relecture et relis-le avec le locataire avant de signer.", ["bail", "Préparer le bail"]],
    ["inv", "Inventaire du mobilier d'entrée", "Obligatoire en meublé (liste minimale du décret n° 2015-981), inutile en logement vide. Tu peux le préparer avant la visite en reprenant la liste d'un autre logement.", ["inv-e", "Inventaire d'entrée"]],
    ["edl", "État des lieux d'entrée", "Pièce par pièce, avec photos. Le locataire peut le compléter sous 10 jours (chauffage : premier mois).", ["edl-e", "État des lieux d'entrée"]],
    ["sig", "Signatures", "Bail, état des lieux et inventaire signés par les deux parties, un exemplaire chacun (signature à l'écran possible).", ["docs", "Aller aux documents"]],
    ["dep", "Dépôt de garantie reçu", "Maximum : 2 mois de loyer hors charges en meublé, 1 mois en logement vide. Il se note dans l'appli et dans Excel.", null],
    ["cle", "Clés remises et compteurs relevés", "Note les index d'électricité, d'eau et de gaz dans l'état des lieux.", null],
    ["ass", "Attestation d'assurance habitation reçue", "Le locataire doit l'avoir à l'entrée puis chaque année.", null],
    ["loc", "Locataire enregistré dans l'appli et dans Excel", "Dates de début, loyer, charges, dépôt.", ["loc", "Fiche locataire"]]
  ]},
  dep: {titre:"Départ d'un locataire", etapes:[
    ["con", "Congé reçu et vérifié", "Préavis du locataire : 1 mois en meublé, 3 mois en logement vide (1 mois en zone tendue et dans certains cas). Bailleur : au moins 3 mois (meublé) ou 6 mois (vide) avant la fin du bail, pour un motif légal. Forme : lettre recommandée, acte de commissaire de justice ou remise en main propre contre récépissé.", null],
    ["dat", "Date de départ fixée avec le locataire", "Le locataire prend rendez-vous au moins une semaine avant son déménagement. La lettre de rappel lui liste ce qu'il doit préparer (propreté, clés, justificatifs).", ["rappel", "Lettre de rappel"]],
    ["inv", "Inventaire du mobilier de sortie", "Repris de l'inventaire d'entrée : tu notes l'état de chaque article à la sortie et les remarques.", ["inv-s", "Inventaire de sortie"]],
    ["edl", "État des lieux de sortie", "Repris de l'état d'entrée : les éléments plus dégradés ressortent en rouge dans le PDF.", ["edl-s", "État des lieux de sortie"]],
    ["sig", "Signatures", "Document signé par les deux parties, un exemplaire chacun.", ["docs", "Aller aux documents"]],
    ["cle", "Clés rendues, compteurs relevés, adresse de renvoi notée", "Garde la nouvelle adresse du locataire pour lui envoyer le décompte.", null],
    ["sol", "Loyers et charges à jour", "Vérifie le solde du locataire ; une lettre de loyer impayé est prête si besoin.", ["impaye", "Lettre d'impayé"]],
    ["ret", "Retenues justifiées", "Devis ou factures, en tenant compte de la vétusté. Rien sans justificatif.", null],
    ["res", "Dépôt de garantie restitué", "Sous 1 mois si l'état de sortie est conforme à l'entrée, sous 2 mois sinon (à vérifier sur le texte en vigueur).", ["depot", "Lettre de restitution"]],
    ["qui", "Dernière quittance et solde de tout compte", "À remettre une fois tout réglé.", null],
    ["clo", "Locataire clos dans l'appli et dans Excel", "Renseigne la date de fin du bail. Prépare les diagnostics et le bien pour la prochaine location.", ["loc", "Fiche locataire"]]
  ]}
};
function mvtRec(bien, mv){
  let r = docList("docs").find(x => x.kind === "chk" && x.bien === bien && x.mv === mv && !x.del);
  if (!r){ r = {id:uid(), kind:"chk", bien, mv, done:{}, upd:Date.now()}; docList("docs").push(r); }
  return r;
}
function mvtHas(bien, k, type){ return docList(k).some(x => x.bien === bien && !x.del && x.type === type); }
function viewMvt(){
  const id = V.bsel, t = tenantFor(id, todayIso());
  const card = mv => { const M = MVT[mv], r = docList("docs").find(x => x.kind === "chk" && x.bien === id && x.mv === mv && !x.del) || {done:{}}, n = M.etapes.filter(e => r.done[e[0]]).length;
    const type = mv === "arr" ? "entree" : "sortie";
    const rows = M.etapes.filter(e => !(e[0] === "inv" && bkind(id) === "vide")).map(([k, ti, hint, act]) => { const ok = !!r.done[k];
      const btn = act ? `<button class="mini" data-act="mv-go" data-v="${act[0]}">${act[1]}</button>` : "";
      const chip = (k === "inv" && mvtHas(id, "inv", type)) || (k === "edl" && mvtHas(id, "edl", type)) ? ' <span class="chip ok">créé</span>' : "";
      return `<div style="padding:10px 0;border-top:1px solid var(--line)"><label style="display:flex;gap:10px;align-items:flex-start"><input type="checkbox" data-mv="${mv}" data-k="${k}" ${ok ? "checked" : ""} style="margin-top:3px"><span><b style="font-size:14px">${esc(ti)}</b>${chip}${ok ? ` <span class="small muted">· ${frDate(r.done[k])}</span>` : ""}</span></label>
        <div class="small muted" style="margin:4px 0 6px 28px">${esc(hint)}</div>${btn ? `<div style="margin-left:28px">${btn}</div>` : ""}</div>`; }).join("");
    return `<div class="card"><div class="top"><h2>${M.titre}</h2><span class="chip ${n === M.etapes.filter(e => !(e[0] === "inv" && bkind(id) === "vide")).length ? "ok" : "warn"}">${n}/${M.etapes.length}</span></div>${rows}</div>`; };
  return `<div class="info">${t ? "Locataire actuel : " + esc(t.nom) + (t.debut ? " · depuis le " + frDate(t.debut) : "") : "Aucun locataire en cours pour ce bien : tu es dans la phase d'arrivée."} Coche les étapes au fur et à mesure ; les boutons ouvrent directement le bon document.</div>
    ${card("dep")}${card("arr")}<div class="small muted" style="padding:0 4px 12px">Repères généraux : la réglementation change.</div>
    <div class="card"><h2>Vérifier la réglementation</h2><div class="small muted">L'appli ne peut pas se mettre à jour toute seule sur la loi. Avant chaque nouveau bail, contrôle ces sources officielles${S.cfg && S.cfg.regVerif ? " (dernier contrôle noté le " + frDate(S.cfg.regVerif) + ")" : ""}.</div>
      <div class="rows"><div class="row"><div class="main"><div class="t">Contrat type de location</div><div class="s">Décret n° 2026-596 du 6 juillet 2026 : baux conclus ou renouvelés depuis le 1er octobre 2026 (clause résolutoire à six semaines).</div></div><a class="mini" target="_blank" rel="noopener" href="https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000054393114">Légifrance</a></div>
      <div class="row"><div class="main"><div class="t">Fiches pratiques bailleur</div><div class="s">Dépôt, congé, révision du loyer, diagnostics.</div></div><a class="mini" target="_blank" rel="noopener" href="https://www.service-public.fr/particuliers/vosdroits/N31">service-public</a></div></div>
      <div class="btns"><button class="btn sm ghost" data-act="reg-ok">J'ai vérifié aujourd'hui</button></div>
      <div class="small muted">Tu peux aussi me demander dans Claude de contrôler les textes en vigueur avant un bail : je cherche les sources officielles et je te dis ce qui a changé.</div></div>`;
}
/* ---------- PDF de relecture : même document, sans signature, marqué « projet » ---------- */
async function pdfRelect(fn, e){
  const was = RELECT, s = e && e.sig; RELECT = true; if (e) e.sig = null;
  try { return await fn(); } finally { RELECT = was; if (e) e.sig = s; }
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, v = b.dataset.v, e = V.doc ? docCur() : null;
  switch (a){
    case "mv-go": {
      if (v === "cand"){ V.tab = "rent"; V.lsel = V.bsel; V.lsub = "cand"; render(); break; }
      if (v === "docs" || v === "loc"){ V.bsub = v; render(); break; }
      if (v === "bail"){ V.bsub = "docs"; render(); sheetBail(); break; }
      if (v === "impaye" || v === "depot" || v === "rappel"){ V.bsub = "docs"; render(); sheetLettre(v); break; }
      const m = /^(edl|inv)-(e|s)$/.exec(v); if (m){ V.bsub = "docs"; render(); sheetNewDoc(m[1], m[2] === "e" ? "entree" : "sortie"); }
      break; }
    case "reg-ok": S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.regVerif = todayIso(); persist(); render(); break;
    case "dx-rel": { if (!e) break; toast("Création du PDF de relecture…"); try { const bytes = await pdfRelect(() => V.doc.kind === "edl" ? edlPdf(e) : invPdf(e), e);
        saveFile("RELECTURE-" + (V.doc.kind === "edl" ? "etat-des-lieux-" : "inventaire-") + e.type + "-" + e.bien + "-" + e.date + ".pdf", bytes, "application/pdf"); } catch(err){ toast("PDF impossible : " + err.message); } break; }
    case "bail-rel": { const o = bailRead(); if (!o.loc || !o.debut) return toast("Indique au moins le locataire et la date de prise d'effet"); if (o.lhc <= 0) return toast("Indique le loyer hors charges");
      const bytes = await pdfRelect(async () => bailPdf(o)); saveFile("RELECTURE-bail-meuble-" + V.bsel + "-" + o.debut + ".pdf", bytes, "application/pdf"); break; }
  }
});
document.addEventListener("change", ev => {
  const t = ev.target; if (!t || !t.dataset || !t.dataset.mv) return;
  const r = mvtRec(V.bsel, t.dataset.mv); if (t.checked) r.done[t.dataset.k] = todayIso(); else delete r.done[t.dataset.k]; r.upd = Date.now(); persist(); render();
});
/* ---------- Version d'essai (faux biens, adresses, locataires) ---------- */
function demoCard(){
  const back = (() => { try { return !!localStorage.getItem("glf-avant-essai"); } catch(e){ return false; } })();
  return `<div class="card"><h2>Version d'essai</h2><div class="small muted">Charge de faux biens, adresses, locataires, états des lieux et inventaires pour tester toutes les fonctions sans toucher à tes vraies données.</div>
    <div class="btns"><button class="btn sm" data-act="demo">Charger la version d'essai</button>${S.demo && back ? '<button class="btn sm ghost" data-act="demo-back">Retrouver mes données</button>' : ""}</div></div>`;
}
