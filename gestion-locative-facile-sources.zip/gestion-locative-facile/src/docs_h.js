/* ============ Mise en location : annonce par bien + candidatures (sans serveur, échanges par e-mail) ============ */
/* Données : S.annonces = {bien: {...}} et S.cand = [{...}]. Pièces jointes : IndexedDB "f:<id>" (cet appareil seulement). */
const CAND_ST = [["dem", "Demande reçue"], ["vis", "Visite"], ["dos", "Dossier à vérifier"], ["ret", "Retenu"], ["ref", "Refusé"]];
const candStLabel = k => (CAND_ST.find(x => x[0] === k) || [0, k])[1];
const CAND_CONTRAT = ["", "CDI", "CDI en période d'essai", "CDD / intérim", "Fonctionnaire", "Indépendant / entreprise", "Étudiant", "Retraité", "Autre"];
const CAND_GARANT = [["", "Aucun garant"], ["proche", "Garant (parent, proche)"], ["visale", "Garantie Visale"], ["autre", "Autre garantie"]];
/* Pièces que le bailleur peut demander : liste limitative (décret n° 2015-1437), à contrôler sur le texte en vigueur. */
const CAND_PIECES = [
  ["id", "Pièce d'identité en cours de validité", 0], ["dom", "Justificatif de domicile actuel", 0], ["act", "Justificatif de situation professionnelle", 0],
  ["res", "Justificatifs de ressources (3 derniers bulletins, avis d'imposition)", 0],
  ["gid", "Garant : pièce d'identité", 1], ["gdom", "Garant : justificatif de domicile", 1], ["gact", "Garant : situation professionnelle", 1], ["gres", "Garant : justificatifs de ressources", 1]
];
const SITES_ANN = [["lbc", "Leboncoin", "https://www.leboncoin.fr"], ["pap", "PAP (de particulier à particulier)", "https://www.pap.fr"], ["sl", "SeLoger", "https://www.seloger.com"], ["fb", "Facebook Marketplace", "https://www.facebook.com/marketplace"], ["autre", "Autre site ou affichage", ""]];
const candList = () => (S.cand = S.cand || []);
const candGet = id => candList().find(x => x.id === id && !x.del);
const annGet = bien => { S.annonces = S.annonces || {}; return S.annonces[bien] || null; };
const fmtVisite = v => v ? frDate(v.slice(0, 10)) + (v.length > 10 ? " à " + v.slice(11, 16) : "") : "";
const nf1 = n => (Math.round(n * 10) / 10).toString().replace(".", ",");

function annDefaults(bien){
  const b = S.biens.find(x => x.id === bien) || {}, t = live(S.locataires).filter(x => x.bien === bien).sort((a, c) => (c.debut || "").localeCompare(a.debut || ""))[0] || {};
  return {titre:"", type:(b.bail === "vide" ? "Appartement" : "Appartement meublé"), surf:"", loc:"", loyer:b.loyer || t.loyer || "", charges:t.charges || "", depot:b.loyer || t.depot || "", dispo:"", dpe:"", ges:"", equip:"", mail:(S.cfg && S.cfg.candMail) || "", tel:"", pub:{}, photos:[], perso:"", statut:"brouillon"};
}
function annOf(bien){ return Object.assign(annDefaults(bien), annGet(bien) || {}); }
function loyerCC(bien){ const a = annOf(bien); return (Number(a.loyer) || 0) + (Number(a.charges) || 0); }

/* ---------- Note de pertinence (indicative) ---------- */
function candScore(c){
  const cc = loyerCC(c.bien); if (!cc) return null; const r = Number(c.rev) || 0, g = Number(c.grev) || 0;
  if (r >= 3 * cc) return {lvl:"ok", txt:"Revenus × " + nf1(r / cc) + " le loyer"};
  if (c.garant === "visale") return {lvl:"ok", txt:"Garantie Visale" + (r ? " · revenus × " + nf1(r / cc) : "")};
  if (c.garant && g >= 3 * cc) return {lvl:"ok", txt:"Garant × " + nf1(g / cc) + " le loyer"};
  if (r >= 2.5 * cc) return {lvl:"warn", txt:"Revenus × " + nf1(r / cc) + " (un peu juste)"};
  if (r) return {lvl:"bad", txt:"Revenus × " + nf1(r / cc) + " le loyer"};
  return {lvl:"", txt:"Revenus non renseignés"};
}
const candPieces = c => { const need = CAND_PIECES.filter(p => !p[2] || (c.garant === "proche" || c.garant === "autre")), got = need.filter(p => c.pieces && c.pieces[p[0]]).length; return {n:got, m:need.length}; };

/* ---------- Texte de l'annonce ---------- */
function annText(bien){ const a = annOf(bien); return a.perso && a.perso.trim() ? a.perso.trim() : annGen(bien); }
function annGen(bien){
  const a = annOf(bien), cc = (Number(a.loyer) || 0) + (Number(a.charges) || 0), L = [];
  L.push((a.titre || a.type + (a.surf ? " " + a.surf + " m²" : "") + (a.loc ? " – " + a.loc : "")).trim());
  L.push("");
  L.push(a.type + (a.surf ? " de " + a.surf + " m²" : "") + (a.loc ? ", " + a.loc : "") + ".");
  if (a.equip) L.push(a.equip.trim());
  L.push("");
  L.push(Number(a.charges) ? "Loyer : " + eur(a.loyer) + " + " + eur(a.charges) + " de charges, soit " + eur(cc) + " par mois charges comprises." : "Loyer : " + eur(a.loyer) + " par mois.");
  L.push("Dépôt de garantie : " + eur(a.depot) + ".");
  if (a.dispo) L.push("Disponible à partir du " + frDate(a.dispo) + ".");
  L.push("Performance énergétique (DPE) : classe " + (a.dpe || "à compléter") + (a.ges ? " · GES : classe " + a.ges : "") + ".");
  L.push("");
  L.push("Pour candidater, écrivez-moi" + (a.mail ? " à " + a.mail : "") + (a.tel ? " ou appelez le " + a.tel : "") + " en indiquant : votre nom, un numéro de téléphone, votre situation professionnelle, vos revenus mensuels, le nombre d'occupants, votre date d'emménagement souhaitée et, si vous en avez un, votre garant. Les pièces justificatives vous seront demandées ensuite.");
  return L.join("\n");
}
function annChecks(bien){
  const a = annOf(bien), w = [];
  if (!a.loyer) w.push("Indique le loyer.");
  if (!a.surf) w.push("Indique la surface (obligatoire dans l'annonce).");
  if (!a.dpe) w.push("La classe énergie (DPE) doit figurer dans l'annonce.");
  if (a.dpe === "G") w.push("Un logement classé G ne peut plus être loué en résidence principale.");
  if (!a.mail) w.push("Indique l'e-mail où recevoir les candidatures.");
  if (!a.loc) w.push("Indique le quartier ou la ville (évite l'adresse exacte dans l'annonce).");
  return w;
}

/* ---------- Vue de l'onglet ---------- */
function viewRent(){
  const ids = bienIds(); if (!V.lsel || !ids.includes(V.lsel)) V.lsel = ids[0] || ""; if (!V.lsub) V.lsub = "cand";
  const bien = V.lsel, subs = [["cand", "Candidats"], ["ann", "Annonce"]];
  const seg = `<div class="seg">${subs.map(([k, l]) => `<button class="${V.lsub === k ? "on" : ""}" data-act="lsub" data-v="${k}">${l}</button>`).join("")}</div>`;
  const body = !bien ? '<div class="empty">Ajoute d\'abord un bien dans Réglages.</div>' : V.lsub === "ann" ? viewAnnonce(bien) : viewCands(bien);
  return topbar("Mise en location") + bienSeg("lsel", bien, false) + seg + body;
}
function viewAnnonce(bien){
  const a = annOf(bien), w = annChecks(bien), txt = annText(bien), lbl = {brouillon:"Brouillon", publiee:"Publiée", louee:"Louée"}[a.statut] || "Brouillon";
  const sites = SITES_ANN.map(([k, n, u]) => { const d = a.pub && a.pub[k]; return `<div class="row"><label style="display:flex;gap:10px;align-items:center;flex:1"><input type="checkbox" data-pub="${k}" ${d ? "checked" : ""}><span><b style="font-size:14px">${esc(n)}</b>${d ? ` <span class="small muted">· publiée le ${frDate(d)}</span>` : ""}</span></label>${u ? `<a class="mini" target="_blank" rel="noopener" href="${u}">Ouvrir</a>` : ""}</div>`; }).join("");
  return `<div class="card"><div class="top"><h2>Annonce · ${esc(bienName(bien))}</h2><span class="chip ${a.statut === "publiee" ? "ok" : a.statut === "louee" ? "" : "warn"}">${lbl}</span></div>
    ${w.length ? `<div class="info" style="background:var(--warn-soft)">${w.map(x => "• " + esc(x)).join("<br>")}</div>` : ""}
    <label class="f" style="margin-top:8px">${a.perso && a.perso.trim() ? "Ton texte (utilisé tel quel)" : "Texte prêt à publier"}<textarea id="an-txt" readonly style="min-height:240px">${esc(txt)}</textarea></label>
    <div class="btns"><button class="btn" data-act="an-edit">Modifier l'annonce</button><button class="btn ghost" data-act="an-copy">Copier le texte</button><button class="btn ghost" data-act="an-share">Partager</button></div>
    <div class="btns"><button class="btn" style="flex:1" data-act="an-pdf">Créer le PDF de l'annonce</button></div>
    <div class="small muted">Le PDF reprend le texte et tes photos : envoie-le par Mail ou Messages. Pour les sites d'annonces, ajoute aussi les photos sur le site. Vérifie les mentions obligatoires sur le site choisi et, si ta commune est en zone d'encadrement des loyers, le loyer de référence.</div></div>
    <div class="card"><div class="top"><h2>Photos de l'annonce</h2><span class="small muted">${(a.photos || []).length} / ${ANN_MAX_PH}</span></div>
    ${(a.photos || []).length ? `<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">${a.photos.map((pid, i) => `<div><img data-ph="${pid}" alt="Photo ${i + 1}" style="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:10px;background:var(--line)">
      <div style="display:flex;gap:4px;margin-top:4px">${i ? `<button class="mini" data-act="an-ph-first" data-pid="${pid}" style="flex:1">1re</button>` : '<span class="chip ok" style="flex:1;text-align:center">Couverture</span>'}<button class="mini" data-act="an-ph-del" data-pid="${pid}">✕</button></div></div>`).join("")}</div>` : '<div class="empty">Aucune photo. Ajoute-en pour un PDF complet.</div>'}
    <label class="f" style="margin-top:8px">Ajouter des photos<input id="an-ph" type="file" accept="image/*" multiple></label>
    <div class="small muted">La première photo sert de couverture. Les photos restent sur cet appareil (elles ne sont pas dans la sauvegarde JSON).</div></div>
    <div class="card"><h2>Où l'annonce est publiée</h2><div class="rows">${sites}</div>
    <div class="btns"><button class="btn sm ghost" data-act="an-state" data-v="${a.statut === "louee" ? "brouillon" : "louee"}">${a.statut === "louee" ? "Remettre en recherche" : "Logement loué : fermer l'annonce"}</button></div>
    <div class="small muted">Quand tu retiens un candidat, l'annonce passe automatiquement en « Louée ». Pense à la retirer des sites.</div></div>`;
}
function viewCands(bien){
  const all = candList().filter(c => c.bien === bien && !c.del), flt = V.lflt || "all";
  const cnt = k => all.filter(c => c.statut === k).length;
  const chips = `<div class="seg"><button class="${flt === "all" ? "on" : ""}" data-act="lflt" data-v="all">Tous ${all.length}</button>${CAND_ST.map(([k, l]) => `<button class="${flt === k ? "on" : ""}" data-act="lflt" data-v="${k}">${l} ${cnt(k)}</button>`).join("")}</div>`;
  const ord = k => CAND_ST.findIndex(x => x[0] === k);
  const list = all.filter(c => flt === "all" || c.statut === flt).sort((a, b) => ord(a.statut) - ord(b.statut) || (b.dateDem || "").localeCompare(a.dateDem || ""));
  const next = all.filter(c => c.visite && c.visite >= todayIso() && c.statut !== "ref" && c.statut !== "ret").sort((a, b) => a.visite.localeCompare(b.visite));
  const row = c => { const s = candScore(c), p = candPieces(c);
    return `<button class="rowbtn" style="width:100%;text-align:left" data-act="cd-open" data-id="${c.id}"><div class="kv"><span><b>${esc(c.nom)}</b> <span class="chip ${c.statut === "ret" ? "ok" : c.statut === "dos" ? "warn" : ""}">${candStLabel(c.statut)}</span></span><span class="small muted">${p.n}/${p.m} pièces</span></div>
      <div class="small muted">${s ? `<span class="chip ${s.lvl}">${esc(s.txt)}</span> ` : ""}${c.visite ? "Visite " + fmtVisite(c.visite) : c.dateDem ? "Demande du " + frDate(c.dateDem) : ""}</div></button>`; };
  const refus = all.filter(c => c.statut === "ref").length;
  return `<div class="card"><div class="top"><h2>Candidats · ${esc(bienName(bien))}</h2><button class="btn sm" data-act="cd-new">+ Candidat</button></div>
    <div class="small muted" style="margin-bottom:6px">Loyer charges comprises : ${loyerCC(bien) ? eur(loyerCC(bien)) : "à renseigner dans l'annonce"}. Règle courante : revenus d'au moins 3 fois ce montant, ou un garant. La note est indicative et ne remplace pas ton jugement.</div>${chips}</div>
    ${candCard(bien)}
    ${next.length ? `<div class="card"><h2>Prochaines visites</h2><div class="rows">${next.map(c => `<div class="row"><div class="main"><div class="t">${fmtVisite(c.visite)} · ${esc(c.nom)}</div></div><button class="mini" data-act="cd-ics" data-id="${c.id}">Calendrier</button></div>`).join("")}</div></div>` : ""}
    <div class="card"><div class="rows">${list.length ? list.map(row).join("") : '<div class="empty">Aucun candidat. Quand une demande arrive par e-mail, ajoute-la avec « + Candidat ».</div>'}</div></div>
    ${(() => { const cl = candList().filter(c => !c.del); const nf = cl.reduce((n, c) => n + (c.fichiers || []).length, 0); return `<div class="card"><h2>Sauvegarde des candidats</h2>
      <div class="small muted"><b>${cl.length} fiche(s)</b> et <b>${nf} fichier(s)</b> joints (pièces importées dans les fiches). Les fiches (coordonnées, situation, notes, pièces cochées) sont dans toutes les sauvegardes. Les <b>fichiers</b> restent sur cet appareil : ils ne sont que dans la <b>sauvegarde complète (.zip)</b>. Pour changer d'appareil ou ne rien perdre, fais-la ici, puis restaure-la dans Réglages › Importer un fichier.</div>
      <div class="btns"><button class="btn sm" data-act="exp-zip">Sauvegarde complète (.zip)</button></div></div>`; })()}
    <div class="card"><h2>Comment ça marche</h2><div class="small muted">1. Publie l'annonce avec ton e-mail.<br>2. Pour chaque demande, crée une fiche candidat et réponds avec les courriers prêts à l'emploi.<br>3. Planifie la visite, puis demande le dossier.<br>4. Coche les pièces reçues (tu peux les joindre sur cet appareil).<br>5. « Retenir » crée le locataire du bien et prépare l'arrivée.</div>
    ${refus ? `<div class="btns"><button class="btn sm ghost" data-act="cd-purge">Effacer les ${refus} dossier(s) refusé(s)</button></div><div class="small muted">Les données d'un candidat non retenu ne doivent pas être gardées : efface-les une fois la location conclue.</div>` : ""}</div>`;
}

/* ---------- Fiche annonce ---------- */
function sheetAnnonce(){
  const bien = V.lsel, a = annOf(bien);
  openSheet(`<h2>Annonce · ${esc(bienName(bien))}</h2>
    <div class="seg"><button class="on" data-act="an-tab" data-v="infos">Informations</button><button data-act="an-tab" data-v="texte">Mon texte</button></div>
    <div id="an-p-texte" style="display:none;flex-direction:column;gap:12px">
      <div class="info">Écris ou colle ton propre texte d'annonce. S'il n'est pas vide, il remplace le texte généré : il est copié, partagé et placé dans le PDF exactement comme tu l'as écrit (le prix, les photos et les infos clés du PDF restent).</div>
      <label class="f">Mon texte d'annonce<textarea id="an-perso" style="min-height:300px">${esc(a.perso || "")}</textarea></label>
      <label class="f">Importer mon texte depuis un fichier Word (.docx) ou texte (.txt)<input id="an-doc" type="file" accept="*/*"></label>
      <div class="btns"><button class="btn sm ghost" data-act="an-gen">Insérer le texte généré</button><button class="btn sm ghost" data-act="an-clear">Effacer mon texte</button></div>
      <div class="small muted">Le texte généré reprend les infos déjà enregistrées. Enregistre avec le bouton en bas ; laisse vide pour garder le texte généré.</div></div>
    <div id="an-p-infos" style="display:flex;flex-direction:column;gap:12px">
    ${dxF("an-titre", "Titre (facultatif)", a.titre)}${dxF("an-type", "Type de logement", a.type)}
    <div class="tl">${dxF("an-surf", "Surface (m²)", a.surf, 'inputmode="decimal"')}${dxF("an-loc", "Quartier / ville", a.loc)}</div>
    <div class="tl">${dxF("an-loyer", "Loyer hors charges", a.loyer, 'inputmode="decimal"')}${dxF("an-chg", "Charges", a.charges, 'inputmode="decimal"')}</div>
    <div class="tl">${dxF("an-depot", "Dépôt de garantie", a.depot, 'inputmode="decimal"')}${dxF("an-dispo", "Disponible le", a.dispo, 'type="date"')}</div>
    <div class="tl">${dxS("an-dpe", "DPE (énergie)", [["", "—"]].concat("ABCDEFG".split("").map(x => [x, x])), a.dpe)}${dxS("an-ges", "GES", [["", "—"]].concat("ABCDEFG".split("").map(x => [x, x])), a.ges)}</div>
    <label class="f">Équipements, points forts<textarea id="an-equip" style="min-height:90px">${esc(a.equip)}</textarea></label>
    ${dxF("an-mail", "E-mail pour les candidatures", a.mail, 'type="email" autocapitalize="off"')}${dxF("an-tel", "Téléphone (facultatif)", a.tel, 'type="tel"')}</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="an-save">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}

/* ---------- Fiche candidat ---------- */
function sheetCand(id){
  const c = id ? candGet(id) : {bien:V.lsel, nom:"", tel:"", email:"", statut:"dem", dateDem:todayIso(), contrat:"", rev:"", occ:"", entree:"", garant:"", grev:"", visite:"", note:"", pieces:{}, fichiers:[]};
  if (!c) return;
  const garantOn = c.garant === "proche" || c.garant === "autre";
  const pcs = CAND_PIECES.map(([k, l, g]) => `<label style="display:flex;gap:8px;align-items:flex-start;padding:4px 0${g ? ";" + (garantOn ? "" : "display:none") : ""}" ${g ? 'class="cd-g"' : ""}><input type="checkbox" id="cd-p-${k}" ${c.pieces && c.pieces[k] ? "checked" : ""} style="margin-top:3px"> <span>${esc(l)}</span></label>`).join("");
  const files = (c.fichiers || []).map(f => `<div class="row">${thumb(f.fid, f.nom)}<div class="main"><div class="t" style="font-size:13.5px">${esc(f.nom)}</div></div><button class="mini" data-act="cf-open" data-id="${c.id}" data-fid="${f.fid}">Ouvrir</button><button class="mini" data-act="cf-del" data-id="${c.id}" data-fid="${f.fid}">Retirer</button></div>`).join("");
  openSheet(`<h2>${id ? esc(c.nom) : "Nouveau candidat"}</h2>
    ${dxF("cd-nom", "Nom et prénom", c.nom)}
    <div class="tl">${dxF("cd-tel", "Téléphone", c.tel, 'type="tel"')}${dxF("cd-mail", "E-mail", c.email, 'type="email" autocapitalize="off"')}</div>
    <div class="tl">${dxS("cd-st", "Étape", CAND_ST, c.statut)}${dxF("cd-dem", "Demande du", c.dateDem, 'type="date"')}</div>
    <div class="tl">${dxS("cd-ct", "Situation", CAND_CONTRAT.map(x => [x, x || "—"]), c.contrat)}${dxF("cd-rev", "Revenus nets / mois", c.rev, 'inputmode="decimal"')}</div>
    <div class="tl">${dxF("cd-occ", "Occupants", c.occ, 'inputmode="numeric"')}${dxF("cd-ent", "Emménagement souhaité", c.entree, 'type="date"')}</div>
    <div class="tl">${dxS("cd-gar", "Garant", CAND_GARANT, c.garant)}${dxF("cd-grev", "Revenus du garant", c.grev, 'inputmode="decimal"')}</div>
    ${dxF("cd-vis", "Visite (date et heure)", c.visite, 'type="datetime-local"')}
    <label class="f">Notes<textarea id="cd-note" style="min-height:80px">${esc(c.note)}</textarea></label>
    <div class="small muted" style="margin-top:8px">Pièces reçues (liste limitative du décret n° 2015-1437 : ne demande rien d'autre)</div>${pcs}
    ${id && dosLink(c) ? `<div class="small muted" style="margin-top:8px">2e formulaire : le candidat y dépose chaque pièce (identité, domicile, contrat, bulletins, avis d'imposition, garant)</div><div class="btns"><button class="btn sm" data-act="cd-dl-copy" data-id="${id}">Copier le lien du dossier</button><button class="btn sm ghost" data-act="cd-dl-share" data-id="${id}">Partager</button></div>` : ""}
    ${id ? `<div class="small muted" style="margin-top:8px">Pièces jointes (restent sur cet appareil, non incluses dans la sauvegarde)</div><div class="rows">${files}</div>
      <label class="f">Joindre une photo ou un PDF<input id="cd-file" type="file" accept="image/*,.pdf" multiple></label>` : '<div class="small muted">Enregistre la fiche pour pouvoir joindre des pièces.</div>'}
    <div class="btns"><button class="btn" style="flex:1" data-act="cd-save" data-id="${id || ""}">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Fermer</button></div>
    ${id ? `<div class="btns"><button class="btn sm" data-act="cd-mail" data-id="${id}">Écrire au candidat</button>${c.visite ? `<button class="btn sm ghost" data-act="cd-ics" data-id="${id}">Visite au calendrier</button>` : ""}${c.statut !== "ret" ? `<button class="btn sm" style="background:var(--ok,#1f8a5b)" data-act="cd-keep" data-id="${id}">Retenir ce candidat</button>` : ""}<button class="btn sm danger" data-act="cd-del" data-id="${id}">Supprimer</button></div>` : ""}`);
}
function cdRead(c){
  const num = id => { const v = parseNum($("#" + id).value); return v == null ? "" : v; };
  c.nom = dxV("cd-nom"); c.tel = dxV("cd-tel"); c.email = dxV("cd-mail"); c.statut = $("#cd-st").value; c.dateDem = dxV("cd-dem"); c.contrat = $("#cd-ct").value; c.rev = num("cd-rev");
  c.occ = dxV("cd-occ"); c.entree = dxV("cd-ent"); c.garant = $("#cd-gar").value; c.grev = num("cd-grev"); c.visite = dxV("cd-vis"); c.note = $("#cd-note").value.trim();
  c.pieces = {}; for (const p of CAND_PIECES){ const e = $("#cd-p-" + p[0]); if (e && e.checked) c.pieces[p[0]] = todayIso(); }
  c.upd = Date.now(); return c;
}
function cdSave(id){
  if (!dxV("cd-nom")){ toast("Donne le nom du candidat"); return null; }
  const c = id ? candGet(id) : {id:uid(), bien:V.lsel, fichiers:[]}; cdRead(c); if (!id) candList().push(c);
  if (c.statut === "ref" && c.visite) { /* garde la date pour mémoire */ }
  persist(); return c;
}

/* ---------- Courriers aux candidats (e-mail préparé) ---------- */
function candMail(k, c){
  const a = annOf(c.bien), b = S.biens.find(x => x.id === c.bien) || {}, me = (S.cfg && S.cfg.bailleur) || "", nom = c.nom || "", head = "Bonjour " + nom + ",\n\n", sign = "\n\nCordialement,\n" + me;
  const pieces = "- Une pièce d'identité en cours de validité\n- Un justificatif de domicile actuel\n- Un justificatif de votre situation professionnelle (contrat de travail, carte d'étudiant, extrait Kbis…)\n- Vos justificatifs de ressources (trois derniers bulletins de salaire, dernier avis d'imposition)\n- Si vous avez un garant : les mêmes pièces pour lui";
  const T = {
    rep:{l:"Réponse à une demande", s:"Votre demande de location – " + (a.titre || bienName(c.bien)), b:head + "Merci de votre intérêt pour le logement" + (a.loc ? " situé à " + a.loc : "") + ". Il est toujours disponible" + (a.dispo ? " à partir du " + frDate(a.dispo) : "") + ".\n\nLoyer : " + eur(a.loyer) + (Number(a.charges) ? " + " + eur(a.charges) + " de charges" : "") + ". Dépôt de garantie : " + eur(a.depot) + ".\n\n" + (candLink(c.bien) ? "Pour étudier votre demande, merci de remplir ce court formulaire (il prépare un e-mail que vous m'envoyez) :\n" + candLink(c.bien) + "\n\n" : "Pour étudier votre demande, pouvez-vous me préciser : votre numéro de téléphone, votre situation professionnelle, vos revenus mensuels, le nombre d'occupants, votre date d'emménagement souhaitée et, le cas échéant, votre garant ?\n\n") + "Je vous proposerai ensuite une visite." + sign},
    vis:{l:"Invitation à la visite", s:"Visite du logement – " + (c.visite ? fmtVisite(c.visite) : "à confirmer"), b:head + "Je vous propose de visiter le logement " + (c.visite ? "le " + fmtVisite(c.visite) : "à la date convenue") + ", à l'adresse suivante : " + (b.adresse || "à préciser") + ".\n\nMerci de me confirmer votre présence par retour de message. En cas d'empêchement, prévenez-moi pour que nous trouvions un autre créneau." + (dosLink(c) ? "\n\nVous pouvez déjà déposer votre dossier (une case par pièce) ici :\n" + dosLink(c) : "") + sign},
    dos:{l:"Demande du dossier", s:"Votre dossier de location", b:head + "Merci d'avoir rempli le formulaire. Si le logement vous intéresse toujours, pouvez-vous m'envoyer votre dossier ? Voici les pièces nécessaires (je ne peux pas en demander d'autres) :\n\n" + pieces + "\n\n" + (dosLink(c) ? "Le plus simple : ce formulaire a une case par document, il prépare un e-mail avec toutes vos pièces :\n" + dosLink(c) + "\n\n" : "") + "Vos documents servent uniquement à étudier votre candidature et seront supprimés si elle n'est pas retenue." + sign},
    ret:{l:"Dossier retenu", s:"Votre candidature est retenue", b:head + "J'ai le plaisir de vous informer que votre dossier est retenu pour le logement" + (b.adresse ? " situé " + b.adresse : "") + ".\n\nLes prochaines étapes : signature du bail, état des lieux et inventaire du mobilier, versement du dépôt de garantie (" + eur(a.depot) + ") et remise d'une attestation d'assurance habitation.\n\nPouvons-nous convenir d'un rendez-vous pour la signature" + (c.entree ? " autour du " + frDate(c.entree) : "") + " ?" + sign},
    ref:{l:"Réponse négative", s:"Suite à votre candidature", b:head + "Merci d'avoir candidaté pour ce logement et du temps que vous y avez consacré. J'ai le regret de vous informer que je ne pourrai pas donner suite à votre candidature.\n\nJe vous souhaite de trouver rapidement un logement qui vous convienne. Vos documents seront supprimés." + sign}
  };
  return T[k];
}
/* Courrier proposé par défaut : la personne a déjà reçu le 1er lien, donc la suite (2e lien) */
const candDefTpl = c => c.statut === "ret" ? "ret" : c.statut === "ref" ? "ref" : (c.statut === "dem" && c.src !== "formulaire") ? "rep" : "dos";
function sheetMail(id, k){
  const c = candGet(id); if (!c) return; V.mailFor = id; k = k || candDefTpl(c); const m = candMail(k, c);
  const tpls = ["rep", "vis", "dos", "ret", "ref"].map(x => [x, candMail(x, c).l]);
  openSheet(`<h2>Écrire à ${esc(c.nom)}</h2>${dxS("cm-tpl", "Courrier", tpls, k)}
    ${dxF("cm-sub", "Objet", m.s)}<label class="f">Message<textarea id="cm-msg" style="min-height:260px">${esc(m.b)}</textarea></label>
    <div class="btns">${c.email ? `<button class="btn" data-act="cm-send" data-id="${id}">Ouvrir dans Mail</button>` : ""}${c.tel ? `<button class="btn ghost" data-act="cm-sms" data-id="${id}">SMS</button>` : ""}<button class="btn ghost" data-act="cm-copy">Copier</button><button class="btn ghost" data-act="cd-open" data-id="${id}">Retour</button></div>
    ${c.email ? "" : '<div class="small muted">Ajoute l\'e-mail du candidat dans sa fiche pour ouvrir Mail directement.</div>'}`);
}
function sheetKeep(id){
  const c = candGet(id); if (!c) return; const a = annOf(c.bien);
  openSheet(`<h2>Retenir ${esc(c.nom)}</h2><div class="info">Le locataire est créé dans « Biens › Locataires » avec ces informations. Tu pourras les corriger ensuite.</div>
    ${dxF("kp-debut", "Début du bail", c.entree || a.dispo || todayIso(), 'type="date"')}
    <div class="tl">${dxF("kp-loyer", "Loyer hors charges", a.loyer, 'inputmode="decimal"')}${dxF("kp-chg", "Charges", a.charges, 'inputmode="decimal"')}</div>
    ${dxF("kp-depot", "Dépôt de garantie", a.depot, 'inputmode="decimal"')}
    <div class="small muted">Dépôt maximum : 2 mois de loyer hors charges en meublé, 1 mois en logement vide.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="cd-keep-ok" data-id="${id}">Créer le locataire</button><button class="btn ghost" data-act="cd-open" data-id="${id}">Annuler</button></div>`);
}
function candIcs(c){
  const d = c.visite; if (!d) return null; const z = x => x.replace(/[-:]/g, "").slice(0, 15), st = z(d + ":00"), en = new Date(new Date(d).getTime() + 30 * 60000), p = n => String(n).padStart(2, "0");
  const e = en.getFullYear() + p(en.getMonth() + 1) + p(en.getDate()) + "T" + p(en.getHours()) + p(en.getMinutes()) + "00", b = S.biens.find(x => x.id === c.bien) || {};
  return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Gestion Locative Facile//FR", "BEGIN:VEVENT", "UID:" + c.id + "@mes-locations", "DTSTAMP:" + new Date().toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z", "DTSTART:" + st, "DTEND:" + e, "SUMMARY:Visite " + (c.nom || "") + " – " + bienName(c.bien), "LOCATION:" + (b.adresse || "").replace(/[,;]/g, " "), "END:VEVENT", "END:VCALENDAR"].join("\r\n");
}

/* ---------- Actions ---------- */
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, v = b.dataset.v, id = b.dataset.id;
  switch (a){
    case "lsel": V.lsel = v; render(); break;
    case "lsub": V.lsub = v; render(); break;
    case "lflt": V.lflt = v; render(); break;
    case "an-edit": sheetAnnonce(); break;
    case "an-tab": { const t = v === "texte"; $("#an-p-texte").style.display = t ? "flex" : "none"; $("#an-p-infos").style.display = t ? "none" : "flex"; document.querySelectorAll('#sheet [data-act=an-tab]').forEach(x => x.classList.toggle("on", x.dataset.v === v)); break; }
    case "an-gen": { const cur = $("#an-perso").value.trim(); $("#an-perso").value = (cur ? cur + "\n\n" : "") + annGen(V.lsel); toast("Texte généré inséré : adapte-le"); break; }
    case "an-clear": $("#an-perso").value = ""; toast("Texte effacé : le texte généré sera utilisé"); break;
    case "an-save": { const num = i => { const x = parseNum($("#" + i).value); return x == null ? "" : x; }, cur = annOf(V.lsel);
      S.annonces = S.annonces || {}; S.annonces[V.lsel] = Object.assign(cur, {titre:dxV("an-titre"), type:dxV("an-type") || "Appartement", surf:dxV("an-surf"), loc:dxV("an-loc"), loyer:num("an-loyer"), charges:num("an-chg"), depot:num("an-depot"), dispo:dxV("an-dispo"), dpe:$("#an-dpe").value, ges:$("#an-ges").value, equip:$("#an-equip").value.trim(), perso:$("#an-perso").value.trim(), mail:dxV("an-mail"), tel:dxV("an-tel"), upd:Date.now()});
      S.cfg = S.cfg || {bailleur:"", adr:{}}; if (S.annonces[V.lsel].mail) S.cfg.candMail = S.annonces[V.lsel].mail;
      persist(); closeSheet(); render(); break; }
    case "an-copy": { const t = annText(V.lsel); (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("Texte copié")).catch(() => { const e = $("#an-txt"); if (e){ e.removeAttribute("readonly"); e.select(); } toast("Sélectionné : copie-le"); }); break; }
    case "an-share": { const t = annText(V.lsel); try { if (navigator.share) await navigator.share({title:"Annonce " + bienName(V.lsel), text:t}); else toast("Utilise « Copier le texte »"); } catch(e){} break; }
    case "an-pdf": { const w = annChecks(V.lsel).filter(x => !/e-mail|quartier/.test(x)); toast("Création du PDF…"); try { const bytes = await annoncePdf(V.lsel); saveFile("annonce-" + V.lsel + ".pdf", bytes, "application/pdf"); if (w.length) toast("PDF créé. À compléter : " + w[0]); } catch(err){ toast("PDF impossible : " + err.message); } break; }
    case "an-ph-first": { const cur = annOf(V.lsel); cur.photos = [b.dataset.pid].concat((cur.photos || []).filter(x => x !== b.dataset.pid)); cur.upd = Date.now(); S.annonces = S.annonces || {}; S.annonces[V.lsel] = cur; persist(); render(); break; }
    case "an-ph-del": { const cur = annOf(V.lsel); cur.photos = (cur.photos || []).filter(x => x !== b.dataset.pid); phDel(b.dataset.pid); cur.upd = Date.now(); S.annonces = S.annonces || {}; S.annonces[V.lsel] = cur; persist(); render(); break; }
    case "an-state": { S.annonces = S.annonces || {}; const cur = annOf(V.lsel); cur.statut = v; cur.upd = Date.now(); S.annonces[V.lsel] = cur; persist(); render(); break; }
    case "cd-link-copy": { const l = $("#cd-link").value; (navigator.clipboard ? navigator.clipboard.writeText(l) : Promise.reject()).then(() => toast("Lien copié")).catch(() => { $("#cd-link").select(); toast("Sélectionné : copie-le"); }); break; }
    case "cd-link-share": { const l = $("#cd-link").value; try { if (navigator.share) await navigator.share({title:"Candidature de location", text:"Voici le formulaire de candidature :", url:l}); else toast("Utilise « Copier le lien »"); } catch(e){} break; }
    case "cd-dl-copy": { const c = candGet(id), l = c && dosLink(c); if (!l) return toast("Indique d'abord ton e-mail dans Annonce › Modifier"); (navigator.clipboard ? navigator.clipboard.writeText(l) : Promise.reject()).then(() => toast("Lien du dossier copié")).catch(() => toast("Copie impossible : utilise Partager")); break; }
    case "cd-dl-share": { const c = candGet(id), l = c && dosLink(c); if (!l) return toast("Indique d'abord ton e-mail dans Annonce › Modifier"); try { if (navigator.share) await navigator.share({title:"Dossier de location", text:"Voici le formulaire pour déposer ton dossier :", url:l}); else toast("Utilise « Copier le lien du dossier »"); } catch(e){} break; }
    case "cd-paste": sheetPaste(); break;
    case "cd-paste-read": { try { const t = await navigator.clipboard.readText(); $("#cp-txt").value = t; } catch(e){ toast("Colle le texte à la main dans la zone"); } break; }
    case "cd-paste-ok": { const fl = [...($("#cp-files") ? $("#cp-files").files : [])], tf = fl.find(f => /\.txt$/i.test(f.name) || f.type === "text/plain"), others = fl.filter(f => f !== tf);
      let txt = $("#cp-txt").value; if (!txt.trim() && tf) txt = await tf.text(); const o = parseCandText(txt); if (!o) return toast("Texte non reconnu : il doit contenir « Nom : … »");
      const isDos = /^\s*DOSSIER\b/i.test(txt); const c = candFromParsed(o); if (isDos){ c.statut = "dos"; c.src = "dossier"; c.note = c.note.replace(/^Pièces annoncées[^\n]*\n?/m, "").trim(); }
      const dup = candList().find(x => !x.del && x.bien === c.bien && ((c.email && x.email && x.email.toLowerCase() === c.email.toLowerCase()) || x.nom.toLowerCase() === c.nom.toLowerCase()));
      if (dup){ const n = await candAttach(dup, others); if (isDos && (dup.statut === "dem" || dup.statut === "vis")) dup.statut = "dos"; dup.upd = Date.now(); persist(); V.lsel = dup.bien; V.lsub = "cand"; render(); toast(n ? n + " pièce(s) ajoutée(s) à la fiche de " + dup.nom : "Ce candidat est déjà dans la liste"); sheetCand(dup.id); break; }
      candList().push(c); const n = await candAttach(c, others); persist(); V.lsel = c.bien; V.lsub = "cand"; render(); sheetCand(c.id); toast("Fiche créée" + (n ? " avec " + n + " pièce(s)" : "") + " : vérifie les informations"); break; }
    case "cd-new": sheetCand(""); break;
    case "cd-open": sheetCand(id); break;
    case "cd-save": { const c = cdSave(id); if (!c) break; closeSheet(); render(); toast("Candidat enregistré"); break; }
    case "cd-mail": { const c = cdSave(id); if (!c) break; sheetMail(id, ""); break; }
    case "cm-send": { const c = candGet(id); if (!c) break; location.href = "mailto:" + encodeURIComponent(c.email).replace(/%40/g, "@") + "?subject=" + encodeURIComponent($("#cm-sub").value) + "&body=" + encodeURIComponent($("#cm-msg").value); break; }
    case "cm-sms": { const c = candGet(id); if (!c) break; location.href = "sms:" + c.tel + "?&body=" + encodeURIComponent($("#cm-msg").value); break; }
    case "cm-copy": { const t = $("#cm-msg").value; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast("Message copié")).catch(() => { $("#cm-msg").select(); toast("Sélectionné : copie-le"); }); break; }
    case "cd-ics": { const c = candGet(id); const ics = c && candIcs(c); if (!ics) return toast("Pas de date de visite"); saveFile("visite-" + (c.nom || "candidat").replace(/\s+/g, "-") + ".ics", ics, "text/calendar"); break; }
    case "cd-keep": { const c = cdSave(id); if (!c) break; sheetKeep(id); break; }
    case "cd-keep-ok": { const c = candGet(id); if (!c) break; const num = i => { const x = parseNum($("#" + i).value); return x == null ? 0 : x; };
      const debut = dxV("kp-debut") || todayIso(), loyer = num("kp-loyer"), depot = num("kp-depot");
      if (loyer && depot > 2 * loyer + 0.005){ toast("Dépôt supérieur à 2 mois de loyer hors charges"); return; }
      const t = {id:uid(), bien:c.bien, nom:c.nom, tel:c.tel, email:c.email, debut, fin:"", loyer, charges:num("kp-chg"), depot, note:"Issu d'une candidature du " + frDate(c.dateDem || todayIso()), upd:Date.now()};
      S.locataires.push(t); c.statut = "ret"; c.loc = t.id; c.upd = Date.now();
      const an = annOf(c.bien); an.statut = "louee"; an.upd = Date.now(); S.annonces = S.annonces || {}; S.annonces[c.bien] = an;
      const r = mvtRec(c.bien, "arr"); r.done.dos = r.done.dos || todayIso(); r.upd = Date.now();
      persist(); closeSheet(); V.tab = "bld"; V.bsel = c.bien; V.bsub = "mvt"; render(); toast("Locataire créé : prépare maintenant l'arrivée"); break; }
    case "cd-del": openSheet(`<h2>Supprimer ce candidat ?</h2><p style="margin:0">La fiche et les pièces jointes sont effacées définitivement de cet appareil.${(candGet(id) || {}).statut === "ret" ? " Attention : ce candidat est devenu locataire, son dossier ne sera plus consultable dans sa fiche." : ""}</p><div class="btns"><button class="btn danger" data-act="cd-del-ok" data-id="${id}">Supprimer</button><button class="btn ghost" data-act="cd-open" data-id="${id}">Annuler</button></div>`); break;
    case "cd-del-ok": { await cdErase(id); persist(); closeSheet(); render(); break; }
    case "cd-purge": { const n = candList().filter(c => c.statut === "ref" && !c.del).length; openSheet(`<h2>Effacer les dossiers refusés ?</h2><p style="margin:0">${n} fiche(s) et leurs pièces jointes seront effacées définitivement de cet appareil.</p><div class="btns"><button class="btn danger" data-act="cd-purge-ok">Effacer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); break; }
    case "cd-purge-ok": { for (const c of candList().filter(c => c.statut === "ref" && !c.del)) await cdErase(c.id); persist(); closeSheet(); render(); break; }
    case "td-open": { const d = docList("docs").find(x => x.id === id); if (d) viewFile(id, d.fname || d.nom); break; }
    case "vw-open": viewFile(b.dataset.fid, b.dataset.name); break;
    case "vw-close": closeViewer(); break;
    case "vw-share": { const w = V.vw; if (w) saveFile(w.name, w.buf, w.type); break; }
    case "td-del": { const d = docList("docs").find(x => x.id === id); if (!d) break; openSheet(`<h2>Retirer ce document ?</h2><p style="margin:0">« ${esc(d.nom)} » sera retiré de l'appli. Ton original reste dans tes fichiers.</p><div class="btns"><button class="btn danger" data-act="td-del-ok" data-id="${id}" data-tid="${b.dataset.tid}">Retirer</button><button class="btn ghost" data-act="ledit" data-id="${b.dataset.tid}">Annuler</button></div>`); break; }
    case "td-del-ok": { const d = docList("docs").find(x => x.id === id); if (d){ d.del = true; d.upd = Date.now(); flDel(id); persist(); } sheetLoc(b.dataset.tid); break; }
    case "cf-open": { const c = candGet(id), f = c && (c.fichiers || []).find(x => x.fid === b.dataset.fid); if (f) viewFile(f.fid, f.nom); break; }
    case "cf-del": { const c = candGet(id); if (!c) break; c.fichiers = (c.fichiers || []).filter(x => x.fid !== b.dataset.fid); flDel(b.dataset.fid); c.upd = Date.now(); persist(); sheetCand(id); break; }
  }
});
async function cdErase(id){ const i = candList().findIndex(x => x.id === id); if (i < 0) return; const fs = candList()[i].fichiers || []; candList().splice(i, 1); for (const f of fs) await flDel(f.fid); }
document.addEventListener("change", async ev => {
  const t = ev.target; if (!t) return;
  if (t.dataset && t.dataset.pub){ const cur = annOf(V.lsel); cur.pub = cur.pub || {}; if (t.checked) cur.pub[t.dataset.pub] = todayIso(); else delete cur.pub[t.dataset.pub]; if (Object.keys(cur.pub).length && cur.statut === "brouillon") cur.statut = "publiee"; cur.upd = Date.now(); S.annonces = S.annonces || {}; S.annonces[V.lsel] = cur; persist(); render(); return; }
  if (t.id === "cm-tpl"){ const c = candGet(V.mailFor || ""); if (c){ const m = candMail(t.value, c); $("#cm-sub").value = m.s; $("#cm-msg").value = m.b; } return; }
  if (t.id === "an-doc" && t.files && t.files[0]){
    try { const f = t.files[0], txt = await docTextOf(f); if (!txt.trim()) throw new Error("aucun texte trouvé"); $("#an-perso").value = txt.trim(); toast("Texte importé : relis-le puis enregistre"); }
    catch(e){ toast("Import impossible : " + e.message); } t.value = ""; return; }
  if (t.id === "an-ph" && t.files && t.files.length){
    const cur = annOf(V.lsel); cur.photos = cur.photos || []; let n = 0;
    for (const f of t.files){ if (cur.photos.length >= ANN_MAX_PH){ toast("Maximum " + ANN_MAX_PH + " photos"); break; } try { const o = await annCompress(f), pid = uid(); await phPut(pid, o); cur.photos.push(pid); n++; } catch(e){ toast("Photo illisible : " + f.name); } }
    cur.upd = Date.now(); S.annonces = S.annonces || {}; S.annonces[V.lsel] = cur; persist(); render(); if (n) toast(n + " photo(s) ajoutée(s)"); return; }
  if (t.id === "cd-gar"){ document.querySelectorAll("label.cd-g").forEach(l => l.style.display = (t.value === "proche" || t.value === "autre") ? "flex" : "none"); return; }
  if (t.id === "td-file" && t.files && t.files.length){
    const tid = t.dataset.tid, tn = S.locataires.find(x => x.id === tid); if (!tn) return; const pt = ($("#td-type") || {}).value || "Autre"; let n = 0;
    for (const f of [...t.files]){ if (f.size > 25e6){ toast("Fichier trop gros (25 Mo maximum) : " + f.name); continue; }
      try { const buf = await f.arrayBuffer(), fid = uid(), type = f.type || mimeOf(f.name); await flPut(fid, {name:f.name, type, buf});
        docList("docs").push({id:fid, bien:tn.bien, kind:"loc", loc:tid, ptype:pt, nom:f.name, fname:f.name, date:todayIso(), type, size:f.size, upd:Date.now()}); n++; } catch(e){ toast("Fichier non enregistré (" + f.name + ") : " + (e && e.message || "erreur")); } }
    persist(); sheetLoc(tid); if (n) toast(n + " document(s) ajouté(s)"); return; }
  if (t.id === "cd-file" && t.files && t.files.length){
    const idc = (document.querySelector('[data-act="cd-save"]') || {dataset:{}}).dataset.id, c = candGet(idc); if (!c) return;
    const saved = cdSave(idc); if (!saved) return;
    const n = await candAttach(saved, [...t.files]);
    persist(); sheetCand(idc); toast(n === t.files.length ? n + " pièce(s) jointe(s)" : n + " sur " + t.files.length + " pièce(s) jointe(s)");
  }
});

/* ---------- Photos et PDF de l'annonce ---------- */
const ANN_MAX_PH = 12;
function annCompress(file){ return new Promise((res, rej) => { const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => { const k = Math.min(1, 1400 / Math.max(img.width, img.height)), c = document.createElement("canvas"); c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res({d:c.toDataURL("image/jpeg", 0.78), w:c.width, h:c.height}); };
  img.onerror = () => { URL.revokeObjectURL(url); rej(new Error("image")); }; img.src = url; }); }
const DPE_COL = {A:"#319834", B:"#33CC31", C:"#9FD62B", D:"#E5D800", E:"#FCB900", F:"#FC9935", G:"#E8302F"};
async function annoncePdf(bien){
  const a = annOf(bien), d = new PdfDoc("Annonce"), M = d.M, W = d.W - 2 * M, R = d.W - M, cc = (Number(a.loyer) || 0) + (Number(a.charges) || 0);
  d.clean = true; d.y = d.H - 52;
  const photos = []; for (const pid of a.photos || []){ const o = await phGet(pid); if (o) photos.push(o); }
  const title = a.titre || (a.type + (a.surf ? " de " + a.surf + " m²" : "") + (a.loc ? " – " + a.loc : ""));
  d.para(title, 21, 26); if (a.loc && a.titre){ d.text(M, d.y, a.loc, {size:11, color:"#5C6B66"}); d.y -= 18; } d.y -= 4;
  d.rect(M, d.y - 46, W, 46, "#E3F1EC"); d.text(M + 14, d.y - 30, eur(cc) + " / mois" + (Number(a.charges) ? " charges comprises" : ""), {size:19, bold:true, color:"#0E6B5C"});
  d.text(R - 12, d.y - 20, Number(a.charges) ? "dont " + eur(a.charges) + " de charges" : "hors charges", {size:9.5, right:true, color:"#3C4A45"}); d.text(R - 12, d.y - 34, "Dépôt de garantie : " + eur(a.depot), {size:9.5, right:true, color:"#3C4A45"}); d.y -= 62;
  const facts = [["Type", a.type || "Appartement"], ["Surface", a.surf ? a.surf + " m²" : ""], ["Disponible", a.dispo ? frDate(a.dispo) : "Immédiatement"], ["DPE", a.dpe || ""]].filter(f => f[1]), cw = W / facts.length;
  facts.forEach(([l, v], i) => { const x = M + i * cw; d.text(x, d.y, l.toUpperCase(), {size:7.5, bold:true, color:"#8A9690"});
    if (l === "DPE" && DPE_COL[v]){ d.rect(x, d.y - 24, 22, 18, DPE_COL[v]); d.text(x + 11, d.y - 19, v, {size:12, bold:true, center:true, color:"#FFFFFF"}); if (a.ges) d.text(x + 30, d.y - 19, "GES " + a.ges, {size:9.5, color:"#3C4A45"}); }
    else d.text(x, d.y - 17, String(v).slice(0, 26), {size:11, bold:true}); }); d.y -= 38;
  const own = a.perso && a.perso.trim();
  /* Hauteur du texte estimée d'avance : la photo principale prend la place qui reste, pour que le texte tienne sur la 1re page */
  const nLines = str => { let n = 1, line = ""; for (const w of String(str).split(" ")){ const t = line ? line + " " + w : w; if (pdfW(t, 11) > W){ n++; line = w; } else line = t; } return n; };
  let textH = 0; if (own) for (const par of own.split(/\r?\n/)) textH += par.trim() ? nLines(par.trim()) * 16 + 3 : 6; else textH = 330;
  if (photos[0]){ const o = photos[0], hmax = Math.max(150, Math.min(300, d.y - 62 - textH - 16)), k = Math.min(W / o.w, hmax / o.h), w = o.w * k, h = o.h * k; d.need(h + 20); d.image(M + (W - w) / 2, d.y - h, w, h, o); d.y -= h + 18; }
  if (own){ d.y -= 2; for (const par of own.split(/\r?\n/)){ if (!par.trim()){ d.y -= 6; continue; } d.para(par.trim(), 11, 16); d.y -= 3; } }
  const desc = own ? "" : ((a.equip && a.equip.trim()) || "");
  if (desc){ d.h("Description", 13); for (const par of desc.split(/\n+/)) d.para(par, 10.5, 15); }
  if (!own){
  d.h("Conditions", 13); d.para("Loyer : " + eur(a.loyer) + (Number(a.charges) ? " + " + eur(a.charges) + " de charges, soit " + eur(cc) + " charges comprises" : " par mois") + ".", 10.5, 15); d.para("Dépôt de garantie : " + eur(a.depot) + ".", 10.5, 15); if (a.dpe) d.para("Performance énergétique (DPE) : classe " + a.dpe + (a.ges ? " · GES : classe " + a.ges : "") + ".", 10.5, 15);
  d.h("Pour candidater", 13); d.para("Écrivez-moi" + (a.mail ? " à " + a.mail : "") + (a.tel ? " ou appelez le " + a.tel : "") + " en indiquant : votre nom, un numéro de téléphone, votre situation professionnelle, vos revenus mensuels, le nombre d'occupants, votre date d'emménagement souhaitée et, si vous en avez un, votre garant. Une visite vous sera proposée, puis les pièces justificatives vous seront demandées.", 10.5, 15);
  }
  /* Autres photos : grille régulière (cases de même taille, photo entière centrée), à la suite du texte */
  const more = photos.slice(1);
  if (more.length){ const gap = 10, cols = more.length === 1 ? 1 : more.length === 2 || more.length === 4 ? 2 : 3, cwp = (W - gap * (cols - 1)) / cols, ch = Math.min(cwp * 0.75, 230);
    d.need(ch + 50); d.y -= 6; d.text(M, d.y - 10, "Photos", {size:13, bold:true, color:"#0E6B5C"}); d.y -= 26;
    for (let i = 0; i < more.length; i += cols){ d.need(ch + gap);
      for (let j = 0; j < cols && i + j < more.length; j++){ const o = more[i + j], x = M + j * (cwp + gap), k = Math.min(cwp / o.w, ch / o.h), w = o.w * k, h = o.h * k;
        d.rect(x, d.y - ch, cwp, ch, "#F2F5F4"); d.image(x + (cwp - w) / 2, d.y - ch + (ch - h) / 2, w, h, o); }
      d.y -= ch + gap; }
  }
  return d.finish("Annonce");
}

/* ---------- Formulaire de candidature en ligne (page statique) et réception dans l'appli ---------- */
function candLink(bien, page, nom){
  const a = annOf(bien); if (!a.mail) return "";
  const u = new URL(page || "candidature.html", location.href); u.search = ""; u.hash = "";
  u.searchParams.set("m", a.mail); u.searchParams.set("r", bien); u.searchParams.set("t", a.titre || (a.type + (a.surf ? " " + a.surf + " m²" : "") + (a.loc ? " – " + a.loc : "")));
  if (nom) u.searchParams.set("n", nom);
  const cc = loyerCC(bien); if (cc && !page) u.searchParams.set("l", String(Math.round(cc))); return u.toString();
}
const dosLink = c => candLink(c.bien, "dossier.html", c.nom);
/* Pièces reçues par le formulaire « dossier » : le nom du fichier commence par le code de la case (id-1.jpg, gbul-2.pdf…) */
const DOS_CODES = {id:"id", dom:"dom", act:"act", bul:"res", imp:"res", res:"res", gid:"gid", gdom:"gdom", gact:"gact", gbul:"gres", gimp:"gres", gres:"gres"};
const DOS_LABEL = {id:"Pièce d'identité", dom:"Justificatif de domicile", act:"Contrat de travail / situation pro.", bul:"Bulletin de salaire", imp:"Avis d'imposition", res:"Justificatif de ressources", gid:"Garant : identité", gdom:"Garant : domicile", gact:"Garant : situation pro.", gbul:"Garant : bulletin de salaire", gimp:"Garant : avis d'imposition", gres:"Garant : ressources"};
const DOS_NOMS = [["gid","garant piece identite"],["gdom","garant justificatif domicile"],["gact","garant contrat de travail"],["gbul","garant bulletin de salaire"],["gimp","garant avis imposition"],["gres","garant autres ressources"],["id","piece identite"],["dom","justificatif domicile"],["act","contrat de travail"],["bul","bulletin de salaire"],["imp","avis imposition"],["res","autres ressources"]];
const dosCode = nom => {
  const n = String(nom || "").replace(/\.[A-Za-z0-9]{1,5}$/, "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
  const f = DOS_NOMS.find(x => n === x[1] || n.startsWith(x[1] + " ")); if (f) return f[0];
  const m = /^(g?(?:id|dom|act|bul|imp|res))-\d+\./i.exec(nom || ""); return m ? m[1].toLowerCase() : "";
};
function parseCandText(t){
  const nrm = x => x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
  const map = {nom:"nom", telephone:"tel", tel:"tel", "e-mail":"email", email:"email", mail:"email", situation:"contrat", "revenus mensuels nets":"rev", revenus:"rev", occupants:"occ", "emmenagement souhaite":"entree", garant:"garant", "revenus du garant":"grev", "pieces jointes":"pj", message:"message", "ref.":"ref", ref:"ref"};
  const o = {}; let cur = "";
  for (const ln of String(t || "").replace(/\r/g, "").split("\n")){
    const m = /^\s*([^:]{2,40}?)\s*:\s*(.*)$/.exec(ln), k = m && map[nrm(m[1])];
    if (k){ cur = k; o[k] = m[2].trim(); } else if (cur === "message" && ln.trim()) o.message += "\n" + ln.trim(); }
  return o.nom ? o : null;
}
function candFromParsed(o){
  const garant = /visale/i.test(o.garant || "") ? "visale" : /proche|parent/i.test(o.garant || "") ? "proche" : /autre/i.test(o.garant || "") ? "autre" : "";
  const ct = CAND_CONTRAT.find(x => x && x.toLowerCase() === (o.contrat || "").toLowerCase()) || (o.contrat ? "Autre" : "");
  let ent = (o.entree || "").trim(); const fr = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(ent); if (fr) ent = fr[3] + "-" + fr[2].padStart(2, "0") + "-" + fr[1].padStart(2, "0"); if (!/^\d{4}-\d{2}-\d{2}$/.test(ent)) ent = "";
  const ids = bienIds(), ref = ids.find(i => i.toLowerCase() === (o.ref || "").toLowerCase()) || V.lsel, num = x => { const v = parseNum(x || ""); return v == null ? "" : v; };
  const pj = o.pj && !/^aucune/i.test(o.pj) ? "Pièces annoncées : " + o.pj : "";
  return {id:uid(), bien:ref, nom:o.nom, tel:o.tel || "", email:o.email || "", statut:"dem", dateDem:todayIso(), contrat:ct, rev:num(o.rev), occ:(o.occ || "").replace(/\D/g, ""), entree:ent, garant, grev:num(o.grev), visite:"", note:[(o.message || "").trim(), pj, ct === "Autre" && o.contrat && o.contrat !== "Autre" ? "Situation indiquée : " + o.contrat : ""].filter(Boolean).join("\n"), pieces:{}, fichiers:[], src:"formulaire", upd:Date.now()};
}
function sheetPaste(){
  openSheet(`<h2>Coller une candidature reçue</h2><div class="info">Les formulaires (candidature ou dossier) envoient un e-mail à ton adresse. Pour une candidature : copie le texte (de « CANDIDATURE » au message) et colle-le ici. Pour un dossier : enregistre les pièces jointes dans Fichiers, puis choisis-les toutes ci-dessous avec dossier.txt.</div>
    <label class="f">Texte reçu<textarea id="cp-txt" style="min-height:220px" placeholder="CANDIDATURE – …&#10;Nom : …"></textarea></label>
    <div class="btns"><button class="btn ghost sm" data-act="cd-paste-read">Coller depuis le presse-papiers</button></div>
    <label class="f">Ou choisis les fichiers reçus (candidature.txt ou dossier.txt, et les pièces)<input id="cp-files" type="file" multiple accept=".txt,text/plain,.pdf,image/*"></label>
    <div class="small muted">Enregistre d'abord les pièces jointes de l'e-mail dans Fichiers, puis sélectionne-les toutes ici : le texte remplit la fiche, les autres fichiers y sont joints.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="cd-paste-ok">Créer la fiche</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}

function candCard(bien){
  const link = candLink(bien);
  return `<div class="card"><h2>Formulaire de candidature</h2>
    <div class="small muted">Quand quelqu'un te contacte, envoie-lui ce lien : il remplit ses informations et son e-mail t'arrive tout préparé. Tu colles ensuite le texte reçu ici et la fiche se remplit toute seule.</div>
    ${link ? `<label class="f">Lien à envoyer<input id="cd-link" readonly value="${esc(link)}"></label>
    <div class="btns"><button class="btn sm" data-act="cd-link-copy">Copier le lien</button><button class="btn sm ghost" data-act="cd-link-share">Partager le lien</button></div>` : '<div class="info" style="background:var(--warn-soft)">Indique d\'abord ton e-mail dans « Annonce › Modifier » : le formulaire envoie les candidatures à cette adresse.</div>'}
    <div class="small muted">Après la visite, le courrier « Demande du dossier » contient un 2e formulaire (une case par pièce : identité, domicile, contrat, bulletins, avis d'imposition, garant).</div>
    <div class="btns"><button class="btn sm ghost" data-act="cd-paste">Coller une candidature ou un dossier reçu</button></div></div>`;
}

async function candAttach(c, files){
  let n = 0; c.fichiers = c.fichiers || [];
  for (const f of files){ const fid = uid(); try { const buf = await f.arrayBuffer(); await flPut(fid, {name:f.name, type:f.type || (/\.pdf$/i.test(f.name) ? "application/pdf" : "application/octet-stream"), buf}); const dc = dosCode(f.name); c.fichiers.push({fid, nom:dc && /^[a-z]*g?(id|dom|act|bul|imp|res)-\d/i.test(f.name) ? DOS_LABEL[dc] + " (" + f.name + ")" : f.name, date:todayIso()}); if (dc){ c.pieces = c.pieces || {}; c.pieces[DOS_CODES[dc]] = c.pieces[DOS_CODES[dc]] || todayIso(); if (/^g/.test(dc) && !c.garant) c.garant = "proche"; } n++; } catch(e){ toast("Fichier non enregistré (" + f.name + ") : " + (e && e.message || "erreur")); } }
  if (n) c.upd = Date.now(); return n;
}

/* ---------- Dossier du locataire (repris de sa candidature) ---------- */
const TD_TYPES = ["Pièce d'identité", "Justificatif de domicile", "Contrat de travail", "Bulletin de salaire", "Avis d'imposition", "Bail / avenant", "Assurance habitation", "Autre"];
function tenantDocs(tid){
  const L = docList("docs").filter(x => x.kind === "loc" && x.loc === tid && !x.del).sort((a, b) => (a.ptype || "").localeCompare(b.ptype || "") || (a.nom || "").localeCompare(b.nom || ""));
  const rows = L.map(d => `<div class="row">${thumb(d.id, d.fname || d.nom, d.type)}<div class="main"><div class="t" style="font-size:13.5px">${esc(d.nom)}</div><div class="s">${esc(d.ptype || "Document")} · ${frDate(d.date)} · ${sizeStr(d.size || 0)}</div></div><button class="mini" data-act="td-open" data-id="${d.id}">Ouvrir</button><button class="mini" data-act="td-del" data-id="${d.id}" data-tid="${tid}" aria-label="Retirer">×</button></div>`).join("");
  return `<details open class="card" style="padding:12px;gap:6px;background:var(--bg)"><summary style="font-weight:700;font-size:15px;cursor:pointer">Documents du locataire · ${L.length}</summary>
    <div class="small muted">Choisis les fichiers dans Fichiers (iCloud Drive, Sur mon iPhone…) : l'appli en garde une copie, ouvrable d'un clic. Les documents restent sur cet appareil, non inclus dans la sauvegarde.</div>
    <div class="rows">${rows || '<div class="small muted">Aucun document.</div>'}</div>
    <label class="f">Type de pièce<select id="td-type">${TD_TYPES.map(x => `<option>${esc(x)}</option>`).join("")}</select></label>
    <label class="f">Ajouter des documents<input id="td-file" data-tid="${tid}" type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"></label></details>`;
}
function tenantDossier(tid){
  const c = candList().find(x => !x.del && x.loc === tid); if (!c) return tenantDocs(tid);
  const g = (CAND_GARANT.find(x => x[0] === (c.garant || "")) || [0, ""])[1], row = (l, v) => v ? `<div class="kv"><span>${esc(l)}</span><b>${esc(String(v))}</b></div>` : "";
  const pcs = CAND_PIECES.filter(p => c.pieces && c.pieces[p[0]]).map(p => `<div class="small">✓ ${esc(p[1])} · reçu le ${frDate(c.pieces[p[0]])}</div>`).join("");
  const fl = (c.fichiers || []).map(f => `<div class="row">${thumb(f.fid, f.nom)}<div class="main"><div class="t" style="font-size:13.5px">${esc(f.nom)}</div><div class="s">${frDate(f.date)}</div></div><button class="mini" data-act="cf-open" data-id="${c.id}" data-fid="${f.fid}">Ouvrir</button></div>`).join("");
  return `<details open class="card" style="padding:12px;gap:6px;background:var(--bg)"><summary style="font-weight:700;font-size:15px;cursor:pointer">Dossier de candidature · ${(c.fichiers || []).length} document(s)</summary>
    ${row("Demande du", c.dateDem ? frDate(c.dateDem) : "")}${row("Situation", c.contrat)}${row("Revenus nets / mois", c.rev ? eur(c.rev) : "")}${row("Occupants", c.occ)}${row("Emménagement souhaité", c.entree ? frDate(c.entree) : "")}${row("Garant", g && c.garant ? g : "")}${row("Revenus du garant", c.grev ? eur(c.grev) : "")}${row("Visite", c.visite ? fmtVisite(c.visite) : "")}
    ${c.note ? `<div class="small muted" style="white-space:pre-wrap">${esc(c.note)}</div>` : ""}
    <div class="small muted" style="margin-top:4px">Pièces reçues</div>${pcs || '<div class="small muted">Aucune pièce cochée</div>'}
    <div class="small muted" style="margin-top:4px">Documents (restent sur cet appareil, non inclus dans la sauvegarde)</div><div class="rows">${fl || '<div class="small muted">Aucun document</div>'}</div>
    <div class="btns"><button class="btn sm ghost" data-act="cd-open" data-id="${c.id}">Ouvrir la fiche candidat</button></div></details>` + tenantDocs(tid);
}

/* ---------- Miniatures et visionneuse (photos et PDF) ---------- */
const THUMB_IMG = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44"><rect width="44" height="44" rx="8" fill="#d8eee8"/><path d="M11 31l7-9 5 6 4-5 6 8z" fill="#0E6B5C" opacity=".55"/><circle cx="15" cy="15" r="3" fill="#0E6B5C" opacity=".55"/></svg>');
const THUMB_PDF = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44 44"><rect width="44" height="44" rx="8" fill="#f3d9d6"/><rect x="12" y="8" width="20" height="28" rx="3" fill="#fff"/><text x="22" y="26" font-size="9" font-weight="700" text-anchor="middle" fill="#b3261e" font-family="sans-serif">PDF</text></svg>');
const isPdfName = n => /\.pdf$/i.test(n || "");
const isImgName = n => /\.(jpe?g|png|gif|webp|heic|heif|bmp)$/i.test(n || "");
function thumb(fid, name, type){ const pdf = isPdfName(name) || type === "application/pdf", img = isImgName(name) || /^image\//.test(type || "");
  return `<img class="thumb" alt="" data-act="vw-open" data-fid="${fid}" data-name="${esc(name)}"${img ? ` data-thumb="${fid}"` : ""} src="${pdf ? THUMB_PDF : THUMB_IMG}">`; }
async function fillThumbs(){
  for (const im of document.querySelectorAll("img[data-thumb]")){ const fid = im.dataset.thumb; delete im.dataset.thumb;
    try { const r = await flGet(fid); if (r && r.buf && /^image\/(jpe?g|png|gif|webp|bmp)/.test(r.type || "")) im.src = URL.createObjectURL(new Blob([r.buf], {type:r.type})); } catch(e){} }
}
{ let tm = 0; new MutationObserver(() => { clearTimeout(tm); tm = setTimeout(fillThumbs, 60); }).observe(document.body, {childList:true, subtree:true}); }
function closeViewer(){ const v = document.getElementById("viewer"); if (v){ const m = v.querySelector("[data-blob]"); if (m) URL.revokeObjectURL(m.dataset.blob); v.remove(); } V.vw = null; }
async function viewFile(fid, name){
  const rec = await flGet(fid); if (!rec) return toast("Fichier introuvable sur cet appareil");
  const type = rec.type || mimeOf(name), isImg = /^image\//.test(type) && !/heic|heif/.test(type), isPdf = type === "application/pdf";
  if (!isImg && !isPdf) return saveFile(name || rec.name || "document", rec.buf, type);
  closeViewer(); V.vw = {name:name || rec.name || "document", buf:rec.buf, type};
  const url = URL.createObjectURL(new Blob([rec.buf], {type})), v = document.createElement("div"); v.id = "viewer";
  v.innerHTML = `<div class="vbar"><span class="vt">${esc(V.vw.name)}</span><button class="mini" data-act="vw-share">Partager</button><button class="mini" data-act="vw-close">Fermer</button></div>` +
    (isImg ? `<div class="vimg"><img data-blob="${url}" src="${url}" alt=""></div>` : `<iframe data-blob="${url}" src="${url}" title="${esc(V.vw.name)}"></iframe>`);
  document.body.appendChild(v);
}


/* ---------- Clôturer un locataire (départ) ---------- */
function sheetClot(tid){
  const t = S.locataires.find(x => x.id === tid); if (!t) return;
  const c = candList().find(x => !x.del && x.loc === tid), nd = docList("docs").filter(x => x.kind === "loc" && x.loc === tid && !x.del).length, nf = c ? (c.fichiers || []).length : 0;
  openSheet(`<h2>Clôturer · ${esc(t.nom)}</h2>
    <div class="small muted">À faire quand le locataire est parti (ou part). Cela : 1) enregistre la date de fin du bail, 2) coche les étapes « Retenues », « Dépôt restitué » et « Locataire clos » du départ (Biens › Arrivée/Départ), 3) calcule le dépôt à rendre. Tu peux annuler en rouvrant la fiche : rien n'est supprimé sans ta case cochée.</div>
    <label class="f">Date de fin du bail (départ)<input id="tc-fin" type="date" value="${esc(t.fin || todayIso())}"></label>
    <div class="kv"><span>Dépôt de garantie versé</span><b>${eur(t.depot || 0)}</b></div>
    <label class="f">Retenues justifiées (€) — dégradations, loyers impayés… avec devis ou factures<input id="tc-ret" inputmode="decimal" value="0"></label>
    <div class="kv"><span>Dépôt à restituer</span><b id="tc-rest" data-dep="${t.depot || 0}">${eur(t.depot || 0)}</b></div>
    <label style="display:flex;gap:10px;align-items:flex-start;font-size:14px"><input type="checkbox" id="tc-res"> Le dépôt a déjà été rendu (coche l'étape « Dépôt restitué »)</label>
    <label style="display:flex;gap:10px;align-items:flex-start;font-size:14px"><input type="checkbox" id="tc-op"> Préparer l'opération de remboursement dans le journal (tu vérifies la catégorie et tu enregistres : rien n'est écrit tout seul)</label>
    <label style="display:flex;gap:10px;align-items:flex-start;font-size:14px"><input type="checkbox" id="tc-erase"> Effacer le dossier de candidature et les documents de ce locataire (${nf + nd} fichier(s), définitif, de cet appareil seulement)</label>
    <div class="small muted">Conseil : garde le dossier tant que le dépôt n'est pas rendu et que le décompte final n'est pas accepté.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="tcl-ok" data-id="${tid}">Clôturer</button><button class="btn ghost" data-act="ledit" data-id="${tid}">Annuler</button></div>`);
}
document.addEventListener("input", ev => { const i = ev.target; if (!i || i.id !== "tc-ret") return; const o = document.getElementById("tc-rest"); if (!o) return;
  o.textContent = eur(Math.max(0, (+o.dataset.dep || 0) - (parseNum(i.value) || 0))); });
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, id = b.dataset.id;
  if (a === "tcl-open"){ sheetClot(id); return; }
  if (a !== "tcl-ok") return;
  const t = S.locataires.find(x => x.id === id); if (!t) return;
  const fin = document.getElementById("tc-fin").value; if (!fin) return toast("Indique la date de fin");
  const ret = Math.max(0, parseNum(document.getElementById("tc-ret").value) || 0), rest = Math.max(0, (t.depot || 0) - ret);
  const wRes = document.getElementById("tc-res").checked, wOp = document.getElementById("tc-op").checked, wEr = document.getElementById("tc-erase").checked;
  t.fin = fin; t.upd = Date.now();
  t.note = ((t.note ? t.note + " · " : "") + "Clôturé le " + frDate(todayIso()) + (t.depot ? " · dépôt " + eur(t.depot) + ", retenues " + eur(ret) + ", à restituer " + eur(rest) : "")).trim();
  const r = mvtRec(t.bien, "dep"), td = todayIso(); if (ret > 0) r.done.ret = r.done.ret || td; if (wRes) r.done.res = r.done.res || td; r.done.clo = td; r.upd = Date.now();
  if (wEr){ const c = candList().find(x => !x.del && x.loc === id); if (c) await cdErase(c.id);
    for (const d of docList("docs").filter(x => x.kind === "loc" && x.loc === id && !x.del)){ d.del = true; d.upd = Date.now(); await flDel(d.id); } }
  persist(); closeSheet();
  if (wOp && rest > 0){ V.back = V.tab; V.editId = null; V.draft = newDraft({type:"Dépense", bien:t.bien, cat:"Divers", lib:"Restitution dépôt de garantie - " + t.nom, mont:fmtNum(rest), montAuto:false, note:"Dépôt " + eur(t.depot || 0) + " moins retenues " + eur(ret)}); V.tab = "add"; render(); toast("Vérifie la catégorie puis enregistre"); return; }
  V.tab = "bld"; V.bsel = t.bien; V.bsub = "mvt"; render(); toast("Locataire clôturé : à restituer " + eur(rest));
});


/* ---------- Dossier rangé par locataire (ZIP) : Gestion locative / bien / Locataires / nom / ... ---------- */
async function locataireFiles(tid){
  const t = S.locataires.find(x => x.id === tid && !x.del); if (!t) return [];
  const root = "Gestion locative/" + cleanName(bienName(t.bien)) + "/Locataires/" + cleanName(t.nom), out = [], used = new Set();
  const mine = d => d.tid ? d.tid === tid : ((tenantFor(t.bien, d.date || todayIso()) || {}).id === tid);
  const add = (dir, name, data) => { let n = root + "/" + dir + "/" + cleanName(name), i = 2; const k = n.lastIndexOf(".");
    while (used.has(n)) n = (k < 0 ? n : n.slice(0, k)) + " (" + i++ + ")" + (k < 0 ? "" : n.slice(k)); used.add(n); out.push({name:n, data}); };
  const addFiles = async (kind, dir) => { for (const d of fileDocs(t.bien, kind).filter(mine)){ const r = await flGet(d.id); if (r) add(dir, d.date + " - " + (d.fname || d.nom), new Uint8Array(r.buf)); } };
  const enc = new TextEncoder(), fiche = ["FICHE LOCATAIRE", "Nom : " + t.nom, "Bien : " + bienName(t.bien), t.tel ? "Téléphone : " + t.tel : "", t.email ? "E-mail : " + t.email : "", "Début du bail : " + (t.debut ? frDate(t.debut) : ""), "Fin du bail : " + (t.fin ? frDate(t.fin) : ""), "Loyer charges comprises : " + eur(t.loyer || 0), "Dont charges : " + eur(t.charges || 0), "Dépôt de garantie : " + eur(t.depot || 0), t.note ? "Note : " + t.note : ""].filter(Boolean).join("\n");
  add("00 Fiche", "Fiche locataire.txt", enc.encode(fiche));
  await addFiles("bail", "01 Bail");
  for (const e of docList("edl").filter(x => x.bien === t.bien && !x.del && mine(x))){ if (e.fichier && !e.pieces.some(p => p.items.some(i => i.etat || i.com || (i.ph || []).length))) continue;
    add("02 États des lieux", e.date + " - État des lieux " + (e.type === "sortie" ? "sortie" : "entrée") + (e.sig ? " (signé)" : "") + ".pdf", await edlPdf(e)); }
  await addFiles("edl", "02 États des lieux");
  for (const e of docList("inv").filter(x => x.bien === t.bien && !x.del && mine(x))){ if (e.fichier && !e.items.some(i => i.etat || i.com)) continue;
    add("03 Inventaires", e.date + " - Inventaire " + (e.type === "sortie" ? "sortie" : "entrée") + (e.sig ? " (signé)" : "") + ".pdf", invPdf(e)); }
  await addFiles("inv", "03 Inventaires");
  for (const d of fileDocs(t.bien, "autre")){ const r = await flGet(d.id); if (r) add("06 Pièces à joindre au bail et autres documents", (d.sub ? annexLabel(d.sub) + " - " : "") + (d.fname || d.nom), new Uint8Array(r.buf)); }
  const c = candList().find(x => !x.del && x.loc === tid);
  if (c) for (const f of (c.fichiers || [])){ const r = await flGet(f.fid); if (r) add("04 Dossier de candidature", f.nom, new Uint8Array(r.buf)); }
  for (const d of docList("docs").filter(x => x.kind === "loc" && x.loc === tid && !x.del)){ const r = await flGet(d.id); if (r) add("05 Documents du locataire", (d.ptype ? d.ptype + " - " : "") + (d.fname || d.nom), new Uint8Array(r.buf)); }
  return out;
}
async function exportLocataires(ids, nom){
  toast("Préparation du dossier…"); let files = []; for (const id of ids) files = files.concat(await locataireFiles(id));
  if (files.length <= ids.length) return toast("Rien à ranger pour l'instant");
  await saveFile(nom + ".zip", zipStore(files), "application/zip");
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  if (b.dataset.act === "zip-loc"){ const t = S.locataires.find(x => x.id === b.dataset.id); if (t) await exportLocataires([t.id], "Gestion locative - " + cleanName(t.nom)); }
  if (b.dataset.act === "zip-loc-all") await exportLocataires(live(S.locataires).map(x => x.id), "Gestion locative");
});


/* ---------- Sauvegarde complète avec fichiers (ZIP) et restauration ---------- */
function zipRead(buf){
  const u = new Uint8Array(buf), dv = new DataView(buf); let e = -1;
  for (let i = u.length - 22; i >= Math.max(0, u.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50){ e = i; break; }
  if (e < 0) throw new Error("ZIP illisible");
  const n = dv.getUint16(e + 10, true), dec = new TextDecoder(), out = []; let p = dv.getUint32(e + 16, true);
  for (let k = 0; k < n; k++){
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("ZIP abîmé");
    const meth = dv.getUint16(p + 10, true), size = dv.getUint32(p + 24, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true), name = dec.decode(u.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + el + cl; if (name.endsWith("/")) continue;
    if (meth !== 0) throw new Error("ZIP recompressé : utilise le ZIP créé par l'appli, tel quel");
    const s = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true); out.push({name, data:u.subarray(s, s + size)}); }
  return out;
}
async function exportFullZip(){
  toast("Préparation de la sauvegarde…");
  const db = PH.db || await phOpen(), enc = new TextEncoder(), files = [], ents = [];
  const all = db ? await new Promise(res => { try { const tx = db.transaction("p"), st = tx.objectStore("p"), ks = st.getAllKeys(), vs = st.getAll(); tx.oncomplete = () => res([ks.result, vs.result]); tx.onerror = tx.onabort = () => res([[], []]); } catch(e){ res([[], []]); } }) : [[], []];
  all[0].forEach((key, n) => { const v = all[1][n]; if (v == null) return;
    if (v.buf instanceof ArrayBuffer){ const meta = Object.assign({}, v); delete meta.buf; const fn = "fichiers/" + n + " - " + cleanName(meta.name || "fichier"); ents.push({n, key, bin:true, meta, file:fn}); files.push({name:fn, data:new Uint8Array(v.buf)}); }
    else { ents.push({n, key, bin:false}); files.push({name:"fichiers/" + n + ".json", data:enc.encode(JSON.stringify(v))}); } });
  files.unshift({name:"LISEZ-MOI.txt", data:enc.encode("Sauvegarde complète de l'appli Gestion Locative Facile (" + todayIso() + ").\r\n- donnees.json : toutes les données de l'appli.\r\n- fichiers/ : tes documents et photos (les fichiers portent leur nom d'origine, précédé d'un numéro). Tu peux les ouvrir sur ordinateur.\r\nPour tout remettre dans l'appli : importe ce .zip tel quel (sans le décompresser) dans Réglages › Synchroniser.\r\nCe dossier contient des papiers personnels : garde-le dans un endroit privé.")});
  files.unshift({name:"manifest.json", data:enc.encode(JSON.stringify({v:1, date:todayIso(), entries:ents}))});
  files.unshift({name:"donnees.json", data:enc.encode(JSON.stringify(S))});
  await saveFile("mes-locations-sauvegarde-complete.zip", zipStore(files), "application/zip");
}
async function restoreFull(files){
  const dec = new TextDecoder(), man = files.find(f => f.name === "manifest.json"); if (!man) return 0;
  const m = JSON.parse(dec.decode(man.data)), by = new Map(files.map(f => [f.name, f.data])), db = PH.db || await phOpen(); if (!db) throw new Error("stockage indisponible"); let n = 0;
  await new Promise((res, rej) => { const tx = db.transaction("p", "readwrite"), st = tx.objectStore("p");
    for (const e of m.entries){ if (e.bin){ const d = by.get(e.file || ("fichiers/" + e.n + ".bin")); if (d){ st.put(Object.assign({}, e.meta, {buf:d.slice().buffer}), e.key); n++; } }
      else { const d = by.get("fichiers/" + e.n + ".json"); if (d){ st.put(JSON.parse(dec.decode(d)), e.key); n++; } } }
    tx.oncomplete = res; tx.onerror = tx.onabort = () => rej(tx.error || new Error("écriture impossible")); });
  PH.cache = {}; return n;
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  if (b.dataset.act === "exp-zip"){ if (S.demo) toast("Attention : ce sont des données d'exemple"); try { await exportFullZip(); } catch(e){ toast("Sauvegarde impossible : " + e.message); } }
});


/* ---------- Remettre un « ZIP rangé » dans les fiches des locataires ---------- */
async function restoreDossiers(files){
  let n = 0, skip = 0; const nolo = new Set(), dec = f => f.name.split("/");
  for (const f of files){
    const [, bn, , ln, dir, fn] = dec(f), b = live(S.biens).find(x => cleanName(bienName(x.id)) === bn), t = b && live(S.locataires).find(x => x.bien === b.id && cleanName(x.nom) === ln);
    if (!t){ nolo.add(ln); continue; }
    const m = /^(\d{4}-\d{2}-\d{2}) - (.+)$/.exec(fn), date = m ? m[1] : todayIso(), name = m ? m[2] : fn, kind = {"01 Bail":"bail", "02 États des lieux":"edl", "03 Inventaires":"inv", "06 Pièces à joindre au bail et autres documents":"autre"}[dir];
    let ptype = "", nom = fn;
    if (dir === "04 Dossier de candidature"){ ptype = "Dossier de candidature"; nom = fn; }
    else if (dir === "05 Documents du locataire"){ const k = fn.indexOf(" - "); if (k > 0){ ptype = fn.slice(0, k); nom = fn.slice(k + 3); } else ptype = "Autre"; }
    const L = docList("docs"), size = f.data.length;
    if (L.some(d => !d.del && d.bien === b.id && (d.loc || "") === (ptype ? t.id : "") && (d.fname || d.nom) === (ptype ? nom : name) && d.size === size)){ skip++; continue; }
    const fid = uid(), type = mimeOf(ptype ? nom : name);
    await flPut(fid, {name:ptype ? nom : name, type, buf:f.data.slice().buffer});
    L.push(Object.assign({id:fid, bien:b.id, kind:ptype ? "loc" : (kind || "autre"), nom:ptype ? nom : name, fname:ptype ? nom : name, date, type, size, upd:Date.now()}, ptype ? {loc:t.id, ptype} : {}));
    n++; }
  return {n, skip, nolo:[...nolo]};
}


/* ---------- Texte d'un fichier Word (.docx) ou texte (.txt) ---------- */
async function docTextOf(f){
  const buf = await f.arrayBuffer(), u = new Uint8Array(buf);
  if (!(u[0] === 0x50 && u[1] === 0x4b)) return new TextDecoder("utf-8").decode(u).replace(/^\uFEFF/, "");
  const dv = new DataView(buf); let e = -1; for (let i = u.length - 22; i >= Math.max(0, u.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50){ e = i; break; }
  if (e < 0) throw new Error("fichier Word illisible");
  const n = dv.getUint16(e + 10, true), dec = new TextDecoder(); let p = dv.getUint32(e + 16, true);
  for (let k = 0; k < n; k++){
    const meth = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true), name = dec.decode(u.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + el + cl; if (name !== "word/document.xml") continue;
    const s0 = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true); let raw = u.subarray(s0, s0 + csz);
    if (meth === 8){ if (typeof DecompressionStream === "undefined") throw new Error("ce navigateur ne sait pas lire le Word : colle le texte à la main"); raw = new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer()); }
    const xml = dec.decode(raw), un = x => x.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
    return (xml.match(/<w:p[ >][\s\S]*?<\/w:p>/g) || []).map(par => un(par.replace(/<w:tab\/>/g, "\t").replace(/<w:br\/>/g, "\n").replace(/<(?!\/?w:t[ >])[^>]*>/g, "").replace(/<[^>]*>/g, ""))).join("\n").replace(/\n{3,}/g, "\n\n");
  }
  throw new Error("texte introuvable dans ce fichier");
}
