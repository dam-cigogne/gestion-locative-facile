/* ============ Documents : PDF (état des lieux, inventaire), bail meublé, lettres ============ */
const bailleurInfo = () => ({nom:(S.cfg && S.cfg.bailleur) || "", adr:(S.cfg && S.cfg.bailleurAdr) || ""});
const MENT_EDL = "État des lieux établi contradictoirement et signé des deux parties, remis à chacune. Le locataire dispose de 10 jours à compter de sa réalisation pour demander au bailleur de compléter l'état des lieux d'entrée, et, pour les éléments de chauffage, durant le premier mois de la période de chauffe (article 3-2 de la loi n° 89-462 du 6 juillet 1989). Si l'état des lieux de sortie ne peut être établi contradictoirement, il l'est par commissaire de justice, à frais partagés.";
let RELECT = false;
function titleBlock(d, titre, sous){ if (RELECT){ d.text(d.W / 2, d.y, "PROJET À RELIRE : NON SIGNÉ, SANS VALEUR CONTRACTUELLE", {size:9.5, bold:true, center:true, color:"#B3261E"}); d.y -= 28; } d.text(d.W / 2, d.y, titre, {size:19, bold:true, center:true, color:"#0E6B5C"}); d.y -= 22; if (sous){ d.text(d.W / 2, d.y, sous, {size:10, center:true, color:"#5C6B66"}); d.y -= 22; } }
function partiesBlock(d, e){
  const bi = bailleurInfo(), M = d.M;
  const bloc = (t, l) => { d.need(50); d.text(M, d.y, t, {size:9.5, bold:true, color:"#5C6B66"}); d.y -= 14; l.filter(Boolean).forEach(x => { d.text(M, d.y, x, {size:10.5}); d.y -= 14; }); d.y -= 6; };
  bloc("BAILLEUR", [bi.nom || "(à renseigner : Réglages ou quittance)", bi.adr]); bloc("LOCATAIRE", [e.loc || "(non précisé)"]); bloc("LOGEMENT", [bienName(e.bien), bienAdr(e.bien)]);
}
async function edlPdf(e){
  const sortie = e.type === "sortie", d = new PdfDoc(sortie ? "État des lieux de sortie" : "État des lieux d'entrée"), M = d.M, tw = d.W - 2 * M, ref = sortie && e.ref ? docGet("edl", e.ref) : null, diffs = [];
  titleBlock(d, sortie ? "ÉTAT DES LIEUX DE SORTIE" : "ÉTAT DES LIEUX D'ENTRÉE", "Établi contradictoirement le " + frDate(e.date)); partiesBlock(d, e);
  const rel = [["Électricité (index)", e.elec, ref && ref.elec], ["Eau (index)", e.eau, ref && ref.eau], ["Gaz (index)", e.gaz, ref && ref.gaz], ["Clés remises (nombre)", e.cles, ref && ref.cles], ["Détecteur de fumée", e.fumee, ref && ref.fumee]];
  if (ref) dTable(d, [{h:"Compteurs et équipements", w:190}, {h:"À l'entrée", w:150}, {h:"À la sortie", w:tw - 340}], rel.map(r => [r[0], r[2] || "—", r[1] || "—"]));
  else dTable(d, [{h:"Compteurs et équipements", w:230}, {h:"Relevé", w:tw - 230}], rel.map(r => [r[0], r[1] || "—"]));
  for (const p of e.pieces){
    d.need(60); d.h(p.nom, 12);
    if (sortie) dTable(d, [{h:"Élément", w:135}, {h:"Entrée", w:70}, {h:"Sortie", w:70}, {h:"Observations", w:tw - 275}],
      p.items.map(i => { const worse = i.etat && i.e0 && RANK[i.etat] > RANK[i.e0]; if (worse) diffs.push([p.nom, i.nom, i.e0, i.etat, i.com]);
        return {cells:[i.nom, i.e0 || "—", i.etat || "—", [i.c0 ? "Entrée : " + i.c0 : "", i.com ? "Sortie : " + i.com : ""].filter(Boolean).join("\n")], fill:worse ? "#FBE9E7" : null}; }));
    else dTable(d, [{h:"Élément", w:170}, {h:"État", w:70}, {h:"Observations", w:tw - 240}], p.items.map(i => [i.nom, i.etat || "—", i.com || ""]));
    for (const i of p.items) if ((i.ph || []).length) await pdfPhotos(d, i.ph, "Photos · " + p.nom + " · " + i.nom);
  }
  if (sortie){ d.h("Différences constatées", 12);
    if (diffs.length) dTable(d, [{h:"Pièce", w:110}, {h:"Élément", w:150}, {h:"Entrée", w:60}, {h:"Sortie", w:60}, {h:"Observation", w:tw - 380}], diffs.map(x => [x[0], x[1], x[2], x[3], x[4] || ""]));
    else d.para("Aucune dégradation constatée par rapport à l'état d'entrée.", 10, 14);
    d.para("Les éventuelles retenues sur le dépôt de garantie doivent être justifiées (devis, factures) et tenir compte de la vétusté.", 9, 12); }
  if (e.rem){ d.h("Remarques générales", 12); d.para(e.rem, 10, 14); }
  d.y -= 6; d.para(MENT_EDL, 8.5, 11.5); sigBlock(d, (S.cfg && S.cfg.ville) || "", e.date, e.sig); if (e.sig) proofPage(d, e.sig, (sortie ? "État des lieux de sortie" : "État des lieux d'entrée") + " · " + bienName(e.bien) + " · " + frDate(e.date));
  return d.finish(sortie ? "État des lieux de sortie" : "État des lieux d'entrée");
}
function invPdf(e){
  const sortie = e.type === "sortie", d = new PdfDoc("Inventaire du mobilier"), tw = d.W - 2 * d.M;
  titleBlock(d, sortie ? "INVENTAIRE DU MOBILIER · SORTIE" : "INVENTAIRE DU MOBILIER · ENTRÉE", "Annexe au contrat de location meublée · établi le " + frDate(e.date)); partiesBlock(d, e);
  for (const g of [...new Set(e.items.map(i => i.grp || "Autres"))]){
    d.need(60); d.h(g, 12); const L = e.items.filter(i => (i.grp || "Autres") === g);
    if (sortie) dTable(d, [{h:"Désignation", w:170}, {h:"Qté entrée", w:55}, {h:"État entrée", w:65}, {h:"Qté sortie", w:55}, {h:"État sortie", w:65}, {h:"Observations", w:tw - 410}],
      L.map(i => { const worse = (i.etat && i.e0 && RANK[i.etat] > RANK[i.e0]) || (i.qte && i.q0 && +i.qte < +i.q0); return {cells:[i.nom, i.q0 || "—", i.e0 || "—", i.qte || "—", i.etat || "—", i.com || ""], fill:worse ? "#FBE9E7" : null}; }));
    else dTable(d, [{h:"Désignation", w:240}, {h:"Qté", w:40}, {h:"État", w:70}, {h:"Observations", w:tw - 350}], L.map(i => [i.nom, i.qte || "1", i.etat || "—", i.com || ""]));
  }
  if (e.rem){ d.h("Remarques générales", 12); d.para(e.rem, 10, 14); }
  d.y -= 6; d.para("Inventaire et état du mobilier établis contradictoirement et signés des deux parties (article 25-5 de la loi du 6 juillet 1989). Une copie est remise à chacune, en annexe du contrat de location.", 8.5, 11.5);
  sigBlock(d, (S.cfg && S.cfg.ville) || "", e.date, e.sig); if (e.sig) proofPage(d, e.sig, (sortie ? "Inventaire du mobilier de sortie" : "Inventaire du mobilier d'entrée") + " · " + bienName(e.bien) + " · " + frDate(e.date)); return d.finish("Inventaire du mobilier");
}

/* ---------- Bail meublé ---------- */
const endBail = (debut, mois) => { const x = new Date(debut + "T12:00:00Z"); x.setUTCMonth(x.getUTCMonth() + mois); x.setUTCDate(x.getUTCDate() - 1); return x.toISOString().slice(0, 10); };
const optSel = (id, label, list, val) => dxS(id, label, list.map(x => [x, x]), val);
function sheetBail(){
  const id = V.bsel, t = tenantFor(id, todayIso()) || {}, de = bienDesc(id), c = bailleurInfo(), lhc = t.loyer ? r2(N(t.loyer) - N(t.charges)) : "";
  openSheet(`<h2>${bkind(id) === "vide" ? "Bail logement vide" : "Bail meublé"} · ${esc(bienName(id))}</h2><div class="info">Contrat de location ${bkind(id) === "vide" ? "non meublée" : "meublée"}, résidence principale, établi d'après le contrat type du décret n° 2015-587. Relis chaque champ avant de le faire signer.</div>
    ${dxF("bl-bail", "Bailleur (nom, prénom)", c.nom)}${dxF("bl-badr", "Adresse du bailleur", c.adr)}${dxF("bl-loc", "Locataire (nom, prénom)", t.nom || "")}${dxF("bl-adr", "Adresse du logement", bienAdr(id))}
    <div class="grid2">${dxF("bl-type", "Nature du logement", de.type || "Appartement")}${dxF("bl-surf", "Surface habitable (m²)", de.surface || "", 'inputmode="decimal"')}</div>
    <div class="grid2">${dxF("bl-etage", "Étage / lot", de.etage || "")}${dxF("bl-pieces", "Pièces principales", de.pieces || "", 'inputmode="numeric"')}</div>
    <div class="grid2">${optSel("bl-copro", "Copropriété", ["Oui", "Non"], de.copro || "Oui")}${optSel("bl-dpe", "Classe DPE", ["A", "B", "C", "D", "E", "F", "G", "À renseigner"], de.dpe || "À renseigner")}</div>
    ${dxF("bl-chauf", "Chauffage", de.chauffage || "Individuel électrique")}${dxF("bl-eau", "Production d'eau chaude", de.eauch || "Individuelle électrique")}${dxF("bl-annex", "Dépendances (cave, parking, etc.)", de.annexes || "Aucune")}
    <div class="grid2">${dxS("bl-duree", "Durée", bkind(id) === "vide" ? [["36", "3 ans (reconductible)"]] : [["12", "1 an (reconductible)"], ["9", "9 mois (étudiant)"]], bkind(id) === "vide" ? "36" : "12")}${dxF("bl-debut", "Date de prise d'effet", t.debut || todayIso(), 'type="date"')}</div>
    <div class="grid2">${dxF("bl-lhc", "Loyer hors charges (€)", fmtNum(lhc), 'inputmode="decimal"')}${dxF("bl-chg", "Charges (€/mois)", fmtNum(t.charges || ""), 'inputmode="decimal"')}</div>
    <div class="grid2">${dxS("bl-regchg", "Charges", [["prov", "Provisions, avec régularisation"], ["forf", "Forfait"]], "prov")}${dxF("bl-jour", "Loyer payable le (jour)", "5", 'inputmode="numeric"')}</div>
    ${dxF("bl-dep", "Dépôt de garantie (€, " + (bkind(id) === "vide" ? "1 mois" : "2 mois") + " maximum)", fmtNum(t.depot || ""), 'inputmode="decimal"')}
    ${dxF("bl-irl", "Indice IRL de référence (trimestre et valeur)", "", 'placeholder="Ex. 2e trimestre 2026 : 146,68"')}
    <div class="grid2">${dxS("bl-enc", "Loyers encadrés", [["Non", "Non"], ["Oui", "Oui"]], "Non")}${dxS("bl-tendue", "Zone tendue", [["Non", "Non"], ["Oui", "Oui"]], "Non")}</div>
    ${dxF("bl-encinfo", "Si encadré ou zone tendue : loyer de référence, majoré, complément, loyer du précédent locataire", "", 'placeholder="À reprendre sur le site officiel de ta ville"')}
    <div class="grid2">${dxF("bl-bmob", "Mobile bailleur (facultatif)", "", 'inputmode="tel"')}${dxF("bl-lmob", "Mobile locataire (facultatif)", t.tel || "", 'inputmode="tel"')}</div>
    <div class="small muted">Baux signés à partir du 1er octobre 2026 : nouvelle clause résolutoire (décret n° 2026-596). Clauses facultatives :</div>
    <div class="grid2">${dxS("bl-assclause", "Défaut d'assurance", [["Non", "Non"], ["Oui", "Oui"]], "Non")}${dxS("bl-trouble", "Troubles de voisinage", [["Non", "Non"], ["Oui", "Oui"]], "Non")}</div>
    ${dxS("bl-servit", "Servitude de résidence principale (secteur du PLU)", [["Non", "Non"], ["Oui", "Oui"]], "Non")}
    ${dxF("bl-ville", "Fait à", (S.cfg && S.cfg.ville) || "")}
    <div class="btns"><button class="btn ghost" style="flex:1" data-act="bail-rel">PDF de relecture</button></div><div class="btns"><button class="btn" style="flex:1" data-act="bail-pdf">Créer le bail (PDF)</button><button class="btn" style="flex:1" data-act="bail-sign">Faire signer à l'écran</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function bailRead(){ const o = {}; for (const k of ["bail", "badr", "loc", "adr", "type", "surf", "etage", "pieces", "copro", "dpe", "chauf", "eau", "annex", "duree", "debut", "regchg", "jour", "irl", "enc", "tendue", "encinfo", "ville", "bmob", "lmob", "assclause", "trouble", "servit"]) o[k] = dxV("bl-" + k);
  o.lhc = parseNum(dxV("bl-lhc")) || 0; o.chg = parseNum(dxV("bl-chg")) || 0; o.dep = parseNum(dxV("bl-dep")) || 0; return o; }
function bailPdf(o, sig){
  const VIDE = bkind(V.bsel) === "vide", d = new PdfDoc(VIDE ? "Bail logement vide" : "Bail meublé"), M = d.M, P = (s, sz) => d.para(s, sz || 10, 13.5), Hh = s => d.h(s, 11.5), mois = +o.duree, fin = endBail(o.debut, mois), tot = r2(o.lhc + o.chg);
  titleBlock(d, VIDE ? "CONTRAT DE LOCATION" : "CONTRAT DE LOCATION MEUBLÉE", VIDE ? "Logement non meublé · résidence principale du locataire · titre Ier de la loi n° 89-462 du 6 juillet 1989" : "Résidence principale du locataire · titre Ier bis de la loi n° 89-462 du 6 juillet 1989");
  d.para("Contrat établi d'après le contrat type annexé au décret n° 2015-587 du 29 mai 2015" + (o.debut >= "2026-10-01" ? ", modifié par le décret n° 2026-596 du 6 juillet 2026 (baux conclus ou renouvelés à compter du 1er octobre 2026)" : "") + ". À relire avant signature ; ce document ne remplace pas un conseil juridique.", 8.5, 11.5); d.y -= 4;
  Hh("1. Désignation des parties");
  P("Le bailleur : " + (o.bail || "………") + ", demeurant " + (o.badr || "………") + (o.bmob ? ", mobile " + o.bmob : "") + ", désigné « le bailleur ».");
  P("Le locataire : " + (o.loc || "………") + (o.lmob ? ", mobile " + o.lmob : "") + ", désigné « le locataire ». S'ils sont plusieurs, les locataires sont tenus solidairement et indivisiblement.");
  Hh("2. Objet du contrat");
  P("Le bailleur loue au locataire le logement suivant, situé " + (o.adr || "………") + " : " + (o.type || "logement") + (o.etage ? ", " + o.etage : "") + ", d'une surface habitable de " + (o.surf || "…") + " m², comprenant " + (o.pieces || "…") + " pièce(s) principale(s). Immeuble en copropriété : " + o.copro.toLowerCase() + ". Dépendances et annexes : " + (o.annex || "aucune") + ".");
  P("Équipements : chauffage " + (o.chauf || "………") + " ; eau chaude " + (o.eau || "………") + ". " + (VIDE ? "Le logement est loué non meublé." : "Le logement est loué meublé : le mobilier est décrit dans l'inventaire et l'état du mobilier annexés au présent contrat.") + "");
  P("Destination : le logement est loué à usage exclusif d'habitation, comme résidence principale du locataire. Performance énergétique : classe " + o.dpe + " (diagnostic de performance énergétique annexé).");
  Hh("3. Date de prise d'effet et durée");
  P("Le contrat prend effet le " + frDate(o.debut) + " pour une durée de " + (VIDE ? "trois ans, jusqu'au " : mois === 9 ? "neuf mois, sans reconduction tacite (bail étudiant), jusqu'au " : "un an, jusqu'au ") + frDate(fin) + (mois === 9 ? "." : VIDE ? ". Il est reconduit tacitement pour une durée de trois ans, sauf congé donné dans les conditions ci-dessous." : ". Il est reconduit tacitement pour une durée d'un an, sauf congé donné dans les conditions ci-dessous."));
  P("Congé du locataire : à tout moment, avec un préavis de " + (VIDE ? "trois mois (réduit à un mois en zone tendue et dans les cas prévus par la loi : mutation, perte d'emploi, raison de santé, etc.)" : "d'un mois") + ". Congé du bailleur : au moins " + (VIDE ? "six mois" : "trois mois") + " avant l'échéance du contrat, uniquement pour reprendre le logement, le vendre ou pour un motif légitime et sérieux. Le congé est notifié par lettre recommandée avec accusé de réception, par acte de commissaire de justice ou remis en main propre contre émargement ou récépissé.");
  Hh("4. Conditions financières");
  P("Loyer mensuel hors charges : " + eur(o.lhc) + " (" + montantLettres(o.lhc) + "). " + (o.chg <= 0 ? "Aucune charge n'est facturée en sus du loyer." : o.regchg === "forf" ? "Charges : forfait mensuel de " + eur(o.chg) + ", non régularisable." : "Charges : provision mensuelle de " + eur(o.chg) + ", régularisée une fois par an sur justificatifs que le bailleur tient à disposition du locataire.") + (o.chg > 0 ? " Total mensuel : " + eur(tot) + "." : ""));
  P("Le loyer et les charges sont payables mensuellement et à terme à échoir, le " + (o.jour || "5") + " de chaque mois, par virement bancaire. Le bailleur remet gratuitement une quittance sur demande du locataire.");
  P("Révision : le loyer est révisé une fois par an, à la date anniversaire du contrat, selon la variation de l'indice de référence des loyers (IRL) publié par l'INSEE. Indice de référence : " + (o.irl || "………") + ".");
  P("Loyers encadrés : " + o.enc + ". Zone tendue : " + o.tendue + "." + (o.encinfo ? " " + o.encinfo : ""));
  P("Dépôt de garantie : " + eur(o.dep) + " (" + montantLettres(o.dep) + "), versé à la signature, sans intérêts. Il est restitué dans un délai maximal d'un mois à compter de la remise des clés si l'état des lieux de sortie est conforme à l'état des lieux d'entrée, de deux mois dans le cas contraire, déduction faite des sommes justifiées dues au bailleur. Tout retard donne lieu à une majoration de 10 % du loyer mensuel hors charges par mois commencé de retard.");
  Hh("5. Obligations des parties");
  P("Le bailleur remet un logement décent et en bon état d'usage, assure au locataire la jouissance paisible du logement, entretient les locaux en état de servir à l'usage prévu et effectue les réparations autres que locatives.");
  P("Le locataire paie le loyer et les charges aux termes convenus, use paisiblement du logement, répond des dégradations et pertes survenues pendant le contrat, prend en charge l'entretien courant et les menues réparations, et ne transforme pas les lieux sans accord écrit du bailleur. Il ne sous-loue pas sans l'accord écrit du bailleur. Il s'assure contre les risques locatifs et en remet l'attestation à la remise des clés, puis chaque année à la demande du bailleur.");
  Hh("6. Clause résolutoire");
  if (o.debut >= "2026-10-01"){
    P("Le contrat est résilié de plein droit en cas de défaut de paiement du loyer ou des charges aux termes convenus, ou de non-versement du dépôt de garantie. Cet effet n'intervient que six semaines après un commandement de payer demeuré infructueux, délivré par commissaire de justice dans les conditions de l'article 24 de la loi du 6 juillet 1989. Le commandement reproduit les mentions exigées par la loi, notamment la possibilité de saisir le fonds de solidarité pour le logement et de demander des délais de paiement. L'expulsion reste subordonnée à une décision de justice.");
    if (o.assclause === "Oui") P("Clause facultative : à défaut de justification d'une assurance des risques locatifs, le contrat est résilié de plein droit un mois après un commandement demeuré infructueux.");
    if (o.trouble === "Oui") P("Clause facultative : le contrat est résilié de plein droit en cas de troubles de voisinage constatés par une décision de justice passée en force de chose jugée.");
    if (o.servit === "Oui") P("Servitude de résidence principale : le logement est situé dans un secteur délimité par le plan local d'urbanisme où il est affecté à l'usage exclusif de résidence principale. Le non-respect de cette obligation, constaté après mise en demeure du maire, peut entraîner la résiliation du contrat.");
  } else P("Le contrat est résilié de plein droit, dans les conditions et délais prévus à l'article 24 de la loi du 6 juillet 1989, en cas de défaut de paiement du loyer ou des charges aux termes convenus, de non-versement du dépôt de garantie ou de défaut d'assurance, après un commandement demeuré infructueux.");
  Hh("7. Honoraires");
  P("Location conclue directement entre les parties : aucun honoraire de location n'est dû.");
  Hh("8. Annexes remises au locataire");
  const bx = ok => ok ? "[ X ]" : "[    ]", bn = V.bsel, has = k => docList(k).some(x => x.bien === bn && !x.del && x.type === "entree");
  P((VIDE ? "" : bx(has("inv")) + " Inventaire et état du mobilier        ") + bx(has("edl")) + " État des lieux d'entrée");
  P(bx(annexHas(bn, "diag")) + " Dossier de diagnostic technique (DPE, et selon le cas : plomb, amiante, électricité, gaz, risques)");
  P(bx(annexHas(bn, "notice")) + " Notice d'information relative aux droits et obligations des locataires et des bailleurs");
  P(bx(annexHas(bn, "copro")) + " Extraits du règlement de copropriété (destination, jouissance et usage des parties privatives et communes)");
  ["charges", "repar", "caution", "assur"].filter(k => annexHas(bn, k)).forEach(k => P(bx(true) + " " + annexLabel(k)));
  sigBlock(d, o.ville, o.debut, sig); if (sig) proofPage(d, sig, (VIDE ? "Contrat de location · " : "Contrat de location meublée · ") + (o.adr || "") + " · prise d'effet le " + frDate(o.debut)); return d.finish(VIDE ? "Contrat de location" : "Contrat de location meublée");
}

/* ---------- Lettres et attestations ---------- */
function sheetLettre(kind){
  const id = V.bsel, s = soldeLoc(id), t = s.t || {}, c = bailleurInfo(), titre = {impaye:"Lettre de loyer impayé", attest:"Attestation de loyer", depot:"Restitution du dépôt de garantie", rappel:"Rappel avant l'état des lieux de sortie"}[kind];
  const common = dxF("lt-bail", "Bailleur", c.nom) + dxF("lt-badr", "Adresse du bailleur", c.adr) + dxF("lt-loc", "Locataire", t.nom || "") + dxF("lt-adr", "Adresse du logement", bienAdr(id)) + dxF("lt-ville", "Fait à", (S.cfg && S.cfg.ville) || "");
  let spec = "";
  if (kind === "impaye"){ const du = r2(sum(s.retard.map(j => j.montant)));
    spec = dxF("lt-mont", "Montant dû (€)", fmtNum(du), 'inputmode="decimal"') + `<div class="small muted">${s.retard.length ? s.retard.map(j => MOIS[mo(j)].toLowerCase() + " " + yr(j) + " : " + eur(j.montant)).join(" · ") : "Aucun loyer non reçu dans l'appli : précise le montant."}</div>` + dxF("lt-delai", "Délai accordé (jours)", "8", 'inputmode="numeric"'); }
  if (kind === "attest") spec = `<div class="grid2">${dxF("lt-lhc", "Loyer hors charges (€)", fmtNum(t.loyer ? r2(N(t.loyer) - N(t.charges)) : ""), 'inputmode="decimal"')}${dxF("lt-chg", "Charges (€)", fmtNum(t.charges || ""), 'inputmode="decimal"')}</div>${dxF("lt-debut", "Occupe le logement depuis le", t.debut || "", 'type="date"')}${dxS("lt-jour", "Locataire à jour de ses loyers", [["Oui", "Oui"], ["Non", "Non"]], s.solde >= -0.005 ? "Oui" : "Non")}`;
  if (kind === "depot") spec = `<div class="grid2">${dxF("lt-dep", "Dépôt versé (€)", fmtNum(t.depot || ""), 'inputmode="decimal"')}${dxF("lt-sortie", "Date de sortie", t.fin || todayIso(), 'type="date"')}</div><label class="f">Retenues (une par ligne : libellé ; montant)<textarea id="lt-ret" placeholder="Réparation du volet ; 80"></textarea></label>${dxS("lt-conf", "État des lieux de sortie", [["conforme", "Conforme à l'entrée (1 mois)"], ["ecart", "Écarts constatés (2 mois)"]], "conforme")}`;
  if (kind === "rappel") spec = dxF("lt-sortie", "Date de départ prévue", (s.t && s.t.fin) || "", 'type="date"');
  openSheet(`<h2>${titre}</h2>${common}${spec}<div class="btns"><button class="btn" style="flex:1" data-act="let-pdf" data-v="${kind}">Créer le PDF</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>
    <div class="btns"><button class="btn ghost" style="flex:1" data-act="let-pdf" data-v="${kind}" data-sign="1">Faire signer sur l'écran</button></div>
    <div class="small muted">« Faire signer » : tu signes (et, pour la restitution du dépôt, le locataire aussi) avec le doigt. Le PDF signé est rangé dans le dossier du locataire (Documents du locataire) et prêt à envoyer.</div>`);
}
function letterPdf(kind, o, sig){
  const d = new PdfDoc(kind === "impaye" ? "Loyer impayé" : kind === "attest" ? "Attestation de loyer" : kind === "rappel" ? "Rappel état des lieux de sortie" : "Dépôt de garantie"), M = d.M, R = d.W - M, P = (s, g) => { d.para(s, 10.5, g || 15); d.y -= 4; };
  d.text(M, d.y, o.bail || "(bailleur)", {size:10.5, bold:true}); d.text(R, d.y, o.loc || "(locataire)", {size:10.5, bold:true, right:true}); d.y -= 14;
  d.text(M, d.y, o.badr || "", {size:10}); d.text(R, d.y, o.adr || "", {size:10, right:true}); d.y -= 30;
  d.text(R, d.y, (o.ville ? o.ville + ", le " : "Le ") + frDate(todayIso()), {size:10.5, right:true}); d.y -= 30;
  if (kind === "impaye"){
    d.text(M, d.y, "Objet : loyer impayé · logement situé " + (o.adr || ""), {size:10.5, bold:true}); d.y -= 26; P("Madame, Monsieur,");
    P("Sauf erreur de ma part, les sommes ci-dessous restent impayées au titre du loyer et des charges du logement situé " + (o.adr || "………") + ", que vous occupez en vertu du bail en cours.");
    if (o.lignes.length) dTable(d, [{h:"Période", w:300}, {h:"Montant", w:211, right:true}], o.lignes.map(l => [l[0], eur(l[1])]));
    P("Total restant dû : " + eur(o.mont) + " (" + montantLettres(o.mont) + ").");
    P("Je vous demande de bien vouloir régler cette somme dans un délai de " + o.delai + " jours à compter de la réception de la présente. Si vous rencontrez une difficulté, merci de me contacter rapidement afin que nous trouvions ensemble une solution amiable, par exemple un échelonnement.");
    P("À défaut de règlement, je serai contraint(e) d'engager les démarches prévues par la loi et par le bail, notamment la délivrance d'un commandement de payer par commissaire de justice, qui peut conduire à la résiliation du bail par application de la clause résolutoire, ainsi que le recouvrement des sommes dues.");
    P("Dans l'attente, je vous prie d'agréer, Madame, Monsieur, mes salutations distinguées.");
    d.y -= 20; d.text(R, d.y, o.bail || "", {size:10.5, right:true}); d.y -= 40; d.para("Lettre à envoyer de préférence en recommandé avec accusé de réception. Elle ne constitue pas un commandement de payer.", 8.5, 11.5);
  } else if (kind === "attest"){
    d.y -= 6; d.text(d.W / 2, d.y, "ATTESTATION DE LOYER", {size:18, bold:true, center:true, color:"#0E6B5C"}); d.y -= 34;
    P("Je soussigné(e) " + (o.bail || "………") + ", demeurant " + (o.badr || "………") + ", propriétaire du logement situé " + (o.adr || "………") + ", atteste que " + (o.loc || "………") + " occupe ce logement à titre de résidence principale" + (o.debut ? " depuis le " + frDate(o.debut) : "") + ".", 17);
    P("Le loyer mensuel est de " + eur(o.lhc) + " hors charges, auquel s'ajoutent " + eur(o.chg) + " de charges, soit " + eur(r2(o.lhc + o.chg)) + " charges comprises.", 17);
    P("À la date du " + frDate(todayIso()) + ", le locataire " + (o.jour === "Oui" ? "est à jour du paiement de son loyer et de ses charges." : "n'est pas à jour du paiement de son loyer et de ses charges."), 17);
    P("Attestation établie pour servir et valoir ce que de droit.", 17); d.y -= 30; d.text(R, d.y, "Signature du bailleur", {size:10.5, right:true});
  } else if (kind === "rappel"){
    d.text(M, d.y, "Objet : préparation de l'état des lieux de sortie · " + (o.adr || ""), {size:10.5, bold:true}); d.y -= 26; P("Madame, Monsieur,");
    P("Nous avons bien noté votre départ du logement situé " + (o.adr || "………") + (o.sortie ? ", prévu le " + frDate(o.sortie) : "") + ". Un état des lieux de sortie sera réalisé en votre présence. Pour qu'il se déroule bien, voici les points à préparer :");
    ["Logement propre et vidé de vos affaires, y compris la cave et les annexes ; cuisine, salle de bains, WC, hotte et joints nettoyés.",
     "Percements rebouchés, aménagements ajoutés sans accord retirés, installations électriques provisoires supprimées.",
     "Équipements en état de fonctionnement : robinetterie, siphons, sanitaires ; vitres et revêtements abîmés réparés.",
     "Toutes les clés et badges remis le jour de l'état des lieux ; à défaut, leur remplacement pourra vous être facturé.",
     "Justificatifs d'entretien (chaudière, climatisation, ramonage) et attestation d'assurance à jour, si le contrat les prévoit.",
     "Relevés ou dernières factures d'électricité et de gaz, et votre nouvelle adresse pour l'envoi du décompte."].forEach(x => P("•  " + x, 14));
    P("Merci de me proposer un rendez-vous au moins une semaine avant votre déménagement. Les dégradations constatées par rapport à l'état d'entrée, déduction faite de la vétusté, pourront être imputées sur le dépôt de garantie, justificatifs à l'appui.");
    P("Je vous prie d'agréer, Madame, Monsieur, mes salutations distinguées."); d.y -= 20; d.text(R, d.y, o.bail || "", {size:10.5, right:true});
  } else {
    d.text(M, d.y, "Objet : restitution du dépôt de garantie · logement situé " + (o.adr || ""), {size:10.5, bold:true}); d.y -= 26; P("Madame, Monsieur,");
    P("Suite à votre départ du logement le " + frDate(o.sortie) + " et à l'état des lieux de sortie, voici le décompte de votre dépôt de garantie.");
    const rows = [["Dépôt de garantie versé", eur(o.dep)]].concat(o.ret.map(r => ["Retenue : " + r[0], "- " + eur(r[1])])).concat([[o.net >= 0 ? "Somme à vous restituer" : "Somme restant due par le locataire", eur(Math.abs(o.net))]]);
    dTable(d, [{h:"Désignation", w:360}, {h:"Montant", w:151, right:true}], rows);
    P("Conformément à l'article 22 de la loi du 6 juillet 1989, le dépôt de garantie est restitué dans un délai maximal " + (o.conf === "conforme" ? "d'un mois" : "de deux mois") + " à compter de la remise des clés" + (o.conf === "conforme" ? ", l'état des lieux de sortie étant conforme à celui d'entrée." : ", des écarts ayant été constatés entre les états des lieux.") + " Il ne porte pas intérêts. Les justificatifs des retenues sont joints à ce courrier.");
    P(o.net >= 0 ? "Le versement sera effectué par virement sur le compte que vous voudrez bien m'indiquer." : "Je vous remercie de bien vouloir régler ce solde dans les meilleurs délais.");
    P("Je vous prie d'agréer, Madame, Monsieur, mes salutations distinguées."); d.y -= 20; d.text(R, d.y, o.bail || "", {size:10.5, right:true});
  }
  const ttl = kind === "impaye" ? "Lettre de loyer impayé" : kind === "attest" ? "Attestation de loyer" : kind === "rappel" ? "Rappel avant état des lieux de sortie" : "Restitution du dépôt de garantie";
  if (sig){ d.need(150); d.y -= 8;
    if (sig.locataire) d.text(M, d.y, "Lu et approuvé par le locataire", {size:9, color:"#5C6B66"});
    if (sig.bailleur) d.text(R, d.y, "Signature électronique du bailleur", {size:9, right:true, color:"#5C6B66"}); d.y -= 62;
    for (const [k, x, right] of [["bailleur", R, true], ["locataire", M, false]]){ const g = sig[k]; if (!g) continue; const h = Math.min(56, 160 * g.h / g.w), w = h === 56 ? 56 * g.w / g.h : 160;
      d.image(right ? x - w - 4 : x + 4, d.y + 3, w, h, g); d.text(x, d.y - 11, "Signé le " + hhmm(g.ts), {size:8, right, color:"#5C6B66"}); }
    proofPage(d, sig, ttl + " · " + (o.adr || "")); }
  return d.finish(ttl);
}

document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, v = b.dataset.v;
  switch (a){
    case "bail-open": sheetBail(); break;
    case "bail-pdf": { const o = bailRead(); if (!o.loc || !o.debut) return toast("Indique au moins le locataire et la date de prise d'effet");
      if (o.lhc <= 0) return toast("Indique le loyer hors charges"); if (o.dep > r2(o.lhc * (bkind(V.bsel) === "vide" ? 1 : 2)) + 0.005) return toast("Le dépôt ne peut pas dépasser " + (bkind(V.bsel) === "vide" ? "1 mois" : "2 mois") + " de loyer hors charges (" + eur(o.lhc * (bkind(V.bsel) === "vide" ? 1 : 2)) + ")");
      S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.bailleur = o.bail; S.cfg.bailleurAdr = o.badr; S.cfg.ville = o.ville;
      const bn = S.biens.find(x => x.id === V.bsel); if (bn){ if (o.adr) bn.adresse = o.adr; bn.desc = {type:o.type, surface:o.surf, etage:o.etage, pieces:o.pieces, copro:o.copro, dpe:o.dpe, chauffage:o.chauf, eauch:o.eau, annexes:o.annex}; }
      persist(); if (o.dpe === "G") toast("Attention : un logement classé G ne peut plus être loué en résidence principale (depuis le 1er janvier 2025)");
      saveFile((bkind(V.bsel) === "vide" ? "bail-vide-" : "bail-meuble-") + V.bsel + "-" + o.debut + ".pdf", bailPdf(o), "application/pdf"); break; }
    case "let-open": sheetLettre(v); break;
    case "let-pdf": { const o = {bail:dxV("lt-bail"), badr:dxV("lt-badr"), loc:dxV("lt-loc"), adr:dxV("lt-adr"), ville:dxV("lt-ville")};
      S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.bailleur = o.bail; S.cfg.bailleurAdr = o.badr; S.cfg.ville = o.ville; persist();
      if (v === "impaye"){ o.mont = parseNum(dxV("lt-mont")) || 0; o.delai = dxV("lt-delai") || "8"; o.lignes = soldeLoc(V.bsel).retard.map(j => [MOIS[mo(j)] + " " + yr(j), j.montant]); if (!(o.mont > 0)) return toast("Indique le montant dû"); }
      if (v === "attest"){ o.lhc = parseNum(dxV("lt-lhc")) || 0; o.chg = parseNum(dxV("lt-chg")) || 0; o.debut = dxV("lt-debut"); o.jour = dxV("lt-jour"); if (!(o.lhc > 0)) return toast("Indique le loyer"); }
      if (v === "depot"){ o.dep = parseNum(dxV("lt-dep")) || 0; o.sortie = dxV("lt-sortie") || todayIso(); o.conf = dxV("lt-conf");
        o.ret = dxV("lt-ret").split("\n").map(l => { const k = l.lastIndexOf(";"); return k < 0 ? null : [l.slice(0, k).trim(), parseNum(l.slice(k + 1)) || 0]; }).filter(x => x && x[0] && x[1] > 0); o.net = r2(o.dep - sum(o.ret.map(r => r[1]))); if (!(o.dep > 0)) return toast("Indique le dépôt versé"); }
      if (v === "rappel") o.sortie = dxV("lt-sortie");
      const fn = {impaye:"loyer-impaye-", attest:"attestation-loyer-", depot:"restitution-depot-", rappel:"rappel-etat-des-lieux-sortie-"}[v] + V.bsel + "-" + todayIso() + ".pdf";
      if (b.dataset.sign){ const bien = V.bsel, tn = soldeLoc(bien).t, titre = {impaye:"Lettre de loyer impayé", attest:"Attestation de loyer", depot:"Restitution du dépôt de garantie", rappel:"Rappel avant l'état des lieux de sortie"}[v];
        const parties = [{key:"bailleur", label:"Bailleur", name:o.bail || "Bailleur"}].concat(v === "depot" ? [{key:"locataire", label:"Locataire", name:o.loc || "Locataire"}] : []);
        signFlow(parties, async res => { const pdf = letterPdf(v, o, res), fid = uid(), name = "signe-" + fn;
          await flPut(fid, {name, type:"application/pdf", buf:pdf.buffer});
          docList("docs").push(Object.assign({id:fid, bien, kind:tn ? "loc" : "autre", nom:titre + " (signé le " + frDate(res.ts.slice(0, 10)) + ")", fname:name, date:res.ts.slice(0, 10), type:"application/pdf", size:pdf.length, upd:Date.now()}, tn ? {loc:tn.id, ptype:"Courrier signé"} : {}));
          persist(); render(); await saveFile(name, pdf, "application/pdf", titre + " signé électroniquement le " + hhmm(res.ts) + "."); }, "ce courrier", JSON.stringify(o)); break; }
      saveFile(fn, letterPdf(v, o), "application/pdf"); break; }
  }
});
