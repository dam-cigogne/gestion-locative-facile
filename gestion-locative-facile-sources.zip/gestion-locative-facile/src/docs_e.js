/* ============ Signature à l'écran, preuve, et export du dossier en ZIP ============ */
function dxTouch(e){ e.upd = Date.now(); if (e.sig){ e.sig = null; toast("Signatures effacées : le document a été modifié"); } }
const hhmm = iso => { const d = new Date(iso); return pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear() + " à " + pad(d.getHours()) + ":" + pad(d.getMinutes()); };
async function sha256Hex(s){ try { const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(h)].map(x => x.toString(16).padStart(2, "0")).join(""); } catch(e){ return ""; } }

/* ---------- Écran de signature ---------- */
const SG = {drawing:false, dirty:false};
function sgSetup(){
  const cv = $("#sg-cv"); if (!cv) return; const r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); const c = cv.getContext("2d"); c.scale(dpr, dpr); c.lineWidth = 2.6; c.lineCap = "round"; c.lineJoin = "round"; c.strokeStyle = "#111"; c.fillStyle = "#fff"; c.fillRect(0, 0, r.width, r.height); SG.dirty = false;
  const pos = e => { const b = cv.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; };
  cv.onpointerdown = e => { try { cv.setPointerCapture(e.pointerId); } catch(x){} SG.drawing = true; const [x, y] = pos(e); c.beginPath(); c.moveTo(x, y); c.lineTo(x + 0.1, y + 0.1); c.stroke(); c.beginPath(); c.moveTo(x, y); SG.dirty = true; e.preventDefault(); };
  cv.onpointermove = e => { if (!SG.drawing) return; const [x, y] = pos(e); c.lineTo(x, y); c.stroke(); c.beginPath(); c.moveTo(x, y); e.preventDefault(); };
  cv.onpointerup = cv.onpointercancel = () => { SG.drawing = false; };
}
function sgExport(){ const cv = $("#sg-cv"), W = 420, H = Math.round(W * cv.height / cv.width), t = document.createElement("canvas"); t.width = W; t.height = H;
  const c = t.getContext("2d"); c.fillStyle = "#fff"; c.fillRect(0, 0, W, H); c.drawImage(cv, 0, 0, W, H); return {d:t.toDataURL("image/jpeg", 0.85), w:W, h:H}; }
function signFlow(parties, done, what, fp){ V.sg = {parties, i:0, res:{}, done, what, fingerprint:fp}; sgStep(); }
function sgStep(){
  const sg = V.sg, p = sg.parties[sg.i];
  openSheet(`<h2>Signature · ${esc(p.label)}</h2><div class="small muted">${sg.i + 1} sur ${sg.parties.length}${sg.i > 0 ? " · passe le téléphone à " + esc(p.name || p.label) : ""}</div>
    <div class="info"><b>${esc(p.name || p.label)}</b> : « Lu et approuvé. J'accepte de signer électroniquement ${esc(sg.what || "ce document")}. »</div>
    <canvas id="sg-cv" style="width:100%;height:170px;border:2px dashed var(--muted);border-radius:12px;background:#fff;touch-action:none;display:block"></canvas>
    <div class="small muted">Signe avec le doigt dans le cadre.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="sg-ok">Je signe</button><button class="btn ghost" data-act="sg-clear">Effacer</button><button class="btn ghost" data-act="sg-cancel">Annuler</button></div>`);
  setTimeout(sgSetup, 30);
}
async function sgFinish(){
  const sg = V.sg, ts = new Date().toISOString(); sg.res.ts = ts; sg.res.hash = await sha256Hex(JSON.stringify({ctx:sg.fingerprint || "", ts, sig:sg.parties.map(p => [p.key, p.name, sg.res[p.key] && sg.res[p.key].ts, sg.res[p.key] && sg.res[p.key].d])}));
  closeSheet(); const f = sg.done; V.sg = null; await f(sg.res);
}
function sigBlock(d, ville, date, sig){
  if (RELECT){ d.need(110); d.y -= 14; d.line(d.M, d.y + 8, d.W - d.M, d.y + 8, "#B3261E"); d.para("Projet destiné à la relecture. Aucune signature n'est portée. Une fois les points vérifiés avec le locataire, crée le document définitif pour le signer.", 10, 14); d.y -= 14;
    d.text(d.M, d.y, "Relu et confirmé par le locataire le ____ / ____ / ________      Initiales : ________", {size:10.5}); d.y -= 22; d.text(d.M, d.y, "Relu par le bailleur le ____ / ____ / ________      Initiales : ________", {size:10.5}); d.y -= 20; return; }
  d.need(sig ? 190 : 120); d.y -= 10; d.text(d.M, d.y, "Fait" + (ville ? " à " + ville : "") + ", le " + frDate(sig ? sig.ts.slice(0, 10) : (date || todayIso())) + ", en deux exemplaires.", {size:10.5}); d.y -= 34;
  d.text(d.M, d.y, "Le bailleur (ou son mandataire)", {size:10, bold:true}); d.text(d.W - d.M, d.y, "Le locataire", {size:10, bold:true, right:true}); d.y -= 14;
  d.text(d.W - d.M, d.y, sig ? "(« lu et approuvé », signature électronique)" : "(mention « lu et approuvé »)", {size:8.5, right:true, color:"#5C6B66"}); d.y -= 62;
  d.line(d.M, d.y, d.M + 190, d.y, "#9AA8A3"); d.line(d.W - d.M - 190, d.y, d.W - d.M, d.y, "#9AA8A3");
  if (sig) for (const [k, x, right] of [["bailleur", d.M, false], ["locataire", d.W - d.M - 190, true]]){ const s = sig[k]; if (!s) continue; const h = Math.min(56, 160 * s.h / s.w), w = h === 56 ? 56 * s.w / s.h : 160;
    d.image(x + 4, d.y + 3, w, h, s); d.text(x, d.y - 11, "Signé le " + hhmm(s.ts), {size:8, color:"#5C6B66"}); }
}
function proofPage(d, sig, titre){
  d.newPage(); d.text(d.M, d.y, "PREUVE DE SIGNATURE ÉLECTRONIQUE", {size:15, bold:true, color:"#0E6B5C"}); d.y -= 26; d.para("Document : " + titre, 10.5, 15); d.y -= 6;
  dTable(d, [{h:"Rôle", w:110}, {h:"Nom", w:230}, {h:"Date et heure de signature", w:171}], [["Bailleur", sig.bailleur], ["Locataire", sig.locataire]].filter(r => r[1]).map(r => [r[0], r[1].nom || "", hhmm(r[1].ts)]));
  d.para("Empreinte numérique (SHA-256) du contenu et des signatures :", 10, 14); const hx = sig.hash || "indisponible"; d.para(hx.slice(0, 32), 10, 14); d.para(hx.slice(32), 10, 14); d.y -= 8;
  d.para("Signatures électroniques simples (articles 1366 et 1367 du Code civil ; règlement européen n° 910/2014 « eIDAS »), tracées à l'écran de l'appareil du bailleur, en présence des signataires, après leur mention « lu et approuvé ». L'identité des signataires n'est pas vérifiée par un tiers de confiance : cette preuve est moins forte qu'une signature électronique avancée ou qualifiée. Conserve ce PDF : le document et l'empreinte ci-dessus en font foi.", 9.5, 13.5);
}
function sigBanner(e){
  return `<div class="btns"><button class="btn sm ghost" data-act="dx-rel">PDF de relecture (à relire avant de signer)</button></div>` + (e.sig ? `<div class="info">Signé par ${esc(e.sig.bailleur.nom || "le bailleur")} le ${hhmm(e.sig.bailleur.ts)} et par ${esc(e.sig.locataire.nom || "le locataire")} le ${hhmm(e.sig.locataire.ts)}. Modifier le document efface les signatures.</div><div class="btns"><button class="btn sm ghost" data-act="dx-sign">Refaire les signatures</button></div>`
    : `<div class="btns"><button class="btn sm ghost" data-act="dx-sign">Faire signer sur l'écran</button></div>`);
}

/* ---------- ZIP (sans compression) : dossier d'un bien rangé en sous-dossiers ---------- */
const CRC_T = (() => { const t = []; for (let n = 0; n < 256; n++){ let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u => { let c = -1; for (let i = 0; i < u.length; i++) c = CRC_T[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function zipStore(files){
  const enc = new TextEncoder(), now = new Date(), tm = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1), dd = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate(), chunks = [], cen = []; let off = 0;
  for (const f of files){ const nm = enc.encode(f.name), crc = crc32(f.data), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, tm, true); h.setUint16(12, dd, true); h.setUint32(14, crc, true); h.setUint32(18, f.data.length, true); h.setUint32(22, f.data.length, true); h.setUint16(26, nm.length, true); h.setUint16(28, 0, true);
    chunks.push(new Uint8Array(h.buffer), nm, f.data);
    const c = new DataView(new ArrayBuffer(46)); c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, tm, true); c.setUint16(14, dd, true); c.setUint32(16, crc, true); c.setUint32(20, f.data.length, true); c.setUint32(24, f.data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
    cen.push(new Uint8Array(c.buffer), nm); off += 30 + nm.length + f.data.length; }
  const cs = cen.reduce((a, x) => a + x.length, 0), e = new DataView(new ArrayBuffer(22)); e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
  const all = chunks.concat(cen, [new Uint8Array(e.buffer)]), out = new Uint8Array(off + cs + 22); let p = 0; for (const x of all){ out.set(x, p); p += x.length; } return out;
}
const cleanName = s => String(s || "").replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim() || "Sans nom";
async function dossierFiles(id){
  const root = cleanName(bienName(id)), out = [], used = new Set();
  const add = (dir, name, data) => { let n = `${root}/${dir}/${cleanName(name)}`; if (used.has(n)){ const k = n.lastIndexOf("."); let i = 2; while (used.has(k < 0 ? n + " (" + i + ")" : n.slice(0, k) + " (" + i + ")" + n.slice(k))) i++; n = k < 0 ? n + " (" + i + ")" : n.slice(0, k) + " (" + i + ")" + n.slice(k); } used.add(n); out.push({name:n, data}); };
  const addFiles = async (kind, dir) => { for (const d of fileDocs(id, kind)){ const r = await flGet(d.id); if (r) add(dir, d.date + " - " + (d.fname || d.nom), new Uint8Array(r.buf)); } };
  await addFiles("bail", "01 Bail");
  for (const e of docList("edl").filter(x => x.bien === id && !x.del)){ if (e.fichier && !e.pieces.some(p => p.items.some(i => i.etat || i.com || (i.ph || []).length))) continue;
    add("02 États des lieux", e.date + " - État des lieux " + (e.type === "sortie" ? "sortie" : "entrée") + (e.sig ? " (signé)" : "") + ".pdf", await edlPdf(e)); }
  await addFiles("edl", "02 États des lieux");
  for (const e of docList("inv").filter(x => x.bien === id && !x.del)){ if (e.fichier && !e.items.some(i => i.etat || i.com)) continue;
    add("03 Inventaires", e.date + " - Inventaire " + (e.type === "sortie" ? "sortie" : "entrée") + (e.sig ? " (signé)" : "") + ".pdf", invPdf(e)); }
  await addFiles("inv", "03 Inventaires"); await addFiles("autre", "04 Autres documents");
  return out;
}
async function exportDossier(ids, nom){
  toast("Préparation du dossier…"); let files = []; for (const id of ids) files = files.concat(await dossierFiles(id));
  if (!files.length) return toast("Rien à ranger pour l'instant");
  await saveFile(nom + "-" + todayIso() + ".zip", zipStore(files), "application/zip"); }

document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, e = V.doc ? docCur() : null;
  switch (a){
    case "sg-clear": sgSetup(); break;
    case "sg-cancel": V.sg = null; closeSheet(); break;
    case "sg-ok": { if (!SG.dirty) return toast("Signe d'abord dans le cadre"); const sg = V.sg, p = sg.parties[sg.i]; sg.res[p.key] = Object.assign(sgExport(), {ts:new Date().toISOString(), nom:p.name || p.label}); sg.i++;
      if (sg.i < sg.parties.length) sgStep(); else await sgFinish(); break; }
    case "dx-sign": { if (!e) break; const bn = bailleurInfo().nom || "Bailleur", what = (V.doc.kind === "edl" ? "cet état des lieux" : "cet inventaire");
      signFlow([{key:"bailleur", label:"Bailleur", name:bn}, {key:"locataire", label:"Locataire", name:e.loc || "Locataire"}], async res => {
        e.sig = res; e.upd = Date.now(); persist(); render(); toast("Signé le " + hhmm(res.ts)); }, what, JSON.stringify(Object.assign({}, e, {sig:null}))); break; }
    case "bail-sign": { const o = bailRead(); if (!o.loc || !o.debut) return toast("Indique au moins le locataire et la date de prise d'effet"); if (o.lhc <= 0) return toast("Indique le loyer hors charges");
      if (o.dep > r2(o.lhc * 2) + 0.005) return toast("Le dépôt ne peut pas dépasser 2 mois de loyer hors charges (" + eur(o.lhc * 2) + ")");
      S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.bailleur = o.bail; S.cfg.bailleurAdr = o.badr; S.cfg.ville = o.ville;
      const bn = S.biens.find(x => x.id === V.bsel); if (bn){ if (o.adr) bn.adresse = o.adr; bn.desc = {type:o.type, surface:o.surf, etage:o.etage, pieces:o.pieces, copro:o.copro, dpe:o.dpe, chauffage:o.chauf, eauch:o.eau, annexes:o.annex}; } persist();
      const bien = V.bsel; signFlow([{key:"bailleur", label:"Bailleur", name:o.bail || "Bailleur"}, {key:"locataire", label:"Locataire", name:o.loc}], async res => {
        const pdf = bailPdf(o, res), fid = uid(), name = "Bail signé " + o.debut + ".pdf";
        await flPut(fid, {name, type:"application/pdf", buf:pdf.buffer}); docList("docs").push({id:fid, bien, kind:"bail", nom:"Bail signé le " + frDate(res.ts.slice(0, 10)), fname:name, date:res.ts.slice(0, 10), type:"application/pdf", size:pdf.length, upd:Date.now()});
        persist(); render(); await saveFile(name, pdf, "application/pdf", "Contrat de location meublée signé électroniquement le " + hhmm(res.ts) + "."); }, "ce contrat de location", JSON.stringify(o)); break; }
    case "zip-bien": exportDossier([V.bsel], "Dossier " + cleanName(bienName(V.bsel))); break;
    case "zip-all": exportDossier(bienIds(), "Gestion Locative Facile"); break;
  }
});
