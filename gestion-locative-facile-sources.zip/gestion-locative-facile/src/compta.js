/* ---------- Compta : regroupement pour ton site de compta (indicatif, à ajuster) ---------- */
/* Articles de dépenses du site (liste lue sur l'écran Dépenses) */
const SITE_ART = ["Eau","Energie","Internet","Téléphone","Charges courantes","Fond de prévoyance","Fond de roulement","Fond Travaux ALUR","Travaux de copropriété","Assurance emprunteur","Assurance GLI","Assurance Habitation 'Propriétaire Non Occupant'","Autres assurances","Autres Equipements","Cuisine équipée","Electroménager","Entretien et réparations","Mobilier","Terrain","Travaux","Adhésion à un OGA","Autres charges","Autres honoraires","Documentation","Frais de comptabilité (facture JD2M, ELM,...)","Frais de diagnostics","Frais de tenue de compte","Frais postaux","Honoraires agence (mise en relation et gestion) / Conciergerie","Publicité","Séminaires et formations","Commission garantie / de caution (Crédit Logement)","Frais agence","Frais de courtage emprunt","Honoraires du notaire","Cotisation Foncière des Entreprises (CFE)","Taxe d'assainissement","Taxe enlèvement des ordures ménagères (TEOM)","Taxe foncière","Autres Impôts et taxes","Charges locatives","Location immobilière"];
const SITE_ART_REC = ["Loyer hors charges locatives","Provision pour charges","Régularisation des charges","Forfait pour charges","Récupération de la TOM","Dépôt de garantie versé par le locataire","Indemnité assurance loyer impayé","Indemnité assurance sinistre","Indemnité assurance emprunteur"];
const SITE_IMMO = ["Autres Equipements","Cuisine équipée","Electroménager","Mobilier","Terrain","Travaux"];
const ART_DEFAULT = {
  "Assurance PNO":"Assurance Habitation 'Propriétaire Non Occupant'", "Assurance GMPA":"Autres assurances",
  "Syndic / copropriété":"Charges courantes", "Eau":"Eau", "Électricité":"Energie",
  "Taxe foncière":"Taxe foncière", "CFE":"Cotisation Foncière des Entreprises (CFE)",
  "Comptabilité":"Frais de comptabilité (facture JD2M, ELM,...)", "CGA / OGA":"Adhésion à un OGA", "Abonnement Rendement locatif":"Autres charges",
  "Entretien / réparations":"Entretien et réparations", "Mobilier / équipement":"Mobilier", "Diagnostics":"Frais de diagnostics",
  "Frais bancaires / cotisations":"Frais de tenue de compte", "Divers":"Autres charges"
};
const artOf = c => ((S.cfg && S.cfg.cmap) || {})[c] || ART_DEFAULT[c] || "Autres charges";
const posteOf = artOf;
const isImmoArt = a => SITE_IMMO.includes(a);
const cdone = k => !!((S.cfg && S.cfg.cdone) || {})[k];

/* emprunt d'un bien : {capital, taux, duree (mois), debut (AAAA-MM-JJ), assur (€/mois)} */
function empOf(id){ const b = S.biens.find(x => x.id === id); return b && b.emprunt && b.emprunt.capital > 0 && b.emprunt.duree > 0 && b.emprunt.debut ? b.emprunt : null; }
function amort(e){
  const n = Math.round(e.duree), r = (e.taux || 0) / 1200, cap = e.capital;
  const m = r === 0 ? cap / n : cap * r / (1 - Math.pow(1 + r, -n));
  const rows = []; let crd = cap; const y0 = +e.debut.slice(0, 4), m0 = +e.debut.slice(5, 7) - 1;
  for (let k = 0; k < n; k++){
    const it = r2(crd * r), kap = k === n - 1 ? r2(crd) : r2(m - it); crd = r2(crd - kap);
    const mm = m0 + k, y = y0 + Math.floor(mm / 12), mo = mm % 12;
    rows.push({k:k + 1, y, m:mo, mens:r2(it + kap), it, kap, crd:Math.max(0, crd)});
  }
  return {mens:r2(m), rows};
}
function empYear(id, y){
  const e = empOf(id); if (!e) return null;
  const A = amort(e), R = A.rows.filter(x => x.y === y), prev = A.rows.filter(x => x.y < y);
  const crdFin = R.length ? R[R.length - 1].crd : (prev.length ? prev[prev.length - 1].crd : e.capital);
  return {e, mens:A.mens, nb:R.length, it:r2(sum(R.map(x => x.it))), kap:r2(sum(R.map(x => x.kap))), assur:r2((e.assur || 0) * R.length), crd:crdFin};
}

/* synthèse de l'année pour un bien */
function comptaBien(id, y){
  const L = J().filter(j => j.bien === id && yr(j) === y);
  const rec = L.filter(j => j.type === "Recette");
  const loyers = r2(sum(rec.filter(j => j.cat === "Loyer").map(j => j.montant)));
  const autres = r2(sum(rec.filter(j => j.cat !== "Loyer").map(j => j.montant)));
  const dep = L.filter(j => j.type === "Dépense" && (j.compte || "Bien") !== "Perso");
  const postes = {};
  for (const j of dep){ if (j.cat === "Crédit (mensualité)") continue; const p = posteOf(j.cat), o = postes[p] || (postes[p] = {n:p, v:0, nb:0, ok:0}); o.v = r2(o.v + j.montant); o.nb++; if (j.compta) o.ok++; }
  const credit = r2(sum(dep.filter(j => j.cat === "Crédit (mensualité)").map(j => j.montant)));
  const ey = empYear(id, y);
  const charges = r2(sum(Object.values(postes).map(p => p.v)));
  const interets = ey ? ey.it : 0, assurE = ey ? ey.assur : 0;
  const aSaisir = dep.filter(j => j.pointe === "x" && !j.compta).length;
  const fact = live(S.factures).filter(f => f.date && +f.date.slice(0, 4) === y && (f.cat || "").toUpperCase() !== "" );
  return {id, y, loyers, autres, postes:Object.values(postes).sort((a, b) => b.v - a.v), credit, ey, charges, interets, assurE, aSaisir,
    resultat:r2(loyers + autres - charges - interets - assurE), fact, lignes:dep.sort((a, b) => a.date.localeCompare(b.date))};
}

function checkItem(label, lines){
  const n = lines.length, ok = lines.filter(j => j.compta).length;
  const st = !n ? "no" : ok === n ? "ok" : "mid";
  return {label, st, n, ok};
}
const CHECK_DEF = {rec:true, int:true, cats:{"Taxe foncière":"bien", "Assurance GMPA":"bien", "Assurance PNO":"bien", "CFE":"all", "Comptabilité":"all", "CGA / OGA":"all", "Abonnement Rendement locatif":"all"}};
const checkCfg = () => S.check || CHECK_DEF;
function checklistCompta(y, list){
  const L = J().filter(j => yr(j) === y && j.compte !== "Perso"), items = [], cfg = checkCfg();
  const cat = (c, ids) => L.filter(j => j.type === "Dépense" && j.cat === c && (!ids || ids.includes(j.bien)));
  if (cfg.rec) items.push(checkItem("Recettes (loyers)", L.filter(j => j.type === "Recette" && list.includes(j.bien))));
  for (const c of allCats("Dépense")){ const m = (cfg.cats || {})[c]; if (!m || c === "Crédit (mensualité)") continue;
    if (m === "all") items.push(checkItem(c, cat(c)));
    else for (const id of list) items.push(checkItem(c + " · " + bienName(id), cat(c, [id]))); }
  if (cfg.int) for (const id of list){ const e = empOf(id), ey = e && empYear(id, y), lb = "Intérêts d'emprunt · " + bienName(id);
    items.push(e ? {label:lb, st:ey && ey.it > 0 ? "ok" : "mid", n:1, ok:ey && ey.it > 0 ? 1 : 0, txt:ey ? eur(ey.it) : ""} : {label:lb, st:"no", n:0, ok:0, txt:"emprunt à renseigner"}); }
  return items;
}
const ckNorm = t => String(t).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
const CK_RULES = [[/\b(recette|loyer)/, "rec"], [/interet|emprunt/, "int"], [/\bcfe\b/, "CFE"], [/foncier/, "Taxe foncière"], [/gmpa/, "Assurance GMPA"], [/\bpno\b/, "Assurance PNO"], [/compta/, "Comptabilité"], [/\b(cga|oga)\b|cgaction/, "CGA / OGA"], [/rendement/, "Abonnement Rendement locatif"], [/syndic|copro/, "Syndic / copropriété"], [/\beau\b/, "Eau"], [/electricit/, "Électricité"], [/entretien|reparation/, "Entretien / réparations"], [/mobilier|equipement/, "Mobilier / équipement"], [/diagnostic/, "Diagnostics"], [/bancaire|cotisation/, "Frais bancaires / cotisations"]];
const CK_GLOBAL = ["CFE", "Comptabilité", "CGA / OGA", "Abonnement Rendement locatif"];
function parseChecklistText(text){
  const cfg = {rec:false, int:false, cats:{}}, notes = [], seen = new Set(), bw = bienIds().map(id => ckNorm(bienName(id)).split(/[^a-z0-9]+/).filter(w => w.length >= 2 && w !== "appartement"));
  for (let raw of String(text).split(/\r?\n/)){
    let l = raw.replace(/^[\s☑☐✓✔✅❌🟠◐•\-*·\d.)]+/, "").split(/\s[:·]\s/)[0].trim(); if (l.length < 3) continue;
    const n = ckNorm(l); if (/^(declaration|liste a ne pas|☑)/.test(n) || /edit|saisi sur le site/.test(n) && /=/.test(n)) continue;
    const r = CK_RULES.find(x => x[0].test(n)); if (!r){ notes.push(l); continue; }
    if (r[1] === "rec") cfg.rec = true; else if (r[1] === "int") cfg.int = true;
    else { const named = bw.some(ws => ws.length && ws.some(w => n.includes(w))), c = r[1], was = cfg.cats[c];
      cfg.cats[c] = named || was === "bien" ? "bien" : CK_GLOBAL.includes(c) ? "all" : "bien";
      if (seen.has(c) && named) cfg.cats[c] = "bien"; seen.add(c); } }
  return {cfg, notes};
}
function importChecklist(){
  const i = document.createElement("input"); i.type = "file"; i.accept = ".docx,.txt,.md";
  i.onchange = async () => { const f = i.files && i.files[0]; if (!f) return;
    try { const {cfg, notes} = parseChecklistText(await docTextOf(f)); if (!cfg.rec && !cfg.int && !Object.keys(cfg.cats).length) return toast("Je n'ai reconnu aucune ligne dans ce fichier"); sheetCheck(cfg, notes); }
    catch(e){ toast("Lecture impossible : " + (e.message || e)); } };
  i.click();
}
function sheetCheck(over, notes){
  const cfg = over || checkCfg(), cs = allCats("Dépense").filter(c => c !== "Crédit (mensualité)");
  openSheet(`<h2>Ma liste « À ne pas oublier »</h2>
    ${over ? '<div class="small" style="padding:8px;border-radius:10px;background:rgba(255,160,0,.15)"><b>Vérifie avant d\'enregistrer.</b> Voici ce que j\'ai compris de ton fichier Word : corrige si besoin, puis « Enregistrer ».' + (notes && notes.length ? '<br>Lignes non reconnues (à ajouter à la main si besoin) : ' + notes.map(esc).join(" · ") : "") + '</div>' : ""}
    <div class="small muted">Choisis ce que TU dois penser à saisir dans ta compta. « Par logement » = une ligne par bien ; « Global » = une seule ligne pour tous les biens (ex. une taxe ou un abonnement commun).</div>
    <label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" id="ck-rec" ${cfg.rec ? "checked" : ""}> Recettes (loyers)</label>
    <label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" id="ck-int" ${cfg.int ? "checked" : ""}> Intérêts d'emprunt (par logement)</label>
    ${cs.map(c => { const m = (cfg.cats || {})[c] || ""; return `<label class="f">${esc(c)}<select class="ck-cat" data-c="${esc(c)}"><option value="">— ne pas suivre</option><option value="bien" ${m === "bien" ? "selected" : ""}>Par logement</option><option value="all" ${m === "all" ? "selected" : ""}>Global</option></select></label>`; }).join("")}
    <div class="btns"><button class="btn" style="flex:1" data-act="ck-save">Enregistrer</button><button class="btn ghost" data-act="ck-reset">Liste de départ</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
async function checklistDocx(y, list){
  const it = checklistCompta(y, list), enc = new TextEncoder(), x = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const par = (t, o = {}) => `<w:p><w:pPr>${o.h ? '<w:pStyle w:val="Heading1"/>' : ""}<w:spacing w:after="${o.h ? 160 : 80}"/></w:pPr><w:r><w:rPr>${o.b || o.h ? "<w:b/>" : ""}${o.g ? '<w:color w:val="666666"/>' : ""}${o.h ? '<w:sz w:val="32"/>' : ""}</w:rPr><w:t xml:space="preserve">${x(t)}</w:t></w:r></w:p>`;
  const tx = a => a.txt || (a.st === "ok" ? "saisi sur le site" : a.st === "mid" ? a.ok + "/" + a.n + " saisi(s) sur le site" : "rien dans le journal");
  const body = par("Déclaration comptabilité · " + y, {h:1}) + par("Liste à ne pas oublier, éditée le " + frDate(todayIso()) + (list.length === 1 ? " · " + bienName(list[0]) : ""), {g:1})
    + it.map(a => par((a.st === "ok" ? "☑ " : "☐ ") + a.label + " : " + tx(a))).join("")
    + par("☑ = saisi sur le site · ☐ = à faire ou à vérifier.", {g:1});
  const doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + body + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr></w:body></w:document>';
  const files = [
    {name:"[Content_Types].xml", data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')},
    {name:"_rels/.rels", data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')},
    {name:"word/document.xml", data:enc.encode(doc)}];
  await saveFile("a-ne-pas-oublier-" + y + ".docx", zipStore(files), "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
}
function checklistCard(y, list){
  const it = checklistCompta(y, list), done = it.filter(x => x.st === "ok").length;
  const ic = {ok:"✓", mid:"◐", no:"✗"}, tx = x => x.txt || (x.st === "ok" ? "saisi sur le site" : x.st === "mid" ? x.ok + "/" + x.n + " saisi(s) sur le site" : "rien dans le journal");
  return `<div class="card"><h2>À ne pas oublier ${y}</h2><div class="small muted">${done} sur ${it.length} complet(s). ✓ saisi sur le site · ◐ dans le journal, à saisir · ✗ rien trouvé : vérifie si tu as bien tout ajouté.</div>
    ${it.map(x => `<div class="kv"><span>${x.st === "ok" ? "✅" : x.st === "mid" ? "🟠" : "❌"} ${esc(x.label)}</span><span class="small muted">${esc(tx(x))}</span></div>`).join("")}
    <div class="small muted">Un point ❌ est normal si la dépense n'existe pas pour ce bien cette année.</div>
    <div class="btns"><button class="btn ghost" data-act="ck-open">Personnaliser ma liste</button><button class="btn ghost" data-act="ck-docx">Word ⬇</button><button class="btn ghost" data-act="ck-imp">Word ⬆</button></div></div>`;
}
function viewCompta(){
  const y = V.y, ids = bienIds().filter(id => bkind(id) === "meuble");
  if (!ids.length) return topbar("Compta", yearNav()) + `<div class="card"><h2>Compta : location meublée (LMNP)</h2><div class="small">Cette partie prépare la comptabilité des locations <b>meublées</b> (régime LMNP, BIC au réel). Tes logements sont en location vide : ils relèvent des revenus fonciers (déclaration 2044), qui ne sont pas encore gérés ici. Le Guide du bailleur explique la différence.</div><div class="btns"><button class="btn" data-act="go" data-v="guide">Ouvrir le Guide du bailleur</button></div></div>`;
  if (!V.csel || (V.csel !== "all" && !ids.includes(V.csel))) V.csel = "all";
  const sel = V.csel, list = sel === "all" ? ids : [sel], D = list.map(id => comptaBien(id, y));
  const T = k => r2(sum(D.map(d => d[k])));
  const posteAll = {}; for (const d of D) for (const p of d.postes){ const o = posteAll[p.n] || (posteAll[p.n] = {n:p.n, v:0}); o.v = r2(o.v + p.v); }
  const rows = Object.values(posteAll).sort((a, b) => b.v - a.v);
  const aSaisir = T("aSaisir"), nFact = sum(D.map(d => d.fact.filter(f => !f.jdmm).length));
  const seg = `<div class="seg"><button class="${sel==="all"?"on":""}" data-act="csel" data-v="all">Tous</button>${ids.map(id => `<button class="${sel===id?"on":""}" data-act="csel" data-v="${esc(id)}">${esc(bienName(id))}</button>`).join("")}</div>`;
  const emp = D.map(d => { const b = S.biens.find(x => x.id === d.id) || {}; return `<div class="env" style="padding:8px 0;gap:4px"><div class="top"><div>${bienPill(d.id)}</div><button class="mini" data-act="emp-open" data-id="${esc(d.id)}">${d.ey || empOf(d.id) ? "Modifier" : "Renseigner"}</button></div>
    ${empOf(d.id) ? `<div class="small muted">${eur(empOf(d.id).capital)} à ${String(empOf(d.id).taux).replace(".", ",")} % sur ${empOf(d.id).duree} mois, depuis ${frDate(empOf(d.id).debut)}</div>
      ${d.ey ? kv("Intérêts " + y, eur(d.ey.it)) + kv("Capital remboursé " + y, eur(d.ey.kap)) + kv("Assurance emprunteur " + y, eur(d.ey.assur)) + kv("Capital restant dû fin " + y, eur(d.ey.crd)) : ""}`
      : '<div class="small muted">Emprunt non renseigné : les intérêts ne sont pas comptés.</div>'}</div>`; }).join("");
  const syn = `
  <div class="hero"><div class="small">Résultat ${y} (indicatif)</div><div class="big num">${eur(T("resultat"))}</div>
    <div class="small">Loyers ${eur(T("loyers"))} − charges ${eur(T("charges"))} − intérêts ${eur(T("interets"))}</div></div>
  <div class="tiles"><button class="tile ${aSaisir ? "warn" : ""}" data-act="go" data-v="month" data-sub="" data-f="compta"><span class="n">${aSaisir}</span><span class="l">dépense(s) à saisir en compta</span></button>
    <div class="tile ${nFact ? "warn" : ""}"><span class="n">${nFact}</span><span class="l">facture(s) non enregistrée(s)</span></div></div>
  ${checklistCard(y, list)}
  <div class="card"><h2>Recettes ${y}</h2>${kv("Loyers encaissés ou prévus", eur(T("loyers")))}${T("autres") ? kv("Autres recettes", eur(T("autres"))) : ""}
    <div class="small muted">Les lignes de l'année comptent, pointées ou non. Pointe tes loyers pour t'en servir comme contrôle.</div></div>
  <div class="card"><h2>Charges ${y} par poste</h2>${catBars(rows, rows.length ? rows[0].v : 0)}${rows.length ? "" : '<div class="empty">Aucune charge cette année.</div>'}
    <div class="kv tot"><span>Total charges</span><span class="num">${eur(T("charges"))}</span></div>
    <div class="small muted">La mensualité du crédit n'est pas une charge : on ne déclare que les intérêts et l'assurance, calculés plus bas.</div></div>
  <div class="card"><h2>Emprunt et intérêts</h2>${emp}</div>
  <div class="card"><h2>Exporter pour ta compta</h2><div class="small muted">Un fichier Excel (synthèse, détail par poste, emprunt, factures) ou un PDF à garder. Regroupement indicatif, à ajuster avec le site.</div>
    <div class="btns"><button class="btn" data-act="cmp-xlsx">Excel</button><button class="btn ghost" data-act="cmp-pdf">PDF</button><button class="btn ghost" data-act="go" data-v="guide">Guide du bailleur</button></div></div>`;
  const SUBS = [["syn","Synthèse"],["log","Logements"],["emp","Échéances"],["dep","Dépenses"],["rec","Recettes"]]; if (!SUBS.some(x => x[0] === V.csub)) V.csub = "syn";
  const subseg = `<div class="seg">${SUBS.map(([k, l]) => `<button class="${V.csub === k ? "on" : ""}" data-act="csub" data-v="${k}">${l}</button>`).join("")}</div>`;
  return topbar("Compta", yearNav()) + seg + subseg + (V.csub === "syn" ? syn : cmpSite(V.csub, list, y));
}

function sheetEmprunt(id){
  const e = (S.biens.find(x => x.id === id) || {}).emprunt || {};
  openSheet(`<h2>Emprunt · ${esc(bienName(id))}</h2>
    <label class="f">Capital emprunté (€)<input id="em-cap" inputmode="decimal" value="${e.capital ? fmtNum(e.capital) : ""}"></label>
    <label class="f">Taux annuel hors assurance (%)<input id="em-taux" inputmode="decimal" value="${e.taux != null && e.taux !== "" ? String(e.taux).replace(".", ",") : ""}"></label>
    <label class="f">Durée (mois)<input id="em-dur" inputmode="numeric" value="${e.duree || ""}"></label>
    <label class="f">Date de la première échéance<input id="em-deb" type="date" value="${e.debut || ""}"></label>
    <label class="f">Date de déblocage des fonds (comme sur le site)<input id="em-fonds" type="date" value="${e.fonds || ""}"></label>
    <label class="f">Assurance emprunteur (€ par mois)<input id="em-ass" inputmode="decimal" value="${e.assur ? fmtNum(e.assur) : ""}"></label>
    <div class="small muted">Les intérêts sont calculés avec un tableau d'amortissement classique. Compare avec ton tableau de la banque.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="emp-save" data-id="${esc(id)}">Enregistrer</button>${e.capital ? `<button class="btn danger" data-act="emp-del" data-id="${esc(id)}">Retirer</button>` : ""}<button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}

/* ---- exports ---- */
function comptaData(y, sel){ const ids = sel === "all" ? bienIds() : [sel]; return {y, ids, D:ids.map(id => comptaBien(id, y))}; }
function comptaXlsx(y, sel){
  const C = comptaData(y, sel), wb = XLSX.utils.book_new(), dt = iso => isoToSerial(iso), money = "#,##0.00 \"€\"";
  const add = (name, aoa, widths, fmt) => { const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = widths.map(w => ({wch:w}));
    for (const k of Object.keys(ws)){ if (k[0] === "!") continue; const c = ws[k]; if (c.t === "n" && fmt && fmt(k)) c.z = fmt(k); } XLSX.utils.book_append_sheet(wb, ws, name); };
  const bl = (S.cfg && S.cfg.bailleur) || "";
  add("Synthèse", [["Compta " + y + " (regroupement indicatif)"], [bl ? "Bailleur : " + bl : ""], [], ["Bien", "Régime", "Loyers", "Autres recettes", "Charges", "Intérêts d'emprunt", "Assurance emprunteur", "Résultat"]]
    .concat(C.D.map(d => [bienName(d.id), (S.biens.find(b => b.id === d.id) || {}).regime || "", d.loyers, d.autres, d.charges, d.interets, d.assurE, d.resultat]))
    .concat([["Total", "", ...["loyers", "autres", "charges", "interets", "assurE", "resultat"].map(k => r2(sum(C.D.map(d => d[k]))))]]),
    [22, 16, 14, 16, 14, 18, 20, 14], k => /^[C-H]/.test(k) && +k.slice(1) > 4 ? money : null);
  const post = [["Bien", "Poste", "Montant", "Nb lignes", "Saisies en compta"]]; for (const d of C.D) for (const p of d.postes) post.push([bienName(d.id), p.n, p.v, p.nb, p.ok]);
  add("Charges par poste", post, [22, 48, 14, 10, 18], k => k[0] === "C" && +k.slice(1) > 1 ? money : null);
  const det = [["Date", "Bien", "Poste compta", "Catégorie", "Libellé", "Montant", "Payé", "Saisi compta", "Fournisseur / n° facture"]];
  for (const d of C.D) for (const j of d.lignes) det.push([dt(j.date), bienName(j.bien), j.cat === "Crédit (mensualité)" ? "(non déclaré : voir Emprunt)" : posteOf(j.cat), j.cat, j.lib, j.montant, j.pointe === "x" ? "x" : "", j.compta ? "x" : "", j.fourn]);
  add("Détail dépenses", det, [12, 16, 40, 24, 32, 14, 8, 12, 26], k => k[0] === "A" && +k.slice(1) > 1 ? "dd/mm/yyyy" : (k[0] === "F" && +k.slice(1) > 1 ? money : null));
  const em = [["Bien", "Année", "Échéances", "Mensualité", "Intérêts", "Capital remboursé", "Assurance", "Capital restant dû fin d'année"]];
  for (const d of C.D){ const e = empOf(d.id); if (!e) continue; const A = amort(e); const ys = [...new Set(A.rows.map(x => x.y))];
    for (const yy of ys){ const ey = empYear(d.id, yy); em.push([bienName(d.id), yy, ey.nb, A.mens, ey.it, ey.kap, ey.assur, ey.crd]); } }
  add("Emprunt par année", em, [22, 8, 10, 14, 14, 18, 12, 24], k => /^[D-H]/.test(k) && +k.slice(1) > 1 && k[0] !== "C" ? money : null);
  const fa = [["Bien", "Date", "Fournisseur", "N° facture", "Catégorie", "Description", "Prix", "Enregistrée sur le site"]];
  for (const f of live(S.factures).filter(f => f.date && +f.date.slice(0, 4) === y)) fa.push(["", dt(f.date), f.fourn, f.num, f.cat, f.desc, f.prix, f.jdmm ? "x" : ""]);
  add("Factures", fa, [10, 12, 24, 14, 16, 36, 12, 20], k => k[0] === "B" && +k.slice(1) > 1 ? "dd/mm/yyyy" : (k[0] === "G" && +k.slice(1) > 1 ? money : null));
  siteSheets(C, add, money, dt);
  return XLSX.write(wb, {type:"array", bookType:"xlsx", compression:true});
}
function comptaPdf(y, sel){
  const C = comptaData(y, sel), d = new PdfDoc("Compta"), M = d.M, R = d.W - M;
  d.text(M, d.y, "Compta " + y, {size:20, bold:true}); d.y -= 22;
  d.para("Regroupement indicatif pour remplir ta déclaration en ligne. Les chiffres viennent de l'appli : à contrôler avec tes justificatifs.", 9.5, 13);
  const bl = (S.cfg && S.cfg.bailleur) || ""; if (bl) d.para("Bailleur : " + bl, 10, 13);
  for (const x of C.D){ const b = S.biens.find(z => z.id === x.id) || {};
    d.h(bienName(x.id) + (b.regime ? " · " + b.regime : ""), 14); if (b.adresse) d.para(b.adresse, 9.5, 12);
    const line = (l, v, bold) => { d.need(16); d.text(M, d.y, l, {size:10, bold}); d.text(R, d.y, eur(v), {size:10, right:true, bold}); d.y -= 15; };
    line("Loyers", x.loyers); if (x.autres) line("Autres recettes", x.autres);
    d.y -= 4; d.text(M, d.y, "Charges par poste", {size:10, bold:true, color:"#5C6B66"}); d.y -= 15;
    for (const p of x.postes) line(p.n, p.v); line("Total charges", x.charges, true);
    d.y -= 4; d.text(M, d.y, "Emprunt", {size:10, bold:true, color:"#5C6B66"}); d.y -= 15;
    if (x.ey){ const e = x.ey.e; d.para(eur(e.capital) + " à " + String(e.taux).replace(".", ",") + " % sur " + e.duree + " mois, 1re échéance le " + frDate(e.debut), 9.5, 12);
      line("Intérêts de l'année", x.ey.it); line("Capital remboursé", x.ey.kap); line("Assurance emprunteur", x.ey.assur); line("Capital restant dû fin " + y, x.ey.crd);
    } else d.para("Non renseigné.", 9.5, 12);
    d.y -= 4; d.line(M, d.y + 8, R, d.y + 8); line("Résultat (loyers − charges − intérêts − assurance)", x.resultat, true); }
  sitePdf(d, C);
  return d.finish("Compta " + y);
}

/* ---------- Pages « comme sur le site » : Logements, Échéances, Dépenses, Recettes ---------- */
function cmpMerge(rows){
  if (!V.cgrp) return rows;
  const m = new Map();
  for (const r of rows){ const key = r.immo ? "i|" + r.k : r.bien + "|" + r.art, o = m.get(key);
    if (!o) m.set(key, Object.assign({}, r, {n:1, first:r.date}));
    else { o.k += "," + r.k; o.montant = r2(o.montant + r.montant); o.n++; o.done = o.done && r.done; o.pointe = o.pointe && r.pointe; if (r.date > o.date) o.date = r.date; if (r.date < o.first) o.first = r.date; } }
  return [...m.values()].map(o => o.n > 1 ? Object.assign(o, {com:o.n + " lignes du " + frDate(o.first) + " au " + frDate(o.date)}) : o);
}
function cmpDepLines(y, ids){
  const rows = [];
  for (const j of J()){ if (j.type !== "Dépense" || yr(j) !== y || !ids.includes(j.bien) || j.compte === "Perso" || j.cat === "Crédit (mensualité)") continue;
    const art = artOf(j.cat); rows.push({k:"j:" + j.id, bien:j.bien, art, com:(j.lib || j.cat) + (j.fourn ? " - " + j.fourn : ""), montant:j.montant, date:j.date, immo:isImmoArt(art), done:!!j.compta, pointe:j.pointe === "x"}); }
  for (const id of ids){ const ey = empYear(id, y); if (ey && ey.assur > 0) rows.push({k:"a|" + id + "|" + y, bien:id, art:"Assurance emprunteur", com:"Assurance emprunteur " + y + " (" + ey.nb + " mois)", montant:ey.assur, date:y + "-12-31", immo:false, done:cdone("a|" + id + "|" + y), pointe:true}); }
  return cmpMerge(rows.sort((a, b) => a.bien.localeCompare(b.bien) || a.date.localeCompare(b.date)));
}
function cmpRecLines(y, ids){
  const rows = [];
  for (const j of J()){ if (j.type !== "Recette" || yr(j) !== y || !ids.includes(j.bien)) continue;
    if (j.cat === "Loyer"){ const t = tenantFor(j.bien, j.date), chg = r2(Math.min(N(t && t.charges), j.montant));
      rows.push({k:"j:" + j.id, bien:j.bien, art:"Loyer hors charges locatives", com:j.lib || "Loyer", montant:r2(j.montant - chg), date:j.date, done:!!j.compta, pointe:j.pointe === "x"});
      if (chg > 0) rows.push({k:"j:" + j.id, bien:j.bien, art:"Provision pour charges", com:j.lib || "Loyer", montant:chg, date:j.date, done:!!j.compta, pointe:j.pointe === "x"}); }
    else rows.push({k:"j:" + j.id, bien:j.bien, art:"À classer à la main", com:j.lib || j.cat, montant:j.montant, date:j.date, done:!!j.compta, pointe:j.pointe === "x"}); }
  return cmpMerge(rows.sort((a, b) => a.bien.localeCompare(b.bien) || a.date.localeCompare(b.date)));
}
function cmpEchLines(y, ids){
  const rows = [];
  for (const id of ids){ const e = empOf(id); if (!e) continue; const A = amort(e), day = e.debut.slice(8, 10);
    for (const r of A.rows) if (r.y === y) rows.push({k:"e|" + id + "|" + y + "-" + pad(r.m + 1), bien:id, date:y + "-" + pad(r.m + 1) + "-" + day, total:r.mens, kap:r.kap, it:r.it, frais:0, crd:r.crd, done:cdone("e|" + id + "|" + y + "-" + pad(r.m + 1))}); }
  return rows;
}
const cmpGroup = (rows, f) => { const ids = [...new Set(rows.map(r => r.bien))]; return ids.map(id => f(id, rows.filter(r => r.bien === id))).join(""); };
const cmpJ = r => r.k.split(",").every(k => k.startsWith("j:"));
const cmpChk = r => cmpJ(r) ? `<button class="chk ${r.pointe ? "on" : ""}" data-act="cmp-pt" data-k="${esc(r.k)}" aria-label="Payé ou encaissé (comme dans Pointage)">${ICON.check}</button>` : `<span class="chk on" style="opacity:.45"></span>`;
const cmpSaisi = r => `<button class="chip ${r.done ? "ok" : ""}" style="border:0;cursor:pointer" data-act="cmp-tog" data-k="${esc(r.k)}">${r.done ? "Saisi sur le site" : "À saisir"}</button>`;
function cmpProg(rows, pt){ const n = rows.length, d = rows.filter(r => r.done).length, p = rows.filter(r => r.pointe).length; return `<div class="small muted">${pt ? p + " / " + n + " " + pt + " · " : ""}${d} / ${n} saisie(s) sur le site</div>`; }
function cmpSite(sub, ids, y){
  if (sub === "log"){
    return `<div class="card"><h2>Logements (comme sur le site)</h2><div class="small muted">À renseigner une seule fois dans Dossier > Logements. Les composants d'amortissement sont proposés par le site selon le prix.</div></div>` +
      ids.map(id => { const b = S.biens.find(x => x.id === id) || {}, l = b.lmnp || {};
        return `<div class="card"><div class="top">${bienPill(id)}<button class="mini" data-act="lmnp-open" data-id="${esc(id)}">Modifier</button></div>
          ${kv("Adresse", esc(b.adresse || "à renseigner"))}${kv("Date de mise en location", l.miseLoc ? frDate(l.miseLoc) : "à renseigner")}${kv("Prix d'acquisition", l.prix ? eur(l.prix) : "à renseigner")}${kv("Régime", esc(b.regime || "-"))}
          ${empOf(id) ? kv("Emprunt : date de déblocage", (empOf(id).fonds ? frDate(empOf(id).fonds) : "à renseigner")) : ""}</div>`; }).join("");
  }
  if (sub === "emp"){
    const rows = cmpEchLines(y, ids);
    return `<div class="card"><h2>Échéances d'emprunt ${y}</h2><div class="small muted">Le site demande chaque échéance (date, total, capital, intérêts, frais de dossier). Compare avec l'échéancier de ta banque : si un montant diffère, garde celui de la banque.</div>${cmpProg(rows)}</div>` +
      (rows.length ? cmpGroup(rows, (id, L) => `<div class="card"><div class="top">${bienPill(id)}<span class="small muted">restant dû fin ${y} : ${eur(L[L.length - 1].crd)}</span></div><div class="rows">${L.map(r => `<div class="row">${cmpChk(r)}<div class="main"><div class="t">${frDate(r.date)} · total ${eur(r.total)}</div><div class="s">capital ${eur(r.kap)} · intérêts ${eur(r.it)} · frais 0 € ${cmpSaisi(r)}</div></div></div>`).join("")}</div>
          <div class="kv tot"><span>Total année</span><span class="num">${eur(r2(sum(L.map(r => r.total))))}</span></div>${kv("dont intérêts", eur(r2(sum(L.map(r => r.it)))), "muted")}</div>`)
        : `<div class="card"><div class="empty">Aucun emprunt renseigné pour cette année. Renseigne-le dans Synthèse.</div></div>`);
  }
  if (sub === "dep" || sub === "rec"){
    const rows = sub === "dep" ? cmpDepLines(y, ids) : cmpRecLines(y, ids), dep = sub === "dep";
    return `<div class="card"><div class="top"><h2>${dep ? "Dépenses" : "Recettes"} ${y} (comme sur le site)</h2>${dep ? `<button class="mini" data-act="map-open">Articles</button>` : ""}</div>
      <div class="seg"><button class="${V.cgrp ? "" : "on"}" data-act="cgrp" data-v="0">Détail</button><button class="${V.cgrp ? "on" : ""}" data-act="cgrp" data-v="1">Regrouper par article</button></div>
      <div class="small muted">${dep ? "Une ligne par facture : logement, article, commentaire, montant, date, immobilisation. Touche le rond quand c'est saisi sur le site." : "Loyer hors charges et provision pour charges sont séparés, avec la date d'encaissement."}</div>${cmpProg(rows, dep ? "payées" : "encaissées")}<div class="small muted">Le rond = payé / encaissé (le même que dans Pointage). « À saisir » passe à « Saisi sur le site » quand tu l'as recopié.</div></div>` +
      (rows.length ? cmpGroup(rows, (id, L) => `<div class="card"><div class="top">${bienPill(id)}<span class="num">${eur(r2(sum(L.map(r => r.montant))))}</span></div><div class="rows">${L.map(r => `<div class="row">${cmpChk(r)}<div class="main"><div class="t">${esc(r.art)}${r.immo ? ' <span class="chip warn">immobilisation</span>' : ""}</div><div class="s">${frDate(r.date)} · ${esc(r.com)}${r.pointe ? "" : " · pas encore " + (dep ? "payé" : "encaissé")} ${cmpSaisi(r)}</div></div><div class="amt num">${eur(r.montant)}</div></div>`).join("")}</div></div>`)
        : `<div class="card"><div class="empty">Rien pour cette année.</div></div>`);
  }
  return "";
}
function sheetLmnp(id){
  const b = S.biens.find(x => x.id === id) || {}, l = b.lmnp || {};
  openSheet(`<h2>${esc(bienName(id))} · infos du site</h2>
    <label class="f">Date de mise en location<input id="lm-loc" type="date" value="${l.miseLoc || ""}"></label>
    <label class="f">Prix d'acquisition (€)<input id="lm-prix" inputmode="decimal" value="${l.prix ? fmtNum(l.prix) : ""}"></label>
    <div class="small muted">L'adresse se change dans « Modifier le bien ». Ces infos restent sur ton téléphone.</div>
    <div class="btns"><button class="btn" style="flex:1" data-act="lmnp-save" data-id="${esc(id)}">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function sheetMap(){
  const cats = [...new Set(J().filter(j => j.type === "Dépense" && j.cat !== "Crédit (mensualité)").map(j => j.cat))].sort();
  openSheet(`<h2>Articles du site</h2><div class="small muted">Choisis l'article du site pour chaque catégorie de l'appli. Les changements ne touchent aucune donnée.</div>
    ${cats.map((c, i) => `<label class="f">${esc(c)}<select data-map="${esc(c)}">${SITE_ART.map(a => `<option ${a === artOf(c) ? "selected" : ""}>${esc(a)}</option>`).join("")}</select></label>`).join("")}
    <div class="btns"><button class="btn" style="flex:1" data-act="map-save">Enregistrer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function siteSheets(C, add, money, dt){
  const ids = C.ids, y = C.y, eL = cmpEchLines(y, ids), dL = cmpDepLines(y, ids), rL = cmpRecLines(y, ids);
  add("Site - Logements", [["Logement", "Adresse", "Date de mise en location", "Prix", "Régime", "Date de déblocage de l'emprunt"]].concat(ids.map(id => { const b = S.biens.find(x => x.id === id) || {}, l = b.lmnp || {}; return [bienName(id), b.adresse || "", l.miseLoc ? dt(l.miseLoc) : "", l.prix || "", b.regime || "", empOf(id) && empOf(id).fonds ? dt(empOf(id).fonds) : ""]; })), [22, 36, 20, 14, 10, 24], k => (k[0] === "C" || k[0] === "F") && +k.slice(1) > 1 ? "dd/mm/yyyy" : (k[0] === "D" && +k.slice(1) > 1 ? money : null));
  add("Site - Echéances", [["Logement", "Date", "Total échéance", "Capital", "Intérêts", "Frais de dossier", "Capital restant dû", "Saisi"]].concat(eL.map(r => [bienName(r.bien), dt(r.date), r.total, r.kap, r.it, 0, r.crd, r.done ? "x" : ""])), [22, 12, 14, 12, 12, 14, 18, 8], k => k[0] === "B" && +k.slice(1) > 1 ? "dd/mm/yyyy" : (/^[C-G]/.test(k) && +k.slice(1) > 1 ? money : null));
  add("Site - Dépenses", [["Logement", "Article", "Commentaire", "Montant", "Date de facture", "Immobilisation", "Saisi"]].concat(dL.map(r => [bienName(r.bien), r.art, r.com, r.montant, dt(r.date), r.immo ? "Oui" : "Non", r.done ? "x" : ""])), [22, 44, 40, 14, 14, 14, 8], k => k[0] === "D" && +k.slice(1) > 1 ? money : (k[0] === "E" && +k.slice(1) > 1 ? "dd/mm/yyyy" : null));
  add("Site - Recettes", [["Logement", "Article", "Commentaire", "Montant", "Date d'encaissement", "Encaissé", "Saisi"]].concat(rL.map(r => [bienName(r.bien), r.art, r.com, r.montant, dt(r.date), r.pointe ? "x" : "", r.done ? "x" : ""])), [22, 32, 30, 14, 18, 10, 8], k => k[0] === "D" && +k.slice(1) > 1 ? money : (k[0] === "E" && +k.slice(1) > 1 ? "dd/mm/yyyy" : null));
}
function pdfTable(d, cols, rows){
  const M = d.M; let x = M; const xs = cols.map(c => { const v = x; x += c.w; return v; });
  const at = (i, c) => c.right ? xs[i] + c.w - 4 : xs[i];
  const head = () => { d.need(34); cols.forEach((c, i) => d.text(at(i, c), d.y, c.t, {size:8.5, bold:true, color:"#5C6B66", right:c.right})); d.y -= 4; d.line(M, d.y, d.W - M, d.y); d.y -= 12; };
  head();
  for (const r of rows){ if (d.y - 16 < 60){ d.newPage(); head(); }
    cols.forEach((c, i) => { let s = String(r[i] == null ? "" : r[i]); if (pdfW(s, 8.5) > c.w - 6){ while (s.length > 1 && pdfW(s + "…", 8.5) > c.w - 6) s = s.slice(0, -1); s += "…"; } d.text(at(i, c), d.y, s, {size:8.5, right:c.right}); });
    d.y -= 13; }
  d.y -= 6;
}
function sitePdf(d, C){
  const ids = C.ids, y = C.y, M = d.M, ck = r => r.done ? "[x]" : "[  ]";
  d.newPage(); d.text(M, d.y, "À saisir sur ton site de compta", {size:16, bold:true, color:"#0E6B5C"}); d.y -= 20;
  d.para("Dans l'ordre du site : Logements, Emprunts et échéances, Dépenses, Recettes. Coche chaque ligne une fois saisie.", 9.5, 13);
  d.h("1. Logements", 12);
  pdfTable(d, [{t:"Logement", w:110}, {t:"Adresse", w:190}, {t:"Mise en location", w:80}, {t:"Prix", w:70, right:true}, {t:"Régime", w:61}], ids.map(id => { const b = S.biens.find(x => x.id === id) || {}, l = b.lmnp || {}; return [bienName(id), b.adresse || "à renseigner", l.miseLoc ? frDate(l.miseLoc) : "à renseigner", l.prix ? eur(l.prix) : "", b.regime || ""]; }));
  d.h("2. Emprunts : échéances " + y, 12);
  const eL = cmpEchLines(y, ids); if (!eL.length) d.para("Aucun emprunt renseigné.", 9.5, 13);
  for (const id of [...new Set(eL.map(r => r.bien))]){ const L = eL.filter(r => r.bien === id), e = empOf(id);
    d.para(bienName(id) + " - déblocage des fonds : " + (e.fonds ? frDate(e.fonds) : "à renseigner") + " - capital restant dû fin " + y + " : " + eur(L[L.length - 1].crd), 9.5, 13);
    pdfTable(d, [{t:"Fait", w:34}, {t:"Date", w:80}, {t:"Total échéance", w:100, right:true}, {t:"Capital", w:100, right:true}, {t:"Intérêts", w:100, right:true}, {t:"Frais", w:97, right:true}], L.map(r => [ck(r), frDate(r.date), eur(r.total), eur(r.kap), eur(r.it), eur(0)]).concat([["", "Total", eur(r2(sum(L.map(r => r.total)))), eur(r2(sum(L.map(r => r.kap)))), eur(r2(sum(L.map(r => r.it)))), ""]])); }
  d.h("3. Dépenses " + y, 12);
  const dL = cmpDepLines(y, ids);
  for (const id of ids){ const L = dL.filter(r => r.bien === id); if (!L.length) continue; d.para(bienName(id), 10, 13);
    pdfTable(d, [{t:"Fait", w:30}, {t:"Article", w:150}, {t:"Commentaire", w:158}, {t:"Montant", w:68, right:true}, {t:"Date", w:64}, {t:"Immo.", w:41}], L.map(r => [ck(r), r.art, r.com, eur(r.montant), frDate(r.date), r.immo ? "Oui" : "Non"]).concat([["", "Total", "", eur(r2(sum(L.map(r => r.montant)))), "", ""]])); }
  d.h("4. Recettes " + y, 12);
  const rL = cmpRecLines(y, ids);
  for (const id of ids){ const L = rL.filter(r => r.bien === id); if (!L.length) continue; d.para(bienName(id), 10, 13);
    pdfTable(d, [{t:"Fait", w:30}, {t:"Article", w:170}, {t:"Commentaire", w:158}, {t:"Montant", w:80, right:true}, {t:"Date", w:73}], L.map(r => [ck(r), r.art, r.com, eur(r.montant), frDate(r.date)]).concat([["", "Total", "", eur(r2(sum(L.map(r => r.montant)))), ""]])); }
  d.para("Document établi par l'appli à partir de tes saisies : à comparer avec tes justificatifs et l'échéancier de ta banque avant de valider sur le site.", 8.5, 12);
}

document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a){
    case "csub": V.csub = v; render(); break;
    case "cgrp": V.cgrp = v === "1"; render(); break;
    case "lmnp-open": sheetLmnp(id); break;
    case "lmnp-save": { const bn = S.biens.find(x => x.id === id); if (!bn) break; bn.lmnp = {miseLoc:$("#lm-loc").value, prix:parseNum($("#lm-prix").value) || 0}; bn.upd = Date.now(); persist(); closeSheet(); toast("Enregistré"); render(); break; }
    case "map-open": sheetMap(); break;
    case "map-save": { S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.cmap = S.cfg.cmap || {}; document.querySelectorAll("#sheet [data-map]").forEach(sel => { const c = sel.dataset.map; if (sel.value === ART_DEFAULT[c]) delete S.cfg.cmap[c]; else S.cfg.cmap[c] = sel.value; }); persist(); closeSheet(); toast("Articles enregistrés"); render(); break; }
    case "cmp-pt": { const ks = b.dataset.k.split(","), on = b.classList.contains("on"); for (const k of ks){ const j = S.journal.find(x => x.id === k.slice(2)); if (j && (j.pointe === "x") === on){ j.pointe = on ? "" : "x"; j.upd = Date.now(); onPointe(j); } } persist(); render(); break; }
    case "cmp-tog": { const ks = b.dataset.k.split(","), on = b.classList.contains("ok");
      for (const k of ks){ if (k.startsWith("j:")){ const j = S.journal.find(x => x.id === k.slice(2)); if (j){ j.compta = on ? "" : "x"; j.upd = Date.now(); } }
        else { S.cfg = S.cfg || {bailleur:"", adr:{}}; S.cfg.cdone = S.cfg.cdone || {}; if (on) delete S.cfg.cdone[k]; else S.cfg.cdone[k] = 1; } }
      persist(); render(); break; }
    case "csel": V.csel = v; render(); break;
    case "emp-open": sheetEmprunt(id); break;
    case "emp-save": { const bn = S.biens.find(x => x.id === id); if (!bn) break;
      const e = {capital:parseNum($("#em-cap").value) || 0, taux:parseNum($("#em-taux").value) || 0, duree:Math.round(parseNum($("#em-dur").value) || 0), debut:$("#em-deb").value, fonds:$("#em-fonds").value, assur:parseNum($("#em-ass").value) || 0};
      if (!(e.capital > 0 && e.duree > 0 && e.debut)) return toast("Capital, durée et date sont nécessaires");
      bn.emprunt = e; bn.upd = Date.now(); persist(); closeSheet(); toast("Emprunt enregistré"); render(); break; }
    case "ck-docx": checklistDocx(V.y, V.csel === "all" ? bienIds() : [V.csel]); break;
    case "ck-imp": importChecklist(); break;
    case "ck-open": sheetCheck(); break;
    case "ck-save": { const cats = {}; document.querySelectorAll(".ck-cat").forEach(x => { if (x.value) cats[x.dataset.c] = x.value; });
      S.check = {rec:$("#ck-rec").checked, int:$("#ck-int").checked, cats}; persist(); closeSheet(); toast("Liste enregistrée"); render(); break; }
    case "ck-reset": delete S.check; persist(); closeSheet(); toast("Liste de départ remise"); render(); break;
    case "emp-del": { const bn = S.biens.find(x => x.id === id); if (bn) delete bn.emprunt; persist(); closeSheet(); render(); break; }
    case "cmp-xlsx": saveFile("compta-" + V.y + ".xlsx", comptaXlsx(V.y, V.csel || "all"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); break;
    case "cmp-pdf": saveFile("compta-" + V.y + ".pdf", comptaPdf(V.y, V.csel || "all"), "application/pdf"); break;
  }
});

/* ---------- Placements (livret A, PEL, bourse…), matelas et argent utilisable ---------- */
const PLACE_CATS = ["Bourse", "Livret A", "PEL", "Autre placement"], CAT_INT = "Intérêts placement";
function placeOf(id){
  const L = J().filter(j => (id == null || j.bien === id) && (PLACE_CATS.includes(j.cat) || j.cat === CAT_INT)), by = {};
  for (const c of PLACE_CATS){ const l = L.filter(j => j.cat === c); by[c] = r2(sum(l.filter(j => j.type === "Sortie").map(j => j.montant)) - sum(l.filter(j => j.type === "Entrée").map(j => j.montant))); }
  const interets = r2(sum(L.filter(j => j.cat === CAT_INT).map(j => j.montant))), net = r2(sum(Object.values(by)));
  return {by, interets, net, total:r2(net + interets)};
}
const matMois = () => { const v = S.cfg && S.cfg.matMois; return v == null || isNaN(+v) ? 12 : Math.max(0, Math.min(36, Math.round(+v))); };
const resMois = () => { const v = S.cfg && S.cfg.resMois; return v == null || isNaN(+v) ? 3 : Math.max(1, Math.min(6, Math.round(+v))); };
function matelasOf(id){
  const t = todayIso(), loyer = suggest(id, "Loyer", t) || 0, mat = r2(matMois() * loyer), compte = soldeBien(id), pl = placeOf(id), total = r2(compte + pl.total);
  const lim = new Date(Date.now() + Math.round(resMois() * 30.4) * 864e5).toISOString().slice(0, 10);
  const pend = J().filter(j => j.bien === id && j.pointe !== "x" && j.date <= lim && j.compte !== "Perso");
  const dep = r2(sum(pend.filter(j => j.type === "Dépense").map(j => j.montant))), rec = r2(sum(pend.filter(j => j.type === "Recette").map(j => j.montant)));
  const reserve = r2(Math.max(0, dep - rec));
  return {loyer, mat, compte, place:pl.total, total, reserve, dep, rec, usable:r2(total - mat - reserve)};
}
function gaugeHtml(m){
  const max = Math.max(m.total, m.mat + m.reserve, 1), pc = v => Math.max(0, Math.min(100, v / max * 100)).toFixed(1);
  const a = Math.min(Math.max(m.total, 0), m.mat), b = Math.min(Math.max(m.total - m.mat, 0), m.reserve), c = Math.max(0, m.total - m.mat - m.reserve);
  return `<div class="mg" role="img" aria-label="Matelas, réserve et argent utilisable"><i style="width:${pc(a)}%;background:#3F6FB5"></i><i style="width:${pc(b)}%;background:#E8890C"></i><i style="width:${pc(c)}%;background:#1FA45B"></i></div>
    <div class="mgl"><span><b style="background:#3F6FB5"></b>Matelas ${eur(m.mat)}</span><span><b style="background:#E8890C"></b>Réservé ${eur(m.reserve)}</span><span><b style="background:#1FA45B"></b>Utilisable ${eur(Math.max(0, m.usable))}</span></div>`;
}
function matelasCard(id){
  const m = matelasOf(id), neg = m.usable < 0;
  return `<div class="card"><h2>Matelas et argent utilisable</h2>
    <div class="small muted">Utilisable aujourd'hui sans te mettre en difficulté</div><div class="big num ${neg ? "neg" : ""}" style="font-size:30px;font-weight:700">${neg ? "manque " + eur(-m.usable) : eur(m.usable)}</div>${gaugeHtml(m)}
    ${kv("Total du bien (compte + placé)", eur(m.total))}${kv("dont sur le compte", eur(m.compte), "muted")}${kv("dont placé (livret, bourse…)", eur(m.place), "muted")}
    ${kv("Matelas : " + matMois() + " mois de loyer (" + matMois() + " × " + eur(m.loyer) + ")", "− " + eur(m.mat))}${kv("Réservé : " + resMois() + " prochains mois", "− " + eur(m.reserve))}
    <div class="small muted">Le matelas ne se touche pas. Réservé = charges prévues dans les ${resMois()} mois moins loyers prévus (0 si les loyers couvrent). Le reste est utilisable.</div></div>`;
}
function matelasHome(){
  const ids = bienIds(); if (!ids.length) return "";
  const ms = ids.map(id => ({id, m:matelasOf(id)})), tot = r2(sum(ms.map(x => x.m.usable)));
  return `<div class="card"><h2>Argent utilisable</h2><div class="big num ${tot < 0 ? "neg" : ""}" style="font-size:30px;font-weight:700">${eur(tot)}</div>
    <div class="small muted">Au-dessus de ${matMois()} mois de loyer par bien, charges des ${resMois()} prochains mois déduites.</div>
    <details class="small muted" style="margin:4px 0"><summary style="cursor:pointer;font-weight:700">Comment c'est calculé ?</summary>
      <div style="margin-top:4px"><b>Argent utilisable</b> = ce que tu peux sortir ou placer sans te mettre en difficulté.<br>Pour chaque bien : <b>compte du bien + argent déjà placé</b> (livret, bourse…), moins le <b>matelas</b> (${matMois()} mois de loyer : on n'y touche pas, c'est ta sécurité en cas de loyers impayés ou de gros travaux), moins le <b>réservé</b> (charges prévues dans les ${resMois()} prochains mois, après déduction des loyers prévus). Le reste est utilisable.<br>Bleu = matelas, orange = réservé, vert = utilisable. Si c'est négatif, l'appli affiche « manque ».<br>Tu peux changer le nombre de mois dans Réglages › Matelas de sécurité. Rien n'est sorti de ton compte : c'est un repère.</div>
      <div class="btns" style="margin-top:6px"><button class="btn sm ghost" data-act="go" data-v="set">Régler le matelas</button></div></details>
    ${ms.map(x => `<button class="rowbtn" style="width:100%;text-align:left" data-act="go" data-v="bld" data-sub="vue" data-bien="${esc(x.id)}"><div class="kv">${bienPill(x.id)}<span class="num ${x.m.usable < 0 ? "neg" : ""}">${eur(x.m.usable)}</span></div>${gaugeHtml(x.m)}</button>`).join("")}</div>`;
}
const usedTypes = id => PLACE_CATS.filter(c => J().some(j => j.cat === c && (id == null || j.bien === id)));
const titleTypes = ty => ty.length < 2 ? (ty[0] || "Bourse") : ty.slice(0, -1).join(", ") + " et " + ty[ty.length - 1];
function placeCard(id){
  const p = placeOf(id), rows = [];
  if (!p.interets && !(id && usedTypes(id).length)) return "";
  return `<div class="card"><div class="top"><h2>${id ? "Intérêts des placements" : "Intérêts gagnés (tous les biens)"}</h2>${id ? `<button class="btn sm" data-act="int-add" data-id="${esc(id)}">Ajouter des intérêts</button>` : ""}</div>
    <div class="kv tot"><span>Intérêts gagnés</span><span class="num pos">${eur(p.interets)}</span></div>
    <div class="small muted">L'argent placé reste compté dans le total du bien. Les intérêts sont notés à part : c'est ce que ton bien te fait gagner en plus.</div></div>`;
}
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b || b.dataset.act !== "int-add") return;
  const bien = b.dataset.id; V.back = "bld"; V.bsub = "vue"; V.bsel = bien; V.editId = null; V.draft = newDraft({type:"Entrée", bien, cat:CAT_INT, lib:"Intérêts", pt:true}); V.tab = "add"; render();
});
