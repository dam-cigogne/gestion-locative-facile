/* ============ Démarrage ============ */
const migrate = () => { if (!S.cfg || typeof S.cfg !== "object") S.cfg = {bailleur:"", adr:{}}; if (!Array.isArray(S.modeles)) S.modeles = []; if (!Array.isArray(S.clotures)) S.clotures = []; if (!S.rapp || typeof S.rapp !== "object") S.rapp = {}; for (const k of ["biens","tarifs","journal","factures","locataires","seen","partages","edl","inv","docs"]) if (!Array.isArray(S[k])) S[k] = []; };
function startApp(){
  S = load();
  if (!S || !Array.isArray(S.journal)){ S = emptyData(); persist(); }
  migrate(); render(); bootRoutines();
}
if ("serviceWorker" in navigator && location.protocol.indexOf("http") === 0) { try { navigator.serviceWorker.register("sw.js").catch(() => {}); } catch(e){} }
window.HAD_DATA = !!(lsGet(KEY) || lsGet(ENC));
secCfgLoad();
faceOK().then(v => { V.faceOK = v; });
if (secAvailable() && lsGet(ENC)){ SEC.on = true; showLock(); } else startApp();
