/* ============ Reprendre une liste depuis un PDF ou un texte collé (inventaire, état des lieux) ============ */
const PDFJS_V = "3.11.174", PDFJS_URL = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/" + PDFJS_V + "/pdf.min.js", PDFJS_WK = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/" + PDFJS_V + "/pdf.worker.min.js";
let PDFJS_P = null;
function loadPdfJs(){
  if (window.pdfjsLib && window.pdfjsLib.__ready) return Promise.resolve(window.pdfjsLib);
  return PDFJS_P || (PDFJS_P = new Promise((res, rej) => {
    const s = document.createElement("script"); s.src = PDFJS_URL;
    s.onload = () => { try { window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WK; window.pdfjsLib.__ready = true; res(window.pdfjsLib); } catch(e){ PDFJS_P = null; rej(e); } };
    s.onerror = () => { PDFJS_P = null; rej(new Error("lecteur PDF indisponible (connexion ?)")); }; document.head.appendChild(s); }));
}
const TESS_URL = "https://cdnjs.cloudflare.com/ajax/libs/tesseract.js/5.1.1/tesseract.min.js", TESS_WK = "https://cdnjs.cloudflare.com/ajax/libs/tesseract.js/5.1.1/worker.min.js", TESS_CORE = "https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1/", TESS_LANG = "https://cdn.jsdelivr.net/npm/@tesseract.js-data/fra/4.0.0_best_int";
let TESS_P = null, OCR_USED = false;
function loadTess(){
  if (window.Tesseract) return Promise.resolve(window.Tesseract);
  return TESS_P || (TESS_P = new Promise((res, rej) => { const s = document.createElement("script"); s.src = TESS_URL; s.onload = () => res(window.Tesseract); s.onerror = () => { TESS_P = null; rej(new Error("lecture optique indisponible (connexion ?)")); }; document.head.appendChild(s); }));
}
/* Document scanné : on dessine chaque page puis on reconnaît le texte sur l'appareil (aucun envoi du document). */
async function ocrPdf(doc){
  const T = await loadTess(), out = [], n = Math.min(doc.numPages, 10);
  toast("Lecture du scan… (premier chargement : un peu long)");
  const w = await T.createWorker("fra", 1, {workerPath:TESS_WK, corePath:TESS_CORE, langPath:TESS_LANG});
  try {
    for (let i = 1; i <= n; i++){
      toast("Lecture du scan : page " + i + " sur " + n);
      const pg = await doc.getPage(i), vp = pg.getViewport({scale:2}), cv = document.createElement("canvas"); cv.width = vp.width; cv.height = vp.height;
      await pg.render({canvasContext:cv.getContext("2d"), viewport:vp}).promise;
      const r = await w.recognize(cv); r.data.text.split(/\r?\n/).forEach(l => { l = l.replace(/[|_]+/g, " ").replace(/\s+/g, " ").trim(); if (l) out.push(l); });
    }
  } finally { try { await w.terminate(); } catch(e){} }
  OCR_USED = true; return out;
}
async function pdfLines(buf){
  OCR_USED = false;
  const lib = await loadPdfJs(), doc = await lib.getDocument({data:new Uint8Array(buf.slice(0))}).promise, out = [];
  for (let n = 1; n <= doc.numPages && n <= 40; n++){
    const tc = await (await doc.getPage(n)).getTextContent(), rows = [];
    for (const it of tc.items){ if (!it.str || !it.str.trim()) continue; const y = Math.round(it.transform[5] / 3); let r = rows.find(q => Math.abs(q.y - y) <= 1); if (!r) rows.push(r = {y, c:[]}); r.c.push({x:it.transform[4], w:it.width || 0, s:it.str.trim()}); }
    rows.sort((a, b) => b.y - a.y).forEach(r => { r.c.sort((a, b) => a.x - b.x); let line = "", end = null; for (const c of r.c){ line += (end === null ? "" : (c.x - end > 18 ? " ; " : " ")) + c.s; end = c.x + c.w; } out.push(line); });
  }
  if (out.join("").length < 30) return await ocrPdf(doc);
  return out;
}
/* Lit un texte libre : « Lit ; 1 ; Bon ; rayure », « 4 chaises », « Cuisine : » (= titre de groupe). */
const ETAT_W = /^(neuf|neuve|bon|bonne|moyen|moyenne|mauvais|mauvaise|usagée?|usé|usée|passable|parfait|parfaite|correct|ok|hs)$/i;
function parseList(text){
  let lines = String(text || "").split(/\r?\n/);
  const start = lines.findIndex(l => /liste des meubles|^\s*[eé]l[eé]ment\b/i.test(l)); if (start >= 0) lines = lines.slice(start + 1);
  const tabular = lines.filter(l => /\s(neuf|bon|moyen|mauvais|usag[eé]e?)\s*$/i.test(l.replace(/état\s+d['’]usure/ig, "usagé").replace(/\bbon\s+[eé]tat\b/ig, "bon"))).length >= 8;
  const out = []; let grp = "Importé";
  for (let raw of lines){
    let line = raw.replace(/^[\s•\-–*·]+/, "").trim(); if (!line || /^page\s*\d+/i.test(line) || /paraphes|^el[ée]ment\b|^liste des meubles|signature|exemplaires|certifi/i.test(line) || line.length > 160) continue;
    line = line.replace(/[eé]tat\s+d['’]usure/ig, "usagé").replace(/\bbon\s+[eé]tat\b/ig, "bon").replace(/\b(neuf|bon|moyen|mauvais)\s+[eé]tat\b/ig, "$1");
    if (/:$/.test(line)){ grp = line.replace(/:$/, "").trim() || grp; continue; }
    if (/^[A-ZÉÈÊÀÂÎÔÛÇ' \/-]{3,28}$/.test(line) && !/\d/.test(line)){ grp = line.charAt(0) + line.slice(1).toLowerCase(); continue; }
    const parts = line.split(/\s*;\s*|\t+/).map(x => x.trim()).filter(Boolean); let nom = "", qte = "", etat = "", com = [];
    for (const p of parts){
      const tk = p.split(/\s+/); let e2 = "", q2 = "";
      if (tk.length > 1 || parts.length > 1){
        if (tk.length && ETAT_W.test(tk[tk.length - 1].replace(/[!|.,:;)\]]+$/, ""))){ e2 = normEtat(tk.pop().replace(/[!|.,:;)\]]+$/, "")) || "Bon"; }
        if (tk.length && /^\d{1,3}[!|.,:;]?$/.test(tk[tk.length - 1]) && (tk.length > 1 || parts.length > 1)){ q2 = tk.pop().replace(/\D/g, ""); }
      }
      if (e2 && !etat) etat = e2; if (q2 && !qte) qte = q2;
      const rest = tk.join(" ").trim(); if (!rest) continue;
      if (!qte && /^\d{1,3}$/.test(rest)){ qte = rest; continue; }
      if (!nom){ const m = /^(\d{1,3})\s*[x×]?\s+(.+)$/i.exec(rest); if (m && !qte){ qte = m[1]; nom = m[2]; } else nom = rest; } else com.push(rest);
    }
    if (!nom) continue;
    if (tabular && !etat && !qte){
      if (!/\d/.test(nom) && nom.split(/\s+/).length <= 3 && /^[A-ZÉÈÊÀ]/.test(nom) && !/[()]/.test(nom)){ grp = nom; continue; }
      if (out.length){ const l = out[out.length - 1]; l.com = (l.com ? l.com + " " : "") + nom; } continue; }
    out.push({id:uid(), grp, nom, qte:qte || "1", etat, com:com.join(" · ")});
    if (out.length >= 400) break;
  }
  return out;
}
/* Sortie créée directement depuis un fichier d'entrée choisi dans la fenêtre « Nouvelle sortie » */
async function dxCreateFromFile(kind, f){
  const date = dxV("dx-date") || todayIso(), loc = dxV("dx-loc"), edate = dxV("dx-edate") || date, bien = V.bsel;
  if (f.size > 25e6) return toast("Fichier trop gros (25 Mo maximum)");
  try {
    const buf = await f.arrayBuffer(), fid = uid(), type = f.type || mimeOf(f.name);
    await flPut(fid, {name:f.name, type, buf});
    docList("docs").push({id:fid, bien, kind, nom:"Entrée · " + f.name, sub:"", fname:f.name, date:edate, type, size:f.size, upd:Date.now()});
    let items = null, pieces = null;
    if (/\.(xlsx|xls|csv)$/i.test(f.name)){ const it = invFromSheet(buf, f.name);
      if (it && it.length){ if (kind === "inv") items = it; else { const map = {}; pieces = []; it.forEach(x => { let p = map[x.grp]; if (!p){ map[x.grp] = p = {id:uid(), nom:x.grp, items:[]}; pieces.push(p); } p.items.push({id:uid(), nom:x.nom, etat:x.etat, com:x.com, ph:[]}); }); } } }
    const eid = uid(), base = {id:eid, bien, type:"entree", date:edate, loc, rem:"", ref:"", fichier:fid, upd:Date.now()};
    const entree = kind === "inv" ? Object.assign(base, {items:items || INV_DEF.flatMap(([g, L]) => L.map(n => ({id:uid(), grp:g, nom:n, qte:"1", etat:"", com:""})))})
      : Object.assign(base, {elec:"", eau:"", gaz:"", cles:"", fumee:"", pieces:pieces || EDL_PIECES.map(p => mkPiece(p[0], p[1]))});
    docList(kind).push(entree); persist();
    if (items || pieces){ closeSheet(); dxMake(kind, "sortie", date, loc, entree, null); toast("Entrée lue : version de sortie créée"); return; }
    V.after = {kind, date, loc};
    let lines = [], note = "";
    try { if (/\.(pdf)$/i.test(f.name)) lines = await pdfLines(buf); else if (/\.txt$/i.test(f.name)) lines = new TextDecoder("utf-8").decode(new Uint8Array(buf)).split(/\r?\n/); } catch(e){ note = "Lecture du PDF impossible (" + e.message + ")."; }
    if (!note) note = lines.length ? (OCR_USED ? "Texte reconnu sur le scan (lecture optique, rarement parfaite) : relis chaque ligne. " : "") + "Corrige puis valide : la version de sortie sera créée ensuite." : "Aucun texte reconnu dans ce document. Colle ici la liste, ou envoie le fichier à Claude pour obtenir un Excel/CSV à importer.";
    sheetBulk(kind, eid, lines.join("\n"), true, note);
  } catch(err){ toast("Import impossible : " + err.message); }
}
function sheetBulk(kind, id, text, replace, note){
  V.bulk = {kind, id, replace:!!replace};
  openSheet(`<h2>${kind === "inv" ? "Liste du mobilier" : "Pièces et éléments"} à reprendre</h2>
    <div class="info">${esc(note || "Colle ou saisis une ligne par élément. Un titre de groupe se termine par « : ». Tu peux écrire « 4 chaises », ou « Lit ; 1 ; Bon ; remarque ».")}</div>
    <label class="f">Texte<textarea id="bk-txt" rows="12" style="font-size:14px">${esc(text || "")}</textarea></label>
    <div class="small muted" id="bk-n"></div>
    <div class="btns"><button class="btn" style="flex:1" data-act="bulk-ok">${replace ? "Créer la liste" : "Ajouter à la liste"}</button><button class="btn ghost" data-act="sheetclose">${replace ? "Garder la liste type" : "Annuler"}</button></div>`);
}
async function bulkFromFile(kind, id, f, buf){
  let lines = [], note = "";
  try { if (/\.pdf$/i.test(f.name)) lines = await pdfLines(buf); else if (/\.(txt)$/i.test(f.name)) lines = new TextDecoder("utf-8").decode(new Uint8Array(buf)).split(/\r?\n/); } catch(e){ note = "Lecture du PDF impossible (" + e.message + "). Colle la liste à la main."; }
  if (!note) note = lines.length ? (OCR_USED ? "Texte reconnu sur le scan (lecture optique, rarement parfaite) : relis chaque ligne, corrige puis valide. " : "") + "Lignes lues dans ton document : corrige, supprime ce qui ne sert pas, puis valide. Le document original reste joint." : "Aucun texte lisible (document scanné ou photo). Ouvre-le depuis la fiche et recopie ou colle la liste ici.";
  sheetBulk(kind, id, lines.join("\n"), true, note);
}
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act;
  if (a === "bulk-open"){ V.after = null; if (V.doc) sheetBulk(V.doc.kind, V.doc.id, "", false); return; }
  if (a === "bulk-ok"){
    const bk = V.bulk, e = bk && docGet(bk.kind, bk.id); if (!e) return closeSheet();
    const items = parseList(($("#bk-txt") || {}).value); if (!items.length) return toast("Aucune ligne reconnue");
    if (bk.blank) items.forEach(i => { i.etat = ""; i.com = ""; });
    if (bk.kind === "inv"){ e.items = bk.replace ? items : e.items.concat(items); }
    else { const L = bk.replace ? [] : e.pieces; for (const it of items){ let p = L.find(x => x.nom === it.grp); if (!p) L.push(p = {id:uid(), nom:it.grp, items:[]}); p.items.push({id:uid(), nom:it.nom, etat:it.etat, com:it.com, ph:[]}); } e.pieces = L; }
    dxTouch(e); persist(); closeSheet(); toast(items.length + " ligne(s) reprise(s)");
    if (V.after && V.after.kind === bk.kind){ const a = V.after; V.after = null; V.bsub = "docs"; dxMake(bk.kind, "sortie", a.date, a.loc, e, null); } else render();
  }
});


/* ---------- Retranscrire un fichier en liste vierge (entrée) + modèle standard ---------- */
async function dxFromFileBlank(kind, f){
  const date = dxV("dx-date") || todayIso(), loc = dxV("dx-loc");
  if (f.size > 25e6) return toast("Fichier trop gros (25 Mo maximum)");
  try {
    const buf = await f.arrayBuffer();
    if (/\.(xlsx|xls|csv)$/i.test(f.name)){ const it = invFromSheet(buf, f.name);
      if (it && it.length){ let tpl;
        if (kind === "inv") tpl = {items:it.map(x => ({grp:x.grp, nom:x.nom, qte:x.qte}))};
        else { const map = {}, pieces = []; it.forEach(x => { let p = map[x.grp]; if (!p){ map[x.grp] = p = {nom:x.grp, items:[]}; pieces.push(p); } p.items.push({nom:x.nom}); }); tpl = {pieces}; }
        dxMake(kind, "entree", date, loc, null, tpl); toast(it.length + " ligne(s) recopiée(s), vierges"); return; }
      toast("Aucune ligne reconnue dans ce tableau : colle la liste à la main"); return; }
    let lines = [], note = "";
    try { if (/\.pdf$/i.test(f.name)) lines = await pdfLines(buf); else lines = new TextDecoder("utf-8").decode(new Uint8Array(buf)).split(/\r?\n/); } catch(e){ note = "Lecture impossible (" + e.message + "). Colle la liste à la main."; }
    dxMake(kind, "entree", date, loc, null, null); V.after = null; const id = V.doc && V.doc.id;
    if (!note) note = lines.length ? (OCR_USED ? "Texte reconnu sur le scan (lecture optique, rarement parfaite) : relis chaque ligne. " : "") + "Voici les lignes lues : corrige, supprime ce qui ne sert pas, puis valide. Les états seront laissés vides, à remplir à la visite." : "Aucun texte lisible dans ce document. Colle la liste ici.";
    sheetBulk(kind, id, lines.join("\n"), true, note); V.bulk.blank = true;
  } catch(err){ toast("Import impossible : " + err.message); }
}
document.addEventListener("click", ev => {
  const b = ev.target.closest("[data-act]"); if (!b || b.dataset.act !== "dx-model") return;
  const e = V.doc && docCur(); if (!e) return;
  if (!e.modele) for (const x of docList(V.doc.kind)) if (x.modele){ delete x.modele; x.upd = Date.now(); }
  if (e.modele) delete e.modele; else e.modele = true; e.upd = Date.now(); persist(); render();
  toast(e.modele ? "Ce document est ton modèle : il sera proposé en premier" : "Modèle retiré");
});
