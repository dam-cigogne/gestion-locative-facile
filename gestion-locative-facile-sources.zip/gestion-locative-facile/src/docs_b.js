/* ============ Documents : écrans (Biens › Documents), états des lieux, inventaires ============ */
const dxF = (id, label, val, ex) => `<label class="f">${label}<input id="${id}" value="${esc(val ?? "")}" ${ex || ""}></label>`;
const dxS = (id, label, opts, val) => `<label class="f">${label}<select id="${id}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(val) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
const dxV = id => { const e = $("#" + id); return e ? e.value.trim() : ""; };
const etatSel = (cur, attrs) => `<select ${attrs}><option value="">État…</option>${ETATS.map(x => `<option ${x === cur ? "selected" : ""}>${x}</option>`).join("")}</select>`;
const chipEtat = s => s ? `<span class="chip ${s === "Mauvais" ? "bad" : s === "Moyen" ? "warn" : "ok"}">${esc(s)}</span>` : "";

function viewDocs(){
  if (V.doc){ const e = docCur(); if (!e || e.bien !== V.bsel) V.doc = null; else return V.doc.kind === "edl" ? viewEdl(e) : viewInv(e); }
  const id = V.bsel, s = soldeLoc(id), by = k => docList(k).filter(x => x.bien === id && !x.del).sort((a, b) => b.date.localeCompare(a.date) || (b.upd || 0) - (a.upd || 0));
  const E = by("edl"), I = by("inv"), hist = s.L.slice(-12).reverse();
  const row = (k, e) => `<div class="row"><button class="rowbtn" data-act="dx-open" data-v="${k}" data-id="${e.id}"><div class="t">${e.type === "sortie" ? "Sortie" : "Entrée"} · ${frDate(e.date)}</div>
    <div class="s">${esc(e.loc || "locataire non précisé")} · ${k === "edl" ? e.pieces.reduce((a, p) => a + p.items.filter(i => i.etat).length, 0) + " élément(s) renseigné(s)" : e.items.filter(i => i.etat).length + "/" + e.items.length + " article(s) renseigné(s)"}</div></button><span class="chip ${e.type === "sortie" ? "warn" : "ok"}">${e.type === "sortie" ? "Sortie" : "Entrée"}${e.fichier ? " + doc" : ""}</span></div>`;
  return `<div class="card"><h2>Solde du locataire</h2>${s.t ? `<div class="small muted">${esc(s.t.nom)} · loyer ${eur(s.t.loyer)}${s.t.charges ? " dont charges " + eur(s.t.charges) : ""}</div>
      <div class="hero" style="margin:8px 0"><div class="small">${s.solde < -0.005 ? "Retard cumulé" : "Solde des loyers"}</div><div class="big num">${eur(s.solde)}</div><div class="small">Reçu ${eur(s.recu)} sur ${eur(s.du)} dus depuis le début du bail</div></div>
      <div class="rows">${hist.map(j => `<div class="row"><div class="main"><div class="t">${MOIS[mo(j)]} ${yr(j)}</div><div class="s">${eur(j.montant)}</div></div>${j.pointe === "x" ? '<span class="chip ok">Reçu</span>' : '<span class="chip bad">Non reçu</span>'}${j.pointe !== "x" ? `<button class="mini" data-act="relance" data-id="${j.id}">Relancer</button>` : ""}</div>`).join("") || '<div class="empty">Aucun loyer à ce jour.</div>'}</div>` : '<div class="empty">Ajoute d\'abord un locataire (onglet Locataires).</div>'}</div>
  <div class="card"><div class="top"><h2>États des lieux</h2></div><div class="small muted">Pièce par pièce, avec photos, puis PDF à faire signer.</div>
    <div class="btns"><button class="btn sm" data-act="dx-new" data-v="edl" data-t="entree">Nouvel état d'entrée</button><button class="btn sm ghost" data-act="dx-new" data-v="edl" data-t="sortie">État de sortie</button></div>
    <div class="btns"><button class="btn sm ghost" data-act="im-open" data-v="edl">Importer un état déjà fait</button></div>
    <div class="rows">${E.map(e => row("edl", e)).join("") || '<div class="empty">Aucun état des lieux pour ce bien.</div>'}${fileDocs(id, "edl").filter(d => !E.some(e => e.fichier === d.id)).map(fileRow).join("")}</div></div>
  ${bkind(id) === "vide" ? "" : `<div class="card"><div class="top"><h2>Inventaire du mobilier</h2></div><div class="small muted">Obligatoire pour un meublé : liste minimale du décret, à compléter.</div>
    <div class="btns"><button class="btn sm" data-act="dx-new" data-v="inv" data-t="entree">Nouvel inventaire d'entrée</button><button class="btn sm ghost" data-act="dx-new" data-v="inv" data-t="sortie">Inventaire de sortie</button></div>
    <div class="btns"><button class="btn sm ghost" data-act="im-open" data-v="inv">Importer un inventaire déjà fait</button></div>
    <div class="rows">${I.map(e => row("inv", e)).join("") || '<div class="empty">Aucun inventaire pour ce bien.</div>'}${fileDocs(id, "inv").filter(d => !I.some(e => e.fichier === d.id)).map(fileRow).join("")}</div></div>`}
  <div class="card"><h2>Bail et lettres</h2><div class="small muted">Les PDF se remplissent avec les données du bien et du locataire.</div>
    <div class="btns"><button class="btn sm" data-act="bail-open">${bkind(id) === "vide" ? "Bail logement vide (PDF)" : "Bail meublé (PDF)"}</button></div>
    <div class="btns"><button class="btn sm ghost" data-act="let-open" data-v="impaye">Lettre de loyer impayé</button><button class="btn sm ghost" data-act="let-open" data-v="attest">Attestation de loyer</button><button class="btn sm ghost" data-act="let-open" data-v="depot">Restitution du dépôt</button><button class="btn sm ghost" data-act="let-open" data-v="rappel">Rappel avant état de sortie</button></div>
    <div class="btns"><button class="btn sm ghost" data-act="im-open" data-v="bail">Importer le bail signé</button></div>
    <div class="rows">${fileDocs(id, "bail").map(fileRow).join("")}</div></div>
  <div class="card"><h2>Pièces à joindre au bail</h2><div class="small muted">Importe chaque pièce une fois ; elle est cochée ici et dans l'annexe du bail. Ce sont les documents que Horiz propose.</div>
    <div class="rows">${ANNEXES.map(a => `<div class="row"><div class="main"><div class="t">${esc(a[1])}</div></div>${annexHas(id, a[0]) ? '<span class="chip ok">Au dossier</span>' : `<button class="mini" data-act="im-open" data-v="autre" data-s="${a[0]}">Importer</button>`}</div>`).join("")}</div></div>
  <div class="card"><h2>Autres documents</h2><div class="small muted">Diagnostics, assurance, courriers… gardés avec le dossier du bien, sur ce téléphone.</div>
    <div class="btns"><button class="btn sm ghost" data-act="im-open" data-v="autre">Importer un document</button></div>
    <div class="rows">${fileDocs(id, "autre").map(fileRow).join("") || '<div class="empty">Aucun document.</div>'}</div></div>`;
}
function dxTop(e, titre){
  return `<div class="btns"><button class="btn ghost sm" data-act="dx-back">‹ Documents</button></div>
  <div class="card"><div class="top"><h2>${titre} ${e.type === "sortie" ? "de sortie" : "d'entrée"}</h2>${bienPill(e.bien)}</div>
    <div class="grid2"><label class="f">Date<input type="date" data-dxh="date" value="${esc(e.date)}"></label><label class="f">Locataire<input data-dxh="loc" value="${esc(e.loc || "")}"></label></div>`;
}
function viewEdl(e){
  const sortie = e.type === "sortie", ref = sortie && e.ref ? docGet("edl", e.ref) : null, open = V.doc.open = V.doc.open || {};
  const rooms = e.pieces.map(p => { const done = p.items.filter(i => i.etat).length, isOpen = open[p.id];
    const items = !isOpen ? "" : p.items.map(it => { const worse = sortie && it.e0 && it.etat && RANK[it.etat] > RANK[it.e0];
      return `<div style="padding:8px 0;border-top:1px solid var(--line)"><div class="top"><b style="font-size:14px">${esc(it.nom)}</b><button class="mini" data-act="edl-delitem" data-p="${p.id}" data-i="${it.id}" aria-label="Supprimer">×</button></div>
        ${sortie && it.e0 ? `<div class="small muted">À l'entrée : ${esc(it.e0)}${it.c0 ? " · " + esc(it.c0) : ""}</div>` : ""}${worse ? '<div class="small neg">Plus dégradé qu\'à l\'entrée</div>' : ""}
        <div class="grid2 dxi">${etatSel(it.etat, `data-dx="etat" data-p="${p.id}" data-i="${it.id}"`)}<input data-dx="com" data-p="${p.id}" data-i="${it.id}" placeholder="Observation" value="${esc(it.com || "")}"></div>
        <div class="dxph">${(it.ph || []).map(pid => `<span class="dxp"><img data-ph="${pid}" alt="photo"><button data-act="ph-del" data-p="${p.id}" data-i="${it.id}" data-id="${pid}" aria-label="Retirer la photo">×</button></span>`).join("")}
          <label class="mini">+ Photo<input type="file" accept="image/*" multiple hidden data-edl-ph data-p="${p.id}" data-i="${it.id}"></label></div></div>`; }).join("") +
      `<div class="grid2 dxi" style="margin-top:8px"><input id="ni-${p.id}" placeholder="Ajouter un élément"><button class="btn sm ghost" data-act="edl-additem" data-p="${p.id}">Ajouter</button></div>
       <div class="btns"><button class="btn sm danger" data-act="edl-delroom" data-p="${p.id}">Supprimer la pièce</button></div>`;
    return `<div class="card" style="padding:12px 16px"><button class="rowbtn" data-act="dx-room" data-p="${p.id}" style="width:100%"><div class="top"><div><div class="t" style="font-weight:600">${esc(p.nom)}</div><div class="s">${done}/${p.items.length} renseignés</div></div><span class="muted">${isOpen ? "▾" : "▸"}</span></div></button>${items}</div>`; }).join("");
  return topbar("État des lieux") + dxTop(e, "État des lieux") + fileLink(e) + `
    <div class="small muted" style="margin-top:6px">Relevés des compteurs${ref ? " (entrée : élec. " + esc(ref.elec || "—") + " · eau " + esc(ref.eau || "—") + " · gaz " + esc(ref.gaz || "—") + ")" : ""}</div>
    <div class="grid2 dxi"><label class="f">Électricité<input data-dxh="elec" inputmode="decimal" value="${esc(e.elec || "")}"></label><label class="f">Eau<input data-dxh="eau" inputmode="decimal" value="${esc(e.eau || "")}"></label></div>
    <div class="grid2 dxi"><label class="f">Gaz<input data-dxh="gaz" inputmode="decimal" value="${esc(e.gaz || "")}"></label><label class="f">Clés remises<input data-dxh="cles" inputmode="numeric" value="${esc(e.cles || "")}"></label></div>
    <label class="f">Détecteur de fumée<select data-dxh="fumee"><option value="">—</option>${["Présent et testé", "Présent", "Absent"].map(x => `<option ${x === e.fumee ? "selected" : ""}>${x}</option>`).join("")}</select></label></div>
  ${rooms}
  <div class="card"><h2>Ajouter une pièce</h2><div class="btns"><button class="btn sm ghost" data-act="bulk-open">Coller une liste de pièces et éléments</button></div><div class="grid2 dxi"><input id="np-nom" placeholder="Ex. Balcon, cave"><button class="btn sm ghost" data-act="edl-addroom">Ajouter</button></div></div>
  <div class="card"><label class="f">Remarques générales<textarea data-dxh="rem">${esc(e.rem || "")}</textarea></label>
    ${sigBanner(e)}<div class="btns"><button class="btn" style="flex:1" data-act="dx-pdf">${e.sig ? "PDF signé : enregistrer ou envoyer" : "Créer le PDF"}</button><button class="btn ghost" data-act="dx-model">${e.modele ? "★ Retirer des modèles" : "☆ Garder comme modèle"}</button><button class="btn danger" data-act="dx-del">Supprimer</button></div>
    <div class="small muted">Les photos restent sur ce téléphone (pas dans la sauvegarde ni dans Excel). Elles sont jointes au PDF.</div></div>`;
}
function viewInv(e){
  const sortie = e.type === "sortie", groups = [...new Set(e.items.map(i => i.grp || "Autres"))];
  const open = V.doc.open = V.doc.open || {}; if (groups.length && !Object.keys(open).some(k => k.startsWith("g:"))) open["g:" + groups[0]] = 1; const nOpen = groups.filter(g => open["g:" + g]).length;
  const body = `<div class="btns" style="margin:0 0 8px"><button class="btn sm ghost" data-act="dx-all" data-v="${nOpen === groups.length ? "0" : "1"}">${nOpen === groups.length ? "Tout replier" : "Tout déplier"}</button></div>` + groups.map(g => { const its = e.items.filter(i => (i.grp || "Autres") === g), done = its.filter(i => i.etat).length, isOpen = !!open["g:" + g];
    const rows = !isOpen ? "" : its.map(it => `<div style="padding:8px 0;border-top:1px solid var(--line)">
      <div class="top"><b style="font-size:14px">${esc(it.nom)}</b><button class="mini" data-act="inv-delitem" data-i="${it.id}" aria-label="Supprimer">×</button></div>
      ${sortie && (it.e0 || it.q0) ? `<div class="small muted">À l'entrée : ${esc(it.q0 || "1")} · ${esc(it.e0 || "état non noté")}${it.c0 ? " · " + esc(it.c0) : ""}</div>` : ""}
      <div class="dxi" style="display:grid;grid-template-columns:70px 1fr;gap:8px"><input data-dx="qte" data-i="${it.id}" inputmode="numeric" value="${esc(it.qte || "")}" aria-label="Quantité">${etatSel(it.etat, `data-dx="etat" data-i="${it.id}"`)}</div>
      <div class="dxi" style="margin-top:6px"><input data-dx="com" data-i="${it.id}" placeholder="Observation" value="${esc(it.com || "")}"></div></div>`).join("");
    return `<div class="card" style="padding:12px 16px"><button class="rowbtn" data-act="dx-room" data-p="${esc("g:" + g)}" style="width:100%"><div class="top"><div><div class="t" style="font-weight:600">${esc(g)}</div><div class="s">${done}/${its.length} renseignés</div></div><span class="muted">${isOpen ? "▾" : "▸"}</span></div></button>${rows}</div>`; }).join("");
  return topbar("Inventaire") + dxTop(e, "Inventaire du mobilier") + fileLink(e) + `<div class="small muted">Liste minimale d'un meublé (décret n° 2015-981) : complète-la avec le mobilier réellement présent.</div></div>
  ${body}
  <div class="card"><h2>Ajouter un article</h2><div class="dxi"><input id="ni-nom" placeholder="Ex. Télévision, bureau"></div>
    <label class="f">Rangé dans<select id="ni-grp">${[...new Set(["Chambre", "Séjour", "Cuisine", "Entretien", "Autres"].concat(groups))].map(g => `<option>${esc(g)}</option>`).join("")}</select></label>
    <div class="btns"><button class="btn sm ghost" data-act="inv-additem">Ajouter</button></div></div>
  <div class="card"><h2>Ajouter plusieurs lignes</h2><div class="small muted">Colle une liste (copiée d'un PDF, d'un mail, de tes notes) : l'appli la découpe en articles.</div><div class="btns"><button class="btn sm ghost" data-act="bulk-open">Coller une liste</button></div></div>
  <div class="card"><label class="f">Remarques générales<textarea data-dxh="rem">${esc(e.rem || "")}</textarea></label>
    ${sigBanner(e)}<div class="btns"><button class="btn" style="flex:1" data-act="dx-pdf">${e.sig ? "PDF signé : enregistrer ou envoyer" : "Créer le PDF"}</button><button class="btn ghost" data-act="dx-model">${e.modele ? "★ Retirer des modèles" : "☆ Garder comme modèle"}</button><button class="btn danger" data-act="dx-del">Supprimer</button></div></div>`;
}
function tplPick(kind){
  const all = docList(kind).filter(x => !x.del).sort((a, b) => (b.modele ? 1 : 0) - (a.modele ? 1 : 0) || b.date.localeCompare(a.date)), mod = all.find(x => x.modele);
  const L = all.map(x => [x.id, (x.modele ? "★ MODÈLE · " : "") + bienName(x.bien) + " · " + (x.type === "sortie" ? "sortie" : "entrée") + " · " + frDate(x.date) + (x.fichier ? " (importé)" : "")]);
  return L.length ? dxS("dx-tpl", "Préremplir avec la liste d'un document existant (sans les états)" + (mod ? " — ton modèle ★ est choisi" : ""), [["", "Liste type"], ...L], mod ? mod.id : "") : "";
}
function sheetNewDoc(kind, type){
  const id = V.bsel, t = tenantFor(id, todayIso()), prev = docList(kind).filter(x => x.bien === id && !x.del && x.type === "entree").sort((a, b) => b.date.localeCompare(a.date) || (b.upd || 0) - (a.upd || 0));
  openSheet(`<h2>${kind === "edl" ? "État des lieux" : "Inventaire du mobilier"} ${type === "entree" ? "d'entrée" : "de sortie"}</h2>
    ${dxF("dx-date", "Date", todayIso(), 'type="date"')}${dxF("dx-loc", "Locataire", t ? t.nom : "")}
    ${type === "sortie" && prev.length ? dxS("dx-ref", "Comparer avec l'entrée du", prev.map(e => [e.id, frDate(e.date) + " · " + (e.loc || "") + " · " + (kind === "inv" ? e.items.length + " article(s)" : e.pieces.length + " pièce(s)")]), prev[0].id) : ""}
    ${type === "sortie" ? `<div class="info" style="margin-top:8px"><b>As-tu l'exemplaire d'entrée en fichier ?</b> (PDF, Excel ou CSV). Choisis-le ici : l'appli le reprend et crée directement la version de sortie.</div>
      <label class="f">Fichier d'entrée (facultatif)<input id="dx-impf" type="file" accept=".pdf,.xlsx,.xls,.csv,.txt"></label>${dxF("dx-edate", "Date de l'entrée (sur le document)", (tenantFor(id, todayIso()) || {}).debut || "", 'type="date"')}` : ""}
    ${type === "entree" ? `<div class="info" style="margin-top:8px"><b>Tu as déjà une liste en fichier ?</b> (PDF, Excel ou CSV : ancien inventaire, état des lieux…) L'appli la recopie <b>vierge</b>, sans les états, dans la liste de l'application : tu n'as plus qu'à la remplir à la visite.</div>
      <label class="f">Fichier à retranscrire (facultatif)<input id="dx-impl" type="file" accept=".pdf,.xlsx,.xls,.csv,.txt"></label>` : ""}
    ${!(type === "sortie" && prev.length) ? tplPick(kind) : ""}
    ${type === "entree" && kind === "edl" ? '<div class="small muted">Pièces à inclure</div>' + EDL_PIECES.map((p, i) => `<label style="display:flex;gap:8px;align-items:center;padding:4px 0"><input type="checkbox" id="dx-pc-${i}" checked> ${esc(p[0])}</label>`).join("") : ""}
    <div class="btns"><button class="btn" style="flex:1" data-act="dx-create" data-v="${kind}" data-t="${type}">Créer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function dxCreate(kind, type){
  const f = $("#dx-impf") && $("#dx-impf").files[0]; if (type === "sortie" && f) return dxCreateFromFile(kind, f);
  const fl = $("#dx-impl") && $("#dx-impl").files[0]; if (type === "entree" && fl) return dxFromFileBlank(kind, fl);
  const date = dxV("dx-date") || todayIso(), loc = dxV("dx-loc"), refId = $("#dx-ref") ? $("#dx-ref").value : "", ref = refId ? docGet(kind, refId) : null;
  const tplId = !ref && $("#dx-tpl") ? $("#dx-tpl").value : "", tpl = tplId ? docGet(kind, tplId) : null;
  dxMake(kind, type, date, loc, ref, tpl);
}
function dxMake(kind, type, date, loc, ref, tpl){
  const id = V.bsel, base = {id:uid(), bien:id, type, date, loc, rem:"", ref:ref ? ref.id : "", upd:Date.now()};
  let doc;
  if (kind === "edl"){
    doc = Object.assign(base, {elec:"", eau:"", gaz:"", cles:"", fumee:"", pieces:[]});
    if (ref) doc.pieces = ref.pieces.map(p => ({id:uid(), nom:p.nom, items:p.items.map(i => ({id:uid(), nom:i.nom, etat:"", com:"", ph:[], e0:i.etat || "", c0:i.com || ""}))}));
    else if (tpl) doc.pieces = tpl.pieces.map(p => ({id:uid(), nom:p.nom, items:p.items.map(i => ({id:uid(), nom:i.nom, etat:"", com:"", ph:[]}))}));
    else doc.pieces = EDL_PIECES.filter((p, i) => !$("#dx-pc-" + i) || $("#dx-pc-" + i).checked).map(p => mkPiece(p[0], p[1]));
  } else {
    doc = Object.assign(base, {items:[]});
    if (ref) doc.items = ref.items.map(i => ({id:uid(), grp:i.grp, nom:i.nom, qte:i.qte || "1", etat:"", com:"", q0:i.qte || "1", e0:i.etat || "", c0:i.com || ""}));
    else if (tpl) doc.items = tpl.items.map(i => ({id:uid(), grp:i.grp, nom:i.nom, qte:i.qte || "1", etat:"", com:""}));
    else INV_DEF.forEach(([g, L]) => L.forEach(n => doc.items.push({id:uid(), grp:g, nom:n, qte:"1", etat:"", com:""})));
  }
  docList(kind).push(doc); persist(); closeSheet(); V.doc = {kind, id:doc.id, open:{}}; if (kind === "edl" && doc.pieces[0]) V.doc.open[doc.pieces[0].id] = 1; if (kind === "inv" && doc.items[0]) V.doc.open["g:" + (doc.items[0].grp || "Autres")] = 1; render();
}
const dxItem = (e, p, i) => V.doc.kind === "edl" ? ((e.pieces.find(x => x.id === p) || {items:[]}).items.find(x => x.id === i)) : e.items.find(x => x.id === i);
function sheetDelDoc(){ openSheet(`<h2>Supprimer ce document ?</h2><p style="margin:0">Il sera retiré de la liste. Les PDF déjà envoyés ne sont pas touchés.</p><div class="btns"><button class="btn danger" data-act="dx-del-ok">Supprimer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); }

/* ---------- Actions ---------- */
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v, e = V.doc ? docCur() : null;
  switch (a){
    case "dx-new": sheetNewDoc(v, b.dataset.t); break;
    case "dx-create": dxCreate(v, b.dataset.t); break;
    case "dx-open": V.doc = {kind:v, id, open:{}}; render(); break;
    case "dx-back": V.doc = null; render(); break;
    case "dx-all": if (e && V.doc.kind === "inv"){ V.doc.open = V.doc.open || {}; for (const g of new Set(e.items.map(i => i.grp || "Autres"))) V.doc.open["g:" + g] = v === "1"; render(); } break;
    case "dx-room": if (e){ V.doc.open[b.dataset.p] = !V.doc.open[b.dataset.p]; render(); } break;
    case "edl-addroom": { const n = dxV("np-nom"); if (!e || !n) return toast("Donne un nom à la pièce"); const p = mkPiece(n, ["Sol", "Murs", "Plafond"]); e.pieces.push(p); dxTouch(e); V.doc.open[p.id] = 1; persist(); render(); break; }
    case "edl-delroom": if (e){ e.pieces = e.pieces.filter(p => p.id !== b.dataset.p); dxTouch(e); persist(); render(); } break;
    case "edl-additem": { const n = dxV("ni-" + b.dataset.p); const p = e && e.pieces.find(x => x.id === b.dataset.p); if (!p || !n) return toast("Écris le nom de l'élément"); p.items.push(mkItem(n)); dxTouch(e); persist(); render(); break; }
    case "edl-delitem": { const p = e && e.pieces.find(x => x.id === b.dataset.p); if (p){ const it = p.items.find(x => x.id === b.dataset.i); (it && it.ph || []).forEach(phDel); p.items = p.items.filter(x => x.id !== b.dataset.i); dxTouch(e); persist(); render(); } break; }
    case "ph-del": { const it = e && dxItem(e, b.dataset.p, b.dataset.i); if (it){ it.ph = (it.ph || []).filter(x => x !== id); phDel(id); dxTouch(e); persist(); render(); } break; }
    case "inv-additem": { const n = dxV("ni-nom"); if (!e || !n) return toast("Écris le nom de l'article"); e.items.push({id:uid(), grp:dxV("ni-grp") || "Autres", nom:n, qte:"1", etat:"", com:""}); V.doc.open = V.doc.open || {}; V.doc.open["g:" + (dxV("ni-grp") || "Autres")] = true; dxTouch(e); persist(); render(); break; }
    case "inv-delitem": if (e){ e.items = e.items.filter(x => x.id !== b.dataset.i); dxTouch(e); persist(); render(); } break;
    case "dx-pdf": { if (!e) break; toast("Création du PDF…"); try { const bytes = V.doc.kind === "edl" ? await edlPdf(e) : invPdf(e);
        saveFile((V.doc.kind === "edl" ? "etat-des-lieux-" : "inventaire-") + e.type + "-" + e.bien + "-" + e.date + ".pdf", bytes, "application/pdf"); } catch(err){ toast("PDF impossible : " + err.message); } break; }
    case "dx-del": sheetDelDoc(); break;
    case "dx-del-ok": if (e){ e.del = true; dxTouch(e); persist(); } closeSheet(); V.doc = null; render(); break;
  }
});
document.addEventListener("change", async ev => {
  const t = ev.target; if (!t || !t.dataset) return; const e = V.doc ? docCur() : null; if (!e) return;
  if (t.dataset.dxh){ e[t.dataset.dxh] = t.value; dxTouch(e); persist(); return; }
  if (t.dataset.dx){ const it = dxItem(e, t.dataset.p, t.dataset.i); if (!it) return; it[t.dataset.dx] = t.value; dxTouch(e); persist();
    if (t.dataset.dx === "etat" && V.doc.kind === "edl") render(); return; }
  if (t.hasAttribute("data-edl-ph")){ const it = dxItem(e, t.dataset.p, t.dataset.i); if (!it) return; const files = [...t.files]; t.value = ""; let n = 0;
    for (const f of files){ try { const o = await phCompress(f), pid = uid(); await phPut(pid, o); (it.ph = it.ph || []).push(pid); n++; } catch(err){ toast("Photo illisible"); } }
    if (n){ dxTouch(e); persist(); render(); toast(n + " photo(s) ajoutée(s)"); } }
});
