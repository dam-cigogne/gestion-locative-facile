/* ============ Documents importés (bail signé, état des lieux, inventaire déjà faits) ============ */
/* Les fichiers sont gardés dans IndexedDB (clé "f:<id>"), la fiche (nom, date, bien) dans S.docs. */
async function flPut(fid, rec){ const db = PH.db || await phOpen(); if (!db) throw new Error("stockage indisponible");
  return new Promise((res, rej) => { const tx = db.transaction("p", "readwrite"); tx.objectStore("p").put(rec, "f:" + fid); tx.oncomplete = () => res(); tx.onerror = tx.onabort = () => rej(tx.error || new Error("écriture impossible")); }); }
async function flGet(fid){ const db = PH.db || await phOpen(); if (!db) return null;
  return new Promise(res => { try { const q = db.transaction("p").objectStore("p").get("f:" + fid); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); } catch(e){ res(null); } }); }
async function flDel(fid){ const db = PH.db || await phOpen(); if (!db) return;
  return new Promise(res => { try { const tx = db.transaction("p", "readwrite"); tx.objectStore("p").delete("f:" + fid); tx.oncomplete = tx.onerror = tx.onabort = () => res(); } catch(e){ res(); } }); }
const ANNEXES = [["diag", "Dossier de diagnostics (DPE, risques, plomb, électricité, gaz…)"], ["notice", "Notice d'information locataires / bailleurs"], ["copro", "Extraits du règlement de copropriété"], ["charges", "Liste des charges récupérables"], ["repar", "Liste des réparations locatives"], ["caution", "Acte de cautionnement solidaire"], ["assur", "Attestation d'assurance habitation"], ["caf", "Attestation de loyer (CAF)"]];
const annexLabel = k => (ANNEXES.find(a => a[0] === k) || [0, ""])[1];
const annexHas = (bien, k) => fileDocs(bien, "autre").some(d => d.sub === k);
const FKIND = {bail:"Bail", edl:"État des lieux", inv:"Inventaire", autre:"Autre document"};
const MIMES = {pdf:"application/pdf", jpg:"image/jpeg", jpeg:"image/jpeg", png:"image/png", heic:"image/heic", doc:"application/msword", docx:"application/vnd.openxmlformats-officedocument.wordprocessingml.document", xls:"application/vnd.ms-excel", xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", csv:"text/csv", txt:"text/plain"};
const mimeOf = n => MIMES[(String(n).split(".").pop() || "").toLowerCase()] || "application/octet-stream";
const sizeStr = n => n >= 1048576 ? (n / 1048576).toFixed(1).replace(".", ",") + " Mo" : Math.max(1, Math.round(n / 1024)) + " Ko";
const fileDocs = (bien, kind) => docList("docs").filter(x => x.bien === bien && !x.del && (!kind || x.kind === kind));
function fileRow(d){
  return `<div class="row">${thumb(d.id, d.fname || d.nom, d.type)}<div class="main"><div class="t">${esc(d.nom)}</div><div class="s">${esc(d.sub ? annexLabel(d.sub) : (FKIND[d.kind] || "Document"))} · ${frDate(d.date)} · ${sizeStr(d.size || 0)}</div></div>
    <button class="mini" data-act="fl-open" data-id="${d.id}">Ouvrir</button><button class="mini" data-act="fl-del" data-id="${d.id}" aria-label="Supprimer">×</button></div>`;
}
function fileLink(e){
  const src = e.fichier ? e : (e.ref ? docGet(V.doc.kind, e.ref) : null), d = src && src.fichier ? docList("docs").find(x => x.id === src.fichier && !x.del) : null; if (!d) return "";
  return `<div class="info" style="margin:8px 0">${e.fichier ? "Document joint" : "État d'entrée signé (document joint)"} : ${esc(d.nom)} <button class="mini" data-act="fl-open" data-id="${d.id}">Ouvrir</button></div>`;
}
function sheetImport(kind){
  const id = V.bsel, t = tenantFor(id, todayIso()), rooms = kind === "edl" ? '<div class="small muted">Pièces de l\'état des lieux (pour pouvoir faire celui de sortie)</div>' + EDL_PIECES.map((p, i) => `<label style="display:flex;gap:8px;align-items:center;padding:4px 0"><input type="checkbox" id="im-pc-${i}" checked> ${esc(p[0])}</label>`).join("") : "";
  const help = {bail:"Le bail signé est conservé tel quel (PDF ou photo). Il n'est pas lu par l'appli.", edl:"Excel ou CSV (colonnes pièce, élément, état, observation) : les pièces et éléments sont repris tels quels. PDF, Word ou photo : le document est conservé et l'appli crée un état d'entrée avec les pièces cochées, à compléter. Dans les deux cas tu peux ensuite créer celui de sortie.",
    inv:"Excel ou CSV : la liste est lue et reprise dans l'appli (désignation, quantité, état, observation). PDF, Word ou photo : le document est conservé et une liste type est créée à compléter.", autre:"Le document est simplement conservé dans le dossier du bien."}[kind];
  openSheet(`<h2>Importer · ${esc(FKIND[kind])}</h2><div class="info">${help}</div>
    <label class="f">Fichier<input id="im-file" type="file" accept=".pdf,.xlsx,.xls,.csv,.doc,.docx,.txt,image/*"></label>
    ${dxF("im-date", "Date du document", todayIso(), 'type="date"')}${dxF("im-nom", "Nom (facultatif)", "", 'placeholder="Ex. Bail signé 2025"')}
    ${kind === "autre" ? dxS("im-sub", "Type de pièce", [["", "Autre document"], ...ANNEXES.map(a => [a[0], a[1]])], V.imSub || "") : ""}${kind === "edl" || kind === "inv" ? dxF("im-loc", "Locataire", t ? t.nom : "") : ""}${rooms}
    <div class="btns"><button class="btn" style="flex:1" data-act="im-save" data-v="${kind}">Importer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`);
}
function normEtat(s){ const t = String(s || "").toLowerCase(); if (!t.trim()) return ""; if (/neuf/.test(t)) return "Neuf"; if (/mauvais|\bhs\b|cass|d[ée]grad|abim/.test(t)) return "Mauvais"; if (/moyen|us[ée]|usag|passable|v[ée]tust/.test(t)) return "Moyen"; if (/bon|correct|satisf|\bok\b|propre/.test(t)) return "Bon"; return ""; }
function invFromSheet(buf, name){
  try {
    let wb; if (/\.csv$/i.test(name || "")){ const txt = new TextDecoder("utf-8").decode(new Uint8Array(buf)).replace(/^\uFEFF/, ""), first = txt.split("\n")[0] || "", fs = [";", "\t", ","].map(d => [d, first.split(d).length]).sort((a, b) => b[1] - a[1])[0][0]; wb = XLSX.read(txt, {type:"string", FS:fs}); } else wb = XLSX.read(buf, {type:"array"});
    const ws = wb.Sheets[wb.SheetNames[0]], rows = XLSX.utils.sheet_to_json(ws, {header:1, defval:"", raw:false}).map(r => r.map(c => String(c ?? "").trim()));
    let h = -1, c = {nom:0, qte:-1, etat:-1, com:-1, grp:-1};
    for (let i = 0; i < Math.min(15, rows.length) && h < 0; i++){ const r = rows[i], ni = r.findIndex(x => /d[ée]signation|article|objet|mobilier|[ée]l[ée]ment|libell|nom/i.test(x));
      if (ni >= 0 && r.filter(Boolean).length >= 2){ h = i; c = {nom:ni, qte:r.findIndex(x => /qt|quantit|nombre|^nb/i.test(x)), etat:r.findIndex(x => /[ée]tat/i.test(x)), com:r.findIndex(x => /obs|comment|remarque|note/i.test(x)), grp:r.findIndex(x => /pi[eè]ce|cat[ée]gorie|groupe|local/i.test(x))}; } }
    if (h < 0){ const sec = rows.filter(r => /^\d+([.,]\d+)?$/.test(r[1] || "")).length; c.qte = sec > rows.length / 3 ? 1 : -1; }
    const multi = c.qte >= 0 || c.etat >= 0 || c.com >= 0, out = []; let grp = "Importé";
    for (const r of rows.slice(h + 1)){ const nom = (r[c.nom] || "").trim(); if (!nom) continue;
      const qte = c.qte >= 0 ? r[c.qte] : "", raw = c.etat >= 0 ? r[c.etat] : "", obs = c.com >= 0 ? r[c.com] : "";
      if (multi && c.grp < 0 && !qte && !raw && !obs){ grp = nom; continue; }
      const et = normEtat(raw), com = [obs, raw && !et ? raw : ""].filter(Boolean).join(" · ");
      out.push({id:uid(), grp:c.grp >= 0 && r[c.grp] ? r[c.grp] : grp, nom, qte:qte || "1", etat:et, com});
      if (out.length >= 300) break; }
    return out;
  } catch(e){ return null; }
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a){
    case "im-open": V.imSub = b.dataset.s || ""; sheetImport(v); break;
    case "im-save": {
      const f = $("#im-file") && $("#im-file").files[0]; if (!f) return toast("Choisis un fichier");
      if (f.size > 25e6) return toast("Fichier trop gros (25 Mo maximum)");
      try {
        const buf = await f.arrayBuffer(), fid = uid(), type = f.type || mimeOf(f.name), date = dxV("im-date") || todayIso(), loc = dxV("im-loc");
        await flPut(fid, {name:f.name, type, buf});
        docList("docs").push({id:fid, bien:V.bsel, kind:v, nom:dxV("im-nom") || f.name, sub:v === "autre" ? dxV("im-sub") : "", fname:f.name, date, type, size:f.size, upd:Date.now()});
        let msg = "Document importé", bulkId = "";
        if (v === "edl"){ let pieces = null;
          if (/\.(xlsx|xls|csv)$/i.test(f.name)){ const it = invFromSheet(buf, f.name); if (it && it.length){ const map = {}; pieces = []; it.forEach(x => { const p = map[x.grp] || (map[x.grp] = {id:uid(), nom:x.grp, items:[]}); if (!map[x.grp].added){ map[x.grp].added = 1; pieces.push(p); } p.items.push({id:uid(), nom:x.nom, etat:x.etat, com:x.com, ph:[]}); }); pieces.forEach(p => delete p.added); } }
          const eid = uid(); if (!pieces && /\.(pdf|txt)$/i.test(f.name)) bulkId = eid;
          docList("edl").push({id:eid, bien:V.bsel, type:"entree", date, loc, elec:"", eau:"", gaz:"", cles:"", fumee:"", rem:"", ref:"", fichier:fid, upd:Date.now(),
            pieces:pieces || EDL_PIECES.filter((p, i) => !$("#im-pc-" + i) || $("#im-pc-" + i).checked).map(p => mkPiece(p[0], p[1]))}); msg = pieces ? "État lu : " + pieces.length + " pièce(s) reprise(s), prêt pour la sortie" : "Importé : état d'entrée créé, prêt pour la sortie"; }
        if (v === "inv"){ let items = /\.(xlsx|xls|csv)$/i.test(f.name) ? invFromSheet(buf, f.name) : null; const lu = items && items.length;
          if (!lu){ items = []; INV_DEF.forEach(([g, L]) => L.forEach(n => items.push({id:uid(), grp:g, nom:n, qte:"1", etat:"", com:""}))); }
          const nid = uid(); docList("inv").push({id:nid, bien:V.bsel, type:"entree", date, loc, rem:"", ref:"", fichier:fid, items, upd:Date.now()}); msg = lu ? "Inventaire lu : " + items.length + " article(s) repris" : "Document gardé"; if (!lu) bulkId = nid; }
        persist(); closeSheet(); toast(msg); render(); if (bulkId) bulkFromFile(v, bulkId, f, buf);
      } catch(err){ toast("Import impossible : " + err.message); }
      break; }
    case "fl-open": { const d = docList("docs").find(x => x.id === id); if (d) viewFile(id, d.fname || d.nom); break; }
    case "fl-del": { const d = docList("docs").find(x => x.id === id); if (!d) break;
      openSheet(`<h2>Supprimer ce document ?</h2><p style="margin:0">« ${esc(d.nom)} » sera retiré de l'appli. Ton original reste dans tes fichiers.</p><div class="btns"><button class="btn danger" data-act="fl-del-ok" data-id="${id}">Supprimer</button><button class="btn ghost" data-act="sheetclose">Annuler</button></div>`); break; }
    case "fl-del-ok": { const d = docList("docs").find(x => x.id === id); if (d){ d.del = true; d.upd = Date.now(); flDel(id); for (const k of ["edl", "inv"]) docList(k).forEach(e => { if (e.fichier === id) e.fichier = ""; }); persist(); } closeSheet(); render(); break; }
  }
});
