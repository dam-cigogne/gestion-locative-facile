"use strict";
/* ============ Constantes ============ */
const KEY = "glf-data-v1";           // clé localStorage propre à cette appli (≠ appli comptes)
const IDB_NAME = "glf-sec";                   // base IndexedDB propre à cette appli
const MOIS = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const MC = ["Janv","Févr","Mars","Avr","Mai","Juin","Juil","Août","Sept","Oct","Nov","Déc"];
const TYPES = ["Recette","Dépense","Sortie","Entrée"];
const TYPE_LAB = {"Recette":"Recette","Dépense":"Dépense","Sortie":"Épargne (sortie)","Entrée":"Entrée"};
const CATS = {
  "Recette":["Loyer","Remboursement","Autre recette"],
  "Dépense":["Crédit (mensualité)","Assurance PNO","Assurance GMPA","Syndic / copropriété","Eau","Électricité","Taxe foncière","CFE","Comptabilité","CGA / OGA","Abonnement Rendement locatif","Entretien / réparations","Mobilier / équipement","Diagnostics","Frais bancaires / cotisations","Divers"],
  "Sortie":["Bourse","Livret A","PEL","Autre placement","Assurance vie","Placement","Prêt","Transfert entre comptes","Achat personnel","Remboursement","Écart de rapprochement","Autre"],
  "Entrée":["Bourse","Livret A","PEL","Autre placement","Intérêts placement","Assurance vie","Placement","Prêt","Transfert entre comptes","Achat personnel","Remboursement","Écart de rapprochement","Autre"]
};
const FAMILLE = {"Crédit (mensualité)":"Crédit","Assurance PNO":"Assurances","Assurance GMPA":"Assurances","Taxe foncière":"Taxes","CFE":"Taxes","Comptabilité":"Compta & gestion","CGA / OGA":"Compta & gestion","Abonnement Rendement locatif":"Compta & gestion","Syndic / copropriété":"Copropriété & énergie","Eau":"Copropriété & énergie","Électricité":"Copropriété & énergie","Entretien / réparations":"Travaux & équipement","Mobilier / équipement":"Travaux & équipement","Diagnostics":"Travaux & équipement","Frais bancaires / cotisations":"Divers","Divers":"Divers"};
const BIEN_COL0 = {"STUDIO":"#1B7F79", "T2":"#B03060"}, BIEN_PAL = ["#1B7F79","#B03060","#B8741A","#3B6FB6","#7A4FB3","#4C8A2E","#B5473A","#2F7F9E"];
const BIEN_COL = new Proxy({}, {get:(_, id) => { if (typeof id !== "string") return undefined; if (BIEN_COL0[id]) return BIEN_COL0[id]; const ids = (typeof S !== "undefined" && S && S.biens ? S.biens.map(b => b.id) : []).filter(i => !BIEN_COL0[i]); const k = ids.indexOf(id); return BIEN_PAL[(k < 0 ? 2 : 2 + k) % BIEN_PAL.length]; }});
const BOURSE_COL = "#7030A0";
const PARTAGE_CAT = {"CFE":"CFE","Comptabilité":"Comptabilité","CGA / OGA":"CGA / OGA","Rendement locatif":"Abonnement Rendement locatif"};
const POSTES_TARIF = ["Loyer","Crédit (mensualité)","Assurance GMPA","Assurance PNO"];
const NO_EPARGNE = ["Écart de rapprochement","Transfert entre comptes","Intérêts placement"];

/* ============ Utilitaires ============ */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const eur = n => new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(Number(n)||0);
const isNum = v => typeof v === "number" && isFinite(v);
const N = v => isNum(v) ? v : 0;
const r2 = v => Math.round(v * 100) / 100;
const uid = () => "a" + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
const pad = n => String(n).padStart(2,"0");
const todayIso = () => { const d = new Date(); return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate()); };
const parseNum = s => { const t = String(s).replace(/\s/g,"").replace(",","."); const v = parseFloat(t); return isFinite(v) ? v : null; };
const fmtNum = v => (v === "" || v == null) ? "" : String(v).replace(".",",");
function serialToIso(s){ const d = new Date(Math.floor(s + 1e-6 - 25569) * 86400000); return d.toISOString().slice(0,10); }
function isoToSerial(iso){ const [y,m,d] = iso.split("-").map(Number); return Math.round(Date.UTC(y,m-1,d)/86400000) + 25569; }
function anyToIso(v){
  if (isNum(v)) return v > 20000 ? serialToIso(v) : "";
  if (v instanceof Date) return v.getFullYear()+"-"+pad(v.getMonth()+1)+"-"+pad(v.getDate());
  const s = String(v ?? "").trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return m[1]+"-"+m[2]+"-"+m[3];
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return m[3]+"-"+pad(m[2])+"-"+pad(m[1]);
  return "";
}
const frDate = iso => iso ? iso.slice(8,10)+"/"+iso.slice(5,7)+"/"+iso.slice(0,4) : "";
const frDateL = iso => iso ? iso.slice(8,10)+"/"+iso.slice(5,7)+"/"+iso.slice(0,4) : "";
const norm = s => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zA-Z0-9]/g,"").toLowerCase();
const str = v => v == null ? "" : String(v).trim();
const truthy = v => v === true || v === 1 || /^(1|x|oui|true|vrai)$/i.test(String(v ?? "").trim());
const sum = a => a.reduce((s,v) => s + N(v), 0);

/* ============ Données ============ */
let S = null, memCopy = null;
function load(){ try { const t = localStorage.getItem(KEY); if (t) return JSON.parse(t); } catch(e){} return memCopy; }
function persist(){ if (!S) return; memCopy = S; if (SEC.on){ SEC.dirty = true; if (!SEC.saving) flushEnc(); return; } try { localStorage.setItem(KEY, JSON.stringify(S)); } catch(e){} }

/* ============ Sécurité : code, Face ID, chiffrement AES-GCM ============ */
const ENC = KEY + "-enc", SECK = KEY + "-sec";
const SEC = {on:false, dk:null, saving:false, dirty:false, away:0, pin:"", msg:"", ask:false, cfg:{face:false, cred:"", delay:30, fails:0, until:0}};
const lsGet = k => { try { return localStorage.getItem(k); } catch(e){ return null; } };
const lsSet = (k,v) => { try { localStorage.setItem(k,v); } catch(e){} };
const lsDel = k => { try { localStorage.removeItem(k); } catch(e){} };
const lsWorks = () => { try { localStorage.setItem(KEY+"-t","1"); const ok = localStorage.getItem(KEY+"-t") === "1"; localStorage.removeItem(KEY+"-t"); return ok; } catch(e){ return false; } };
const subtle = (window.crypto && crypto.subtle) || null;
function b64(u8){ let t = ""; for (let i = 0; i < u8.length; i += 8192) t += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(t); }
const unb64 = t => Uint8Array.from(atob(t), c => c.charCodeAt(0));
async function kek(pin, salt){ const base = await subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveKey"]);
  return subtle.deriveKey({name:"PBKDF2", salt, iterations:200000, hash:"SHA-256"}, base, {name:"AES-GCM", length:256}, false, ["encrypt","decrypt"]); }
async function aesEnc(key, data){ const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = new Uint8Array(await subtle.encrypt({name:"AES-GCM", iv}, key, data)); return {iv:b64(iv), ct:b64(ct)}; }
async function aesDec(key, o){ return new Uint8Array(await subtle.decrypt({name:"AES-GCM", iv:unb64(o.iv)}, key, unb64(o.ct))); }
const dkKey = raw => subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt","decrypt"]);
function secCfgLoad(){ try { Object.assign(SEC.cfg, JSON.parse(lsGet(SECK) || "{}")); } catch(e){} }
const secCfgSave = () => lsSet(SECK, JSON.stringify(SEC.cfg));
async function flushEnc(){ SEC.saving = true;
  try { while (SEC.dirty && SEC.dk && S){ SEC.dirty = false; const blob = JSON.parse(lsGet(ENC)); blob.d = await aesEnc(SEC.dk, new TextEncoder().encode(JSON.stringify(S))); lsSet(ENC, JSON.stringify(blob)); } } catch(e){}
  SEC.saving = false; }
async function secFlushed(){ while (SEC.saving || SEC.dirty){ if (!SEC.saving) flushEnc(); await new Promise(r => setTimeout(r, 20)); } }
function idb(){ return new Promise((res,rej) => { const r = indexedDB.open(IDB_NAME,1); r.onupgradeneeded = () => r.result.createObjectStore("k"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
async function idbPut(k,v){ const db = await idb(); return new Promise((res,rej) => { const t = db.transaction("k","readwrite"); t.objectStore("k").put(v,k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }); }
async function idbGet(k){ const db = await idb(); return new Promise((res,rej) => { const q = db.transaction("k").objectStore("k").get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); }
async function idbDel(k){ try { const db = await idb(); await new Promise(res => { const t = db.transaction("k","readwrite"); t.objectStore("k").delete(k); t.oncomplete = () => res(); t.onerror = () => res(); }); } catch(e){} }
const secAvailable = () => !!subtle && lsWorks() && location.protocol.indexOf("http") === 0;
async function faceOK(){ try { return !!(window.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && window.indexedDB && window.top === window.self && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()); } catch(e){ return false; } }
async function faceRegister(){ const cred = await navigator.credentials.create({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)), rp:{name:"Gestion Locative Facile", id:location.hostname},
  user:{id:crypto.getRandomValues(new Uint8Array(16)), name:"locations", displayName:"Gestion Locative Facile"}, pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],
  authenticatorSelection:{authenticatorAttachment:"platform", userVerification:"required", residentKey:"preferred"}, timeout:60000, attestation:"none"}}); return b64(new Uint8Array(cred.rawId)); }
async function faceAsk(){ await navigator.credentials.get({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)), rpId:location.hostname,
  allowCredentials:[{type:"public-key", id:unb64(SEC.cfg.cred), transports:["internal"]}], userVerification:"required", timeout:60000}}); }
async function secEnable(pin){
  const raw = crypto.getRandomValues(new Uint8Array(32)), salt = crypto.getRandomValues(new Uint8Array(16));
  const w = await aesEnc(await kek(pin, salt), raw); SEC.dk = await dkKey(raw);
  const d = await aesEnc(SEC.dk, new TextEncoder().encode(JSON.stringify(S)));
  lsSet(ENC, JSON.stringify({salt:b64(salt), w, d})); if (lsGet(ENC)) { lsDel(KEY); SEC.on = true; } SEC.cfg.fails = 0; secCfgSave(); }
async function secUnwrap(pin){ const blob = JSON.parse(lsGet(ENC)); return {blob, raw: await aesDec(await kek(pin, unb64(blob.salt)), blob.w)}; }
async function secDisable(){ await secFlushed(); lsSet(KEY, JSON.stringify(S)); lsDel(ENC); await idbDel("dk"); SEC.on = false; SEC.dk = null; SEC.cfg.face = false; SEC.cfg.cred = ""; secCfgSave(); }
async function secChange(oldPin, newPin){ await secFlushed(); const {blob, raw} = await secUnwrap(oldPin); const salt = crypto.getRandomValues(new Uint8Array(16));
  blob.salt = b64(salt); blob.w = await aesEnc(await kek(newPin, salt), raw); lsSet(ENC, JSON.stringify(blob)); }
function afterUnlock(plain){ S = JSON.parse(new TextDecoder().decode(plain)); memCopy = S; SEC.on = true; SEC.cfg.fails = 0; SEC.cfg.until = 0; secCfgSave(); migrate(); return true; }
async function unlockPin(pin){ try { const {blob, raw} = await secUnwrap(pin); SEC.dk = await dkKey(raw); return afterUnlock(await aesDec(SEC.dk, blob.d)); } catch(e){ SEC.dk = null; return false; } }
async function unlockFace(){ try { await faceAsk(); const dk = await idbGet("dk"); if (!dk) return false; const blob = JSON.parse(lsGet(ENC)); const plain = await aesDec(dk, blob.d); SEC.dk = dk; return afterUnlock(plain); } catch(e){ SEC.dk = null; return false; } }

function showLock(msg, bad){
  document.body.classList.remove("priv"); $("#lock").hidden = false; SEC.pin = ""; SEC.ask = false;
  const wait = Math.ceil((SEC.cfg.until - Date.now()) / 1000);
  $("#lockmsg").textContent = wait > 0 ? "Trop d'essais. Patiente " + wait + " s." : (msg || "Entre ton code"); $("#lockmsg").className = bad || wait > 0 ? "bad" : "";
  const key = n => `<button data-act="lk-d" data-id="${n}">${n}</button>`;
  $("#lockpad").innerHTML = [1,2,3,4,5,6,7,8,9].map(key).join("") + (SEC.cfg.face ? `<button data-act="lk-face" aria-label="Face ID">${ICON.face}</button>` : "<span></span>") + key(0) +
    `<button data-act="lk-del" aria-label="Effacer">⌫</button>`;
  $("#lockextra").innerHTML = SEC.ask ? "" : `<button class="btn ghost sm" data-act="lk-ok">Valider</button><button class="btn ghost sm" data-act="lk-forgot">Code oublié</button>`;
  lockDots();
}
function lockDots(){ $("#lockdots").innerHTML = Array.from({length:Math.max(4,SEC.pin.length)}, (_,i) => `<i class="${i < SEC.pin.length ? "on" : ""}"></i>`).join(""); }
function hideLock(){ $("#lock").hidden = true; document.body.classList.remove("priv"); render(); if (typeof bootRoutines === "function") bootRoutines(); }
async function lockSubmit(){
  if (Date.now() < SEC.cfg.until) return showLock("", true);
  if (SEC.pin.length < 4) return;
  const ok = await unlockPin(SEC.pin);
  if (ok) return hideLock();
  SEC.cfg.fails++; if (SEC.cfg.fails >= 5) SEC.cfg.until = Date.now() + Math.min(600, 15 * Math.pow(2, SEC.cfg.fails - 5)) * 1000; secCfgSave();
  showLock("Code incorrect", true);
}
async function lockNow(){ if (!SEC.on || !SEC.dk || !S) return; await secFlushed(); SEC.dk = null; S = null; memCopy = null; V.pending = null; closeSheet(); showLock(); }
document.addEventListener("visibilitychange", () => {
  if (!SEC.on) return;
  if (document.hidden){ if (S) document.body.classList.add("priv"); SEC.away = Date.now(); secFlushed(); }
  else if (S && SEC.away && Date.now() - SEC.away >= SEC.cfg.delay * 1000) lockNow(); else document.body.classList.remove("priv");
});

/* ============ Modèle de données ============ */
function emptyData(){ return { v:1, demo:false, biens:[], tarifs:[], journal:[], factures:[], locataires:[], seen:[], partages:[], rapp:{}, modeles:[], clotures:[], edl:[], inv:[], docs:[], cand:[], annonces:{}, cfg:{bailleur:"", adr:{}} }; }
const live = a => a.filter(x => !x.del);
const bienName = id => { const b = S.biens.find(x => x.id === id); return b ? b.nom : id; };
const bienIds = () => { const ids = live(S.biens).map(b => b.id); for (const j of S.journal) if (j.bien && !ids.includes(j.bien)) ids.push(j.bien); return ids; };
const J = () => S.journal.filter(j => !j.del && j.date);
const yr = j => +j.date.slice(0,4);
const mo = j => +j.date.slice(5,7) - 1;
const isIn = j => j.type === "Recette" || j.type === "Entrée";
function statut(j){ if (j.pointe === "x") return "Pointé"; if (j.date > todayIso()) return "Prévu"; return j.type === "Recette" ? "En retard" : "À pointer"; }
const impact = j => (j.pointe !== "x" || j.compte === "Perso") ? 0 : (isIn(j) ? 1 : -1) * N(j.montant);
function soldeBien(id, uptoYear){
  const b = S.biens.find(x => x.id === id);
  return r2(N(b && b.solde0) + sum(J().filter(j => j.bien === id && (uptoYear == null || yr(j) <= uptoYear)).map(impact)));
}
function soldeAvant(id, y){
  const b = S.biens.find(x => x.id === id);
  return r2(N(b && b.solde0) + sum(J().filter(j => j.bien === id && yr(j) < y).map(impact)));
}
function stats(id, y){   // id = null → tous les biens
  const L = J().filter(j => (id == null || j.bien === id) && yr(j) === y);
  const rec = sum(L.filter(j => j.type === "Recette").map(j => j.montant)), dep = sum(L.filter(j => j.type === "Dépense").map(j => j.montant));
  const recP = sum(L.filter(j => j.type === "Recette" && j.pointe === "x").map(j => j.montant)), depP = sum(L.filter(j => j.type === "Dépense" && j.pointe === "x").map(j => j.montant));
  const ep = sum(L.filter(j => j.type === "Sortie" && !NO_EPARGNE.includes(j.cat)).map(j => j.montant)) - sum(L.filter(j => j.type === "Entrée" && !NO_EPARGNE.includes(j.cat)).map(j => j.montant));
  const bourse = sum(L.filter(j => j.type === "Sortie" && j.cat === "Bourse").map(j => j.montant)) - sum(L.filter(j => j.type === "Entrée" && j.cat === "Bourse").map(j => j.montant));
  return {rec:r2(rec), dep:r2(dep), cf:r2(rec - dep), recP:r2(recP), depP:r2(depP), benef:r2(recP - depP), ep:r2(ep), bourse:r2(bourse)};
}
function counts(y){
  const L = J().filter(j => yr(j) === y);
  return { retard: J().filter(j => statut(j) === "En retard").length, pointer: J().filter(j => statut(j) === "À pointer").length,
           compta: L.filter(j => j.type === "Dépense" && j.pointe === "x" && !j.compta).length };
}
const bourseOn = () => { const c = S.cfg && S.cfg.bourse; return typeof c === "boolean" ? c : !!(S.demo || S.journal.some(j => !j.del && (j.cat === "Bourse" || j.cat === "Livret A" || j.cat === "PEL" || j.cat === "Autre placement"))); };
const bienPill = id => `<span class="bp" style="background:${BIEN_COL[id] || "var(--accent)"}">${esc(bienName(id))}</span>`;
function bourseOf(id, cat){
  const L = J().filter(j => j.cat === (cat || "Bourse") && (id == null || j.bien === id));
  const mis = r2(sum(L.filter(j => j.type === "Sortie").map(j => j.montant))), remb = r2(sum(L.filter(j => j.type === "Entrée").map(j => j.montant)));
  return {mis, remb, reste:r2(mis - remb)};
}
function splitPartage(total, part){ const a = r2(total * part); return [a, r2(total - a)]; }   // STUDIO arrondi, T2 = le reste
const bkind = id => { const b = S.biens.find(x => x.id === id); return b && b.bail === "vide" ? "vide" : "meuble"; };
const partagesList = () => S.partages.length ? S.partages : Object.keys(PARTAGE_CAT).map(f => ({frais:f, total:0, partStudio:0.5}));
function tarifVigueur(bien, poste){
  const L = S.tarifs.filter(t => t.bien === bien && t.poste === poste && t.date && t.date <= todayIso()).sort((a,b) => b.date.localeCompare(a.date));
  return L[0] || null;
}
function tarifFor(bien, poste, iso){
  const L = S.tarifs.filter(t => t.bien === bien && t.poste === poste && t.date && t.date <= iso).sort((a,b) => b.date.localeCompare(a.date));
  return L.length ? L[0].montant : null;
}
function suggest(bien, cat, iso){
  const b = S.biens.find(x => x.id === bien); if (!b) return null;
  if (cat === "Loyer") return tarifFor(bien, "Loyer", iso) ?? (b.loyer || null);
  if (cat === "Crédit (mensualité)") return tarifFor(bien, cat, iso) ?? (b.credit || null);
  return tarifFor(bien, cat, iso);
}
function tenantFor(bien, iso){
  const L = live(S.locataires).filter(t => t.bien === bien);
  return L.find(t => (!t.debut || t.debut <= iso) && (!t.fin || t.fin >= iso)) || L[L.length - 1] || null;
}
function allCats(type){ const set = new Set(CATS[type] || []); for (const j of J()) if (j.type === type && j.cat) set.add(j.cat); return [...set]; }

function demoData(rich){
  const d = emptyData(); d.demo = true;
  d.biens = [{id:"STUDIO",nom:"Studio",solde0:2000,date0:"2021-12-31",loyer:500,credit:240,regime:"LMNP",notes:"",upd:0},{id:"T2",nom:"Appartement T2",solde0:1500,date0:"2021-12-31",loyer:650,credit:410,regime:"LMNP",notes:"",upd:0}];
  const y = new Date().getFullYear(), tm = new Date().getMonth();
  const mk = (bien,m,type,cat,lib,mt,pt) => ({id:uid(),date:y+"-"+pad(m+1)+"-01",bien,type,cat,lib,montant:mt,compte:"Bien",pointe:pt?"x":"",compta:"",justif:"",fourn:"",note:"",upd:0});
  for (let m = 0; m < 12; m++) for (const b of d.biens){
    const pt = m < tm || (m === tm);
    d.journal.push(mk(b.id,m,"Recette","Loyer","Loyer "+MOIS[m].toLowerCase(),b.loyer,pt && !(b.id==="T2" && m===tm)));
    d.journal.push(mk(b.id,m,"Dépense","Crédit (mensualité)","Crédit",b.credit,pt));
    d.journal.push(mk(b.id,m,"Dépense","Assurance PNO","Assurance PNO",20,pt));
  }
  d.factures = [{id:uid(),fourn:"Magasin exemple",num:"F-001",date:y+"-02-10",cat:"TRAVAUX",desc:"Peinture (exemple)",prix:180,jdmm:"",scan:"x",upd:0}];
  d.locataires = [{id:uid(),bien:"T2",nom:"Locataire Exemple",tel:"0600000000",email:"",debut:(y-1)+"-09-01",fin:"",loyer:650,depot:650,note:"Donnée d'exemple",upd:0},
    ];
  if (!rich) return d;
  d.locataires[0].nom = "Julien Exemple"; d.locataires.push({id:uid(),bien:"STUDIO",nom:"Camille Essai",tel:"0600000001",email:"",debut:(y-1)+"-03-01",fin:"",loyer:500,depot:500,note:"Donnée d'exemple",upd:0});
  d.biens[0].adresse = "1 rue de l'Exemple, 00000 Ville-Test"; d.biens[1].adresse = "2 avenue d'Essai, 00000 Ville-Test";
  d.biens[0].desc = {type:"Studio", surface:"22", etage:"2e étage", pieces:"1", copro:"Oui", dpe:"D", chauffage:"Électrique individuel", eauch:"Ballon électrique", annexes:"Aucune"};
  d.biens[1].desc = {type:"Appartement T2", surface:"38", etage:"1er étage", pieces:"2", copro:"Oui", dpe:"C", chauffage:"Électrique individuel", eauch:"Ballon électrique", annexes:"Cave"};
  const dE = (y-1)+"-09-01", it = (nom,etat,com) => ({id:uid(),nom,etat,com:com||"",ph:[]});
  d.edl.push({id:uid(),bien:"T2",type:"entree",date:dE,loc:"Julien Exemple",elec:"12450",eau:"310",gaz:"",cles:"3",fumee:"Présent et testé",rem:"État des lieux d'exemple.",ref:"",upd:0,
    pieces:[{id:uid(),nom:"Entrée",items:[it("Sol","Bon"),it("Murs","Bon"),it("Porte d'entrée","Neuf")]},{id:uid(),nom:"Séjour",items:[it("Sol","Moyen","Rayures légères"),it("Murs","Bon"),it("Fenêtres","Bon")]},{id:uid(),nom:"Cuisine",items:[it("Plan de travail","Bon"),it("Évier","Bon"),it("Plaques de cuisson","Neuf")]}]});
  const iv = (grp,nom,qte,etat) => ({id:uid(),grp,nom,qte,etat,com:""});
  d.inv.push({id:uid(),bien:"T2",type:"entree",date:dE,loc:"Julien Exemple",rem:"",ref:"",upd:0,
    items:[iv("Chambre","Lit (couchage 140 cm)","1","Bon"),iv("Chambre","Couette","1","Bon"),iv("Séjour","Table","1","Bon"),iv("Séjour","Chaises","4","Moyen"),iv("Cuisine","Réfrigérateur","1","Bon"),iv("Cuisine","Assiettes","6","Bon"),iv("Entretien","Aspirateur","1","Neuf")]});
  return d;
}

/* ============ Lecture / écriture des fichiers Excel ============ */
function sheetObjs(wb, name){
  const ws = wb.Sheets[name]; if (!ws) return null;
  const a = XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:""}); if (!a.length) return [];
  const h = a[0].map(norm), out = [];
  for (let i = 1; i < a.length; i++){ const r = a[i]; if (r.every(v => v === "")) continue; const o = {}; h.forEach((k,c) => { if (k) o[k] = r[c]; }); out.push(o); }
  return out;
}
const numOf = v => isNum(v) ? v : (parseNum(v) ?? 0);
const comptaOf = v => { if (v === "" || v == null) return ""; if (isNum(v)) return v > 20000 ? serialToIso(v) : "x"; const s = String(v).trim(); if (/^x$/i.test(s)) return "x"; return anyToIso(s) || "x"; };
function parseEchange(wb){
  const out = {biens:null, tarifs:null, partages:null, reglages:null, journal:[], factures:[], locataires:[], hasAny:false};
  const rg = sheetObjs(wb,"Reglages_appli"), fp = sheetObjs(wb,"FraisPartages_appli"), b = sheetObjs(wb,"Biens_appli"), t = sheetObjs(wb,"Tarifs_appli"), j = sheetObjs(wb,"Journal_appli"), f = sheetObjs(wb,"Factures_appli"), l = sheetObjs(wb,"Locataires_appli");
  if (!b && !t && !j && !f && !l && !fp) return null;
  if (rg){ out.reglages = {}; for (const o of rg) if (str(o.cle)) out.reglages[norm(o.cle)] = str(o.valeur); }
  if (fp) out.partages = fp.filter(o => str(o.frais)).map(o => { let p = numOf(o.partstudio); if (p > 1) p = p / 100; return {frais:str(o.frais), total:numOf(o.total), partStudio:p || 0}; });
  if (b){ const seenB = new Set(); out.biens = b.filter(o => { const id = str(o.id); if (!id || seenB.has(id) || !anyToIso(o.datesoldeinitial)) return false; seenB.add(id); return true; }).map(o => ({id:str(o.id), nom:str(o.nom) || str(o.id), solde0:numOf(o.soldeinitial), date0:anyToIso(o.datesoldeinitial), loyer:numOf(o.loyermensuel), credit:numOf(o.mensualitecredit), regime:str(o.regimefiscal), notes:str(o.notes), adresse:str(o.adresse), upd:0, ...(numOf(o.empcapital) > 0 && numOf(o.empdureemois) > 0 && anyToIso(o.empdebut) ? {emprunt:{capital:numOf(o.empcapital), taux:numOf(o.emptaux), duree:Math.round(numOf(o.empdureemois)), debut:anyToIso(o.empdebut), assur:numOf(o.empassurmensuelle)}} : {})})); }
  if (t){ out.tarifs = t.filter(o => str(o.bien) && str(o.poste)).map(o => ({bien:str(o.bien), poste:str(o.poste), date:anyToIso(o.apartirdu), montant:numOf(o.montant), note:str(o.note)})); }
  if (j) for (const o of j){ const id = str(o.id), date = anyToIso(o.date); if (!id || !date) continue;
    out.journal.push({id, date, bien:str(o.bien), type:str(o.type), cat:str(o.categorie), lib:str(o.libelle), montant:numOf(o.montant), compte:str(o.compte) || "Bien", pointe:truthy(o.pointe) ? "x" : "",
      compta:comptaOf(o.saisicompta), justif:truthy(o.justif) ? "x" : "", fourn:str(o.fournisseur), note:str(o.note), upd:Number(o.modifie) || 0, del:truthy(o.supprime)}); }
  if (f) for (const o of f){ const id = str(o.id); if (!id || !str(o.fournisseur)) continue;
    out.factures.push({id, fourn:str(o.fournisseur), num:str(o.numfacture), date:anyToIso(o.date), cat:str(o.categorie), desc:str(o.description), prix:numOf(o.prix), jdmm:truthy(o.enregistrejdmm) ? "x" : "", scan:truthy(o.scanne) ? "x" : "", upd:Number(o.modifie) || 0, del:truthy(o.supprime)}); }
  if (l) for (const o of l){ const id = str(o.id); if (!id) continue;
    out.locataires.push({id, bien:str(o.bien), nom:str(o.nom), tel:str(o.telephone), email:str(o.email), debut:anyToIso(o.debutbail), fin:anyToIso(o.finbail), loyer:numOf(o.loyercc), charges:numOf(o.charges), depot:numOf(o.depotgarantie), note:str(o.note), upd:Number(o.modifie) || 0, del:truthy(o.supprime)}); }
  return out;
}
function mergeList(list, incoming){
  const byId = new Map(list.map(x => [x.id, x])); let add = 0, upd = 0;
  for (const x of incoming){ const cur = byId.get(x.id);
    if (!cur){ list.push(x); byId.set(x.id, x); add++; }
    else if ((x.upd || 0) > (cur.upd || 0)){ Object.assign(cur, x); upd++; } }
  return {add, upd};
}
const jKey = j => [j.date, j.bien, j.cat, j.lib, r2(N(j.montant))].join("|");
function mergeJournal(list, incoming){   // fusion par ID + rejet des doublons (même date, bien, catégorie, libellé, montant)
  const byId = new Map(list.map(x => [x.id, x])), keys = new Set(list.filter(x => !x.del).map(jKey)); let add = 0, upd = 0, dup = 0;
  for (const x of incoming){ const cur = byId.get(x.id);
    if (!cur){ if (!x.del && keys.has(jKey(x))){ dup++; continue; } list.push(x); byId.set(x.id, x); add++; }
    else if ((x.upd || 0) > (cur.upd || 0)){ Object.assign(cur, x); upd++; } }
  return {add, upd, dup};
}
const idsOf = p => [].concat(p.journal, p.factures, p.locataires).map(x => x.id);
function buildEchange(){
  const dt = iso => iso ? isoToSerial(iso) : "";
  const wb = XLSX.utils.book_new();
  const sheet = (name, head, rows, dateCols) => { const ws = XLSX.utils.aoa_to_sheet([head].concat(rows));
    for (let r = 1; r <= rows.length; r++) for (const c of dateCols){ const a = ws[c + (r + 1)]; if (a && isNum(a.v)){ a.t = "n"; a.z = "dd/mm/yyyy"; } }
    ws["!cols"] = head.map(h => ({wch:Math.max(10, h.length + 2)})); XLSX.utils.book_append_sheet(wb, ws, name); };
  sheet("Journal_appli", ["ID","Date","Bien","Type","Categorie","Libelle","Montant","Compte","Pointe","SaisiCompta","Justif","Fournisseur","Note","Modifie","Supprime"],
    S.journal.map(j => [j.id, dt(j.date), j.bien, j.type, j.cat, j.lib, j.montant, j.compte || "Bien", j.pointe, j.compta === "x" ? "x" : dt(j.compta), j.justif, j.fourn, j.note, j.upd || 0, j.del ? 1 : ""]), ["B","J"]);
  sheet("Factures_appli", ["ID","Fournisseur","NumFacture","Date","Categorie","Description","Prix","EnregistreJDMM","Scanne","Modifie","Supprime"],
    S.factures.map(f => [f.id, f.fourn, f.num, dt(f.date), f.cat, f.desc, f.prix, f.jdmm, f.scan, f.upd || 0, f.del ? 1 : ""]), ["D"]);
  sheet("Locataires_appli", ["ID","Bien","Nom","Telephone","Email","DebutBail","FinBail","LoyerCC","DepotGarantie","Note","Modifie","Supprime","Charges"],
    S.locataires.map(t => [t.id, t.bien, t.nom, t.tel, t.email, dt(t.debut), dt(t.fin), t.loyer, t.depot, t.note, t.upd || 0, t.del ? 1 : "", t.charges || 0]), ["F","G"]);
  sheet("Biens_appli", ["ID","Nom","SoldeInitial","DateSoldeInitial","LoyerMensuel","MensualiteCredit","RegimeFiscal","Notes","Adresse","CreeDansAppli","EmpCapital","EmpTaux","EmpDureeMois","EmpDebut","EmpAssurMensuelle"],
    live(S.biens).map(b => { const e = b.emprunt || {}; return [b.id, b.nom, b.solde0, dt(b.date0), b.loyer, b.credit, b.regime, b.notes, b.adresse || "", b.app ? 1 : "", e.capital || "", e.capital ? e.taux || 0 : "", e.duree || "", e.debut ? dt(e.debut) : "", e.assur || ""]; }), ["D","N"]);
  sheet("Tarifs_appli", ["Bien","Poste","APartirDu","Montant","Note","Modifie"],
    S.tarifs.filter(t => t.app).map(t => [t.bien, t.poste, dt(t.date), t.montant, t.note, t.upd || 0]), ["C"]);
  sheet("Reglages_appli", ["Cle","Valeur"], [["Version", 1], ["DateExport", Date.now()], ["Bailleur", (S.cfg && S.cfg.bailleur) || ""], ["BailleurAdresse", (S.cfg && S.cfg.bailleurAdr) || ""]], []);
  return XLSX.write(wb,{type:"array",bookType:"xlsx",compression:true});
}
/* Dossier d'enregistrement choisi une fois (navigateurs qui le permettent : PC, Android). La poignée est gardée dans une petite base à part. */
const dirIdb = () => new Promise(res => { try { const r = indexedDB.open("glf-prefs", 1); r.onupgradeneeded = () => r.result.createObjectStore("k"); r.onsuccess = () => res(r.result); r.onerror = () => res(null); } catch(e){ res(null); } });
async function dirGet(){ const db = await dirIdb(); if (!db) return null; return new Promise(res => { try { const q = db.transaction("k").objectStore("k").get("dir"); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); } catch(e){ res(null); } }); }
async function dirSet(h){ try { h ? localStorage.setItem("glf-dir", "1") : localStorage.removeItem("glf-dir"); } catch(e){} const db = await dirIdb(); if (!db) return; return new Promise(res => { try { const st = db.transaction("k", "readwrite").objectStore("k"); h ? st.put(h, "dir") : st.delete("dir"); st.transaction.oncomplete = res; st.transaction.onerror = res; } catch(e){ res(); } }); }
async function saveFile(name, data, mime, note){
  try { const dh = window.showDirectoryPicker && lsGet("glf-dir") ? await dirGet() : null;
    if (dh){ if ((await dh.queryPermission({mode:"readwrite"})) !== "granted" && (await dh.requestPermission({mode:"readwrite"})) !== "granted") throw new Error("refusé");
      let fh, had = true; try { fh = await dh.getFileHandle(name); } catch(e){ had = false; fh = await dh.getFileHandle(name, {create:true}); }
      const w = await fh.createWritable(); await w.write(data); await w.close(); toast((had ? "Ancienne version remplacée dans « " : "Enregistré dans « ") + dh.name + " » : " + name); return; } }
  catch(e){ toast("Dossier non disponible, enregistrement normal"); }
  try { const file = new File([data], name, {type:mime});
    if (navigator.canShare && navigator.canShare({files:[file]})){ await navigator.share({files:[file]}); toast("Fichier partagé : " + name + (note ? ". " + note : "")); return; } }
  catch(e){ if (e && e.name === "AbortError") return; }
  const url = URL.createObjectURL(new Blob([data],{type:mime})); const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast("Fichier prêt : " + name);
}
