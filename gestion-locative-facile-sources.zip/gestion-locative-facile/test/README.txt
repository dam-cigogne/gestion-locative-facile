gf1.py : test Playwright de la version publique (serveur : python3 -m http.server 8766 depuis le dossier du build).
Les anciens tests e2e de « Mes locations » ne sont pas inclus (ils contiennent des fichiers Excel de test).
