import asyncio, json, pathlib, subprocess
from playwright.async_api import async_playwright
XLSXJS = pathlib.Path("/tmp/claude-0/-home-claude/4dfcdcd9-937c-5b65-8a52-54fc82a9cb84/scratchpad/npm/node_modules/xlsx/dist/xlsx.full.min.js").read_bytes()
URL="http://localhost:8766/index.html"; ok=True; OUT=pathlib.Path("/tmp/gfout"); OUT.mkdir(exist_ok=True)
def check(n,c,i=""):
    global ok; print(("OK   " if c else "FAIL ")+n+(" -> "+str(i)[:200] if i!="" else "")); ok = ok and bool(c)
def pdftxt(f): return subprocess.run(["pdftotext","-layout",str(f),"-"],capture_output=True,text=True).stdout
async def jc(pg,sel): await pg.evaluate("document.querySelector(%r).click()"%sel)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,accept_downloads=True,locale="fr-FR",service_workers="block")
        await ctx.route("**/cdnjs.cloudflare.com/**", lambda r: r.fulfill(body=XLSXJS, content_type="application/javascript"))
        await ctx.add_init_script("try{localStorage.setItem('glf-tour','1');localStorage.setItem('glf-remind','0')}catch(e){}")
        pg=await ctx.new_page(); errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_selector("[data-act=wz-go]")
        t=await pg.inner_text("body")
        check("accueil neutre + avertissement", "Gestion Locative Facile" in t and "ne remplace ni un notaire" in t and "Studio" not in t, t[:200])
        check("clés de stockage glf", await pg.evaluate("Object.keys(localStorage).every(k=>!k.startsWith('loc-') && k!=='gestion-locative-v1')"))
        # guide depuis l'accueil
        await pg.click("[data-act=go][data-v=guide]"); await asyncio.sleep(.3)
        t=await pg.inner_text("body"); check("guide ouvert", "Guide du bailleur" in t and "Location meublée ou vide" in t and "Colocation" in t and "Amortir" in t)
        await pg.evaluate("document.querySelector('.gsec[data-g=nv]').open=true"); await asyncio.sleep(.2)
        t=await pg.inner_text("body"); check("tableau meublé/vide", "3 ans" in t and "2 mois de loyer" in t and "6 mois avant" in t)
        await pg.evaluate("document.querySelector('.gsec[data-g=co]').open=true"); t=await pg.inner_text("body"); check("colocation", "Baux individuels" in t and "Bail collectif" in t)
        await pg.click("text=Retour"); await asyncio.sleep(.3)
        # créer un bien vide
        await pg.click("[data-act=wz-go]"); await pg.fill("#wz-bail","Jeanne Test"); await pg.fill("#wz-badr","1 rue Test 13100 Aix"); await pg.click("[data-act=wz-bail]")
        await pg.fill("#bn-nom","Appart vide"); await pg.fill("#bn-adr","5 rue du Mail 13100 Aix"); await pg.fill("#bn-loyer","700"); await pg.select_option("#bn-bail","vide")
        reg=await pg.input_value("#bn-regime"); print("regime", reg)
        await pg.click("[data-act=wz-bien]"); await pg.fill("#t-nom","Paul Locataire"); await pg.fill("#t-debut","2026-11-01"); await pg.fill("#t-loyer","750"); await pg.fill("#t-chg","50"); await pg.fill("#t-depot","700")
        await pg.click("[data-act=wz-loc]"); await pg.click("[data-act=wz-end]"); await asyncio.sleep(.5)
        st=await pg.evaluate("JSON.parse(localStorage.getItem('glf-data-v1')).biens[0].bail"); check("bien enregistré en vide", st=="vide", st)
        # compta : message vide
        await pg.evaluate("V.tab='cmp';render();0"); await asyncio.sleep(.3); t=await pg.inner_text("body")
        check("compta : message location vide", "revenus fonciers" in t and "meublées" in t, t[:200])
        # bail vide
        await pg.evaluate("V.tab='bld';V.bsub='docs';V.bsel=bienIds()[0];render();0"); await asyncio.sleep(.4); t=await pg.inner_text("body")
        check("docs : pas d'inventaire, bail vide", "Inventaire du mobilier" not in t and "Bail logement vide" in t, t[:300])
        await jc(pg,"[data-act=bail-open]"); await asyncio.sleep(.3)
        t=await pg.inner_text("#sheet"); check("feuille bail vide : 3 ans, dépôt 1 mois", "3 ans" in t and "1 mois maximum" in t and "9 mois" not in t, t[:200])
        await pg.fill("#bl-dep","1000"); await jc(pg,"[data-act=bail-pdf]"); await asyncio.sleep(.4)
        t=await pg.inner_text("#toast"); check("dépôt > 1 mois refusé", "1 mois" in t, t)
        await pg.fill("#bl-dep","700")
        async with pg.expect_download() as d: await jc(pg,"[data-act=bail-pdf]")
        dl=await d.value; f=OUT/"bail-vide.pdf"; await dl.save_as(str(f)); tx=pdftxt(f)
        check("nom du fichier bail-vide", dl.suggested_filename.startswith("bail-vide-"), dl.suggested_filename)
        check("PDF : 3 ans, préavis 3 mois / 6 mois, pas de meublé", "trois ans" in tx and "trois mois" in tx and "six mois" in tx and "loué meublé" not in tx and "Inventaire" not in tx, tx[:100])
        # 2e bien meublé
        await pg.evaluate("S.biens.push({id:'M1',nom:'Studio meublé',adresse:'2 rue X 13100 Aix',solde0:0,date0:'2026-01-01',loyer:500,credit:0,regime:'LMNP',bail:'meuble',app:true,upd:1});persist();V.tab='bld';V.bsub='docs';V.bsel='M1';render();0"); await asyncio.sleep(.4)
        t=await pg.inner_text("body"); check("meublé : inventaire + bail meublé", "Inventaire du mobilier" in t and "Bail meublé" in t)
        await pg.evaluate("V.tab='cmp';render();0"); await asyncio.sleep(.3); t=await pg.inner_text("body")
        check("compta visible pour le meublé", "Résultat" in t and "À ne pas oublier" in t, t[:150])
        # courrier LMNP
        await pg.evaluate("V.tab='guide';render();0"); await pg.evaluate("document.querySelector('.gsec[data-g=dm]').open=true"); await asyncio.sleep(.2)
        await jc(pg,"[data-act=lmnp-open]"); await asyncio.sleep(.3); await pg.fill("#lm-sie","SIE Aix-en-Provence, 12 rue Z, 13100 Aix")
        async with pg.expect_download() as d: await jc(pg,"[data-act=lmnp-pdf]")
        dl=await d.value; f=OUT/"lmnp.pdf"; await dl.save_as(str(f)); tx=pdftxt(f)
        check("courrier LMNP", "Jeanne Test" in tx and "régime réel simplifié" in tx and "2 rue X" in tx and "Gestion Locative Facile" not in tx, tx[:300])
        check("aucune erreur JS", not errs, errs[:3])
        await b.close()
    print("RESULTAT:", "TOUT OK" if ok else "ECHEC")
asyncio.run(main())
