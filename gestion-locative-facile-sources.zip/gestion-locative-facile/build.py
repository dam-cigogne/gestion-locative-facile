#!/usr/bin/env python3
"""Reconstruit index.html (head + CSS + body + JS) à partir de src/. À lancer avant chaque publication :
   le <head> est toujours régénéré, donc l'ancien style ne reste jamais sur l'iPhone."""
import pathlib, re
root = pathlib.Path(__file__).parent; src = root / "src"
head = (src / "head.html").read_text(encoding="utf-8")
body = (src / "body.html").read_text(encoding="utf-8")
js = (src / "core.js").read_text(encoding="utf-8") + "\n" + (src / "views.js").read_text(encoding="utf-8") + "\n" + (src / "extra.js").read_text(encoding="utf-8") + "\n" + (src / "compta.js").read_text(encoding="utf-8") + "\n" + (src / "docs_a.js").read_text(encoding="utf-8") + "\n" + (src / "docs_b.js").read_text(encoding="utf-8") + "\n" + (src / "docs_c.js").read_text(encoding="utf-8") + "\n" + (src / "docs_d.js").read_text(encoding="utf-8") + "\n" + (src / "docs_e.js").read_text(encoding="utf-8") + "\n" + (src / "docs_f.js").read_text(encoding="utf-8") + "\n" + (src / "docs_g.js").read_text(encoding="utf-8") + "\n" + (src / "docs_h.js").read_text(encoding="utf-8") + "\n" + (src / "pub.js").read_text(encoding="utf-8") + "\n" + (src / "boot.js").read_text(encoding="utf-8")
html = f'''<!doctype html>
<html lang="fr">
<head>
{head}</head>
<body>
{body}
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script>
{js}
</script>
</body>
</html>
'''
(root / "index.html").write_text(html, encoding="utf-8")
for _n in ("candidature.html", "dossier.html"):
    (root / _n).write_text((src / _n).read_text(encoding="utf-8"), encoding="utf-8")
# fiche de présentation (page publique à partager) : version et date injectées
import datetime
_v = re.search(r'const APP_VERSION = "([^"]+)"', (src / "extra.js").read_text(encoding="utf-8")).group(1)
_d = datetime.date.today().strftime("%d/%m/%Y")
for _n in ("fiche.html", "confidentialite.html"):
    (root / _n).write_text((src / _n).read_text(encoding="utf-8").replace("{{VERSION}}", _v).replace("{{DATE}}", _d), encoding="utf-8")
# version du cache du service worker = hash du contenu, pour forcer la mise à jour à chaque build
import hashlib
h = hashlib.sha1(html.encode()).hexdigest()[:8]
sw = (root / "sw.js").read_text(encoding="utf-8")
sw = re.sub(r"const C = '[^']*';", f"const C = 'glf-{h}';", sw)
(root / "sw.js").write_text(sw, encoding="utf-8")
print("index.html", len(html), "octets ; cache glf-" + h)
