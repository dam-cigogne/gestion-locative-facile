# Gestion Locative Facile : sources

Appli web (PWA) en un seul fichier `index.html`, générée par `build.py` à partir de `src/`.

## Reconstruire
    python3 build.py        # produit index.html, fiche.html, confidentialite.html, candidature.html, dossier.html et met à jour sw.js (cache = hash)

## Fichiers publiés sur GitHub Pages (dépôt dam-cigogne/gestion-locative-facile)
index.html, sw.js, manifest.json, fiche.html, confidentialite.html, candidature.html, dossier.html, apercu.png, icon-180/192/512.png

## Organisation des sources (src/)
- core.js (état, stockage, utilitaires), views.js (écrans), extra.js (aide, historique, réglages, assistant de démarrage, PDF), compta.js (compta LMNP + liste « À ne pas oublier »)
- docs_a…docs_h.js (documents : états des lieux, inventaire, bail, signatures, candidatures, annonces, sauvegardes)
- pub.js : spécifique à la version publique (Guide du bailleur, courrier d'option LMNP, avertissements)
- affiches/ : sources de l'image d'aperçu (apercu.html + logo.png), à rendre en PNG 1200x630 avec Playwright

## Règles à garder
- Stockage propre : clés localStorage `glf-*`, base IndexedDB `glf-photos` / `glf-prefs`, caches `glf-*`. Ne JAMAIS réutiliser les clés `loc-*` ou `gestion-locative-v1` de l'autre appli « Mes locations » : les deux sont sur le même domaine dam-cigogne.github.io.
- Le service worker ne supprime que les caches qui commencent par `glf-`.
- Type de location par bien : `bien.bail` = "meuble" (défaut) ou "vide" (fonction `bkind(id)`). Il règle le bail PDF, le dépôt maximum, l'inventaire et l'onglet Compta (réservé au meublé / LMNP).
- Aucun chiffre fiscal en dur dans le guide : « à vérifier » + liens officiels.
- À chaque nouveauté : mettre à jour APP_VERSION et CHANGELOG (extra.js), l'aide (HELP), fiche.html.
